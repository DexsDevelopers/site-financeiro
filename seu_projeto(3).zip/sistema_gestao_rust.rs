use actix_web::{web, App, HttpServer, Result, HttpResponse, middleware::Logger};
use serde::{Deserialize, Serialize};
use mysql::*;
use mysql::prelude::*;
use std::collections::HashMap;
use jsonwebtoken::{encode, decode, Header, Algorithm, Validation, EncodingKey, DecodingKey};
use chrono::{Utc, Duration};
use uuid::Uuid;
use std::sync::Mutex;
use std::time::SystemTime;

// Estruturas de dados
#[derive(Debug, Serialize, Deserialize)]
struct Conta {
    id: u32,
    nome: String,
    descricao: Option<String>,
    codigo_conta: String,
    tipo: String,
    status: String,
    data_criacao: String,
    papel: Option<String>,
}

#[derive(Debug, Serialize, Deserialize)]
struct Membro {
    id: u32,
    conta_id: u32,
    usuario_id: u32,
    papel: String,
    status: String,
    data_convite: String,
    data_aceite: Option<String>,
    usuario: Option<String>,
    nome_completo: Option<String>,
    email: Option<String>,
}

#[derive(Debug, Serialize, Deserialize)]
struct Usuario {
    id: u32,
    usuario: String,
    nome_completo: String,
    email: String,
    tipo: String,
}

#[derive(Debug, Serialize, Deserialize)]
struct LoginRequest {
    usuario: String,
    senha: String,
}

#[derive(Debug, Serialize, Deserialize)]
struct LoginResponse {
    success: bool,
    token: String,
    user: Usuario,
}

#[derive(Debug, Serialize, Deserialize)]
struct ApiResponse<T> {
    success: bool,
    data: Option<T>,
    error: Option<String>,
    message: Option<String>,
}

#[derive(Debug, Serialize, Deserialize)]
struct Claims {
    id: u32,
    usuario: String,
    tipo: String,
    exp: usize,
}

// Estrutura principal do sistema
struct SistemaGestaoRust {
    pool: Pool,
}

impl SistemaGestaoRust {
    fn new() -> Self {
        let url = "mysql://u853242961_user7:Lucastav8012@@localhost:3306/u853242961_financeiro";
        let opts = Opts::from_url(url).unwrap();
        let pool = Pool::new(opts).unwrap();
        
        Self { pool }
    }

    fn get_contas(&self, usuario_id: u32) -> Result<Vec<Conta>, mysql::Error> {
        let mut conn = self.pool.get_conn()?;
        
        let contas: Vec<Conta> = conn.query_map(
            "SELECT c.id, c.nome, c.descricao, c.codigo_conta, c.tipo, c.status, c.data_criacao, cm.papel
             FROM contas c
             JOIN conta_membros cm ON c.id = cm.conta_id
             WHERE cm.usuario_id = ? AND cm.status = 'ativo'
             ORDER BY c.data_criacao DESC",
            (usuario_id,),
            |(id, nome, descricao, codigo_conta, tipo, status, data_criacao, papel)| Conta {
                id,
                nome,
                descricao,
                codigo_conta,
                tipo,
                status,
                data_criacao: data_criacao.format("%Y-%m-%d %H:%M:%S").to_string(),
                papel: Some(papel),
            },
        )?;
        
        Ok(contas)
    }

    fn create_conta(&self, nome: String, descricao: Option<String>, tipo: String, usuario_id: u32) -> Result<u32, mysql::Error> {
        let mut conn = self.pool.get_conn()?;
        
        // Iniciar transação
        conn.query_drop("START TRANSACTION")?;
        
        let codigo_conta = format!("CONTA-{}", SystemTime::now().duration_since(SystemTime::UNIX_EPOCH).unwrap().as_secs());
        
        // Criar conta
        let conta_id: u32 = conn.query_first(
            "INSERT INTO contas (nome, descricao, codigo_conta, tipo, criado_por) VALUES (?, ?, ?, ?, ?)",
            (nome.clone(), descricao, codigo_conta, tipo, usuario_id)
        )?.unwrap();
        
        // Adicionar criador como proprietário
        conn.query_drop(
            "INSERT INTO conta_membros (conta_id, usuario_id, papel, status, data_aceite) VALUES (?, ?, 'proprietario', 'ativo', NOW())",
            (conta_id, usuario_id)
        )?;
        
        // Log da ação
        conn.query_drop(
            "INSERT INTO conta_logs (conta_id, usuario_id, acao, modulo, descricao) VALUES (?, ?, 'criar_conta', 'sistema', ?)",
            (conta_id, usuario_id, format!("Conta \"{}\" criada", nome))
        )?;
        
        // Confirmar transação
        conn.query_drop("COMMIT")?;
        
        Ok(conta_id)
    }

    fn update_conta(&self, conta_id: u32, nome: String, descricao: Option<String>, tipo: String, status: String, usuario_id: u32) -> Result<(), mysql::Error> {
        let mut conn = self.pool.get_conn()?;
        
        // Verificar permissão
        let papel: Option<String> = conn.query_first(
            "SELECT papel FROM conta_membros WHERE conta_id = ? AND usuario_id = ? AND status = 'ativo'",
            (conta_id, usuario_id)
        )?;
        
        if let Some(papel) = papel {
            if papel != "proprietario" && papel != "administrador" {
                return Err(mysql::Error::from(mysql::Error::from("Sem permissão para editar esta conta")));
            }
        } else {
            return Err(mysql::Error::from("Usuário não é membro desta conta"));
        }
        
        // Atualizar conta
        conn.query_drop(
            "UPDATE contas SET nome = ?, descricao = ?, tipo = ?, status = ? WHERE id = ?",
            (nome.clone(), descricao, tipo, status, conta_id)
        )?;
        
        // Log da ação
        conn.query_drop(
            "INSERT INTO conta_logs (conta_id, usuario_id, acao, modulo, descricao) VALUES (?, ?, 'editar_conta', 'sistema', ?)",
            (conta_id, usuario_id, format!("Conta \"{}\" editada", nome))
        )?;
        
        Ok(())
    }

    fn delete_conta(&self, conta_id: u32, usuario_id: u32) -> Result<(), mysql::Error> {
        let mut conn = self.pool.get_conn()?;
        
        // Verificar se é proprietário
        let papel: Option<String> = conn.query_first(
            "SELECT papel FROM conta_membros WHERE conta_id = ? AND usuario_id = ? AND status = 'ativo'",
            (conta_id, usuario_id)
        )?;
        
        if let Some(papel) = papel {
            if papel != "proprietario" {
                return Err(mysql::Error::from("Apenas o proprietário pode excluir a conta"));
            }
        } else {
            return Err(mysql::Error::from("Usuário não é membro desta conta"));
        }
        
        // Excluir conta
        conn.query_drop("DELETE FROM contas WHERE id = ?", (conta_id,))?;
        
        Ok(())
    }

    fn get_membros(&self, conta_id: u32) -> Result<Vec<Membro>, mysql::Error> {
        let mut conn = self.pool.get_conn()?;
        
        let membros: Vec<Membro> = conn.query_map(
            "SELECT cm.id, cm.conta_id, cm.usuario_id, cm.papel, cm.status, cm.data_convite, cm.data_aceite,
                    u.usuario, u.nome_completo, u.email
             FROM conta_membros cm
             JOIN usuarios u ON cm.usuario_id = u.id
             WHERE cm.conta_id = ?
             ORDER BY cm.data_convite DESC",
            (conta_id,),
            |(id, conta_id, usuario_id, papel, status, data_convite, data_aceite, usuario, nome_completo, email)| Membro {
                id,
                conta_id,
                usuario_id,
                papel,
                status,
                data_convite: data_convite.format("%Y-%m-%d %H:%M:%S").to_string(),
                data_aceite: data_aceite.map(|d| d.format("%Y-%m-%d %H:%M:%S").to_string()),
                usuario: Some(usuario),
                nome_completo: Some(nome_completo),
                email: Some(email),
            },
        )?;
        
        Ok(membros)
    }

    fn add_membro(&self, conta_id: u32, usuario_id: u32, papel: String, convidado_por: u32) -> Result<(), mysql::Error> {
        let mut conn = self.pool.get_conn()?;
        
        conn.query_drop(
            "INSERT INTO conta_membros (conta_id, usuario_id, papel, status, data_aceite, convidado_por) VALUES (?, ?, ?, 'ativo', NOW(), ?)",
            (conta_id, usuario_id, papel, convidado_por)
        )?;
        
        Ok(())
    }

    fn convidar_membro(&self, conta_id: u32, email: String, papel: String, convidado_por: u32) -> Result<String, mysql::Error> {
        let mut conn = self.pool.get_conn()?;
        
        let codigo_convite = format!("CONV-{}-{}", 
            SystemTime::now().duration_since(SystemTime::UNIX_EPOCH).unwrap().as_secs(),
            Uuid::new_v4().to_string().replace("-", "").chars().take(9).collect::<String>()
        );
        
        let data_expiracao = Utc::now() + Duration::days(7);
        
        conn.query_drop(
            "INSERT INTO conta_convites (conta_id, email, codigo_convite, papel, data_expiracao, convidado_por) VALUES (?, ?, ?, ?, ?, ?)",
            (conta_id, email, codigo_convite.clone(), papel, data_expiracao.format("%Y-%m-%d %H:%M:%S").to_string(), convidado_por)
        )?;
        
        Ok(codigo_convite)
    }

    fn get_logs(&self, conta_id: u32, limit: u32, offset: u32) -> Result<Vec<HashMap<String, String>>, mysql::Error> {
        let mut conn = self.pool.get_conn()?;
        
        let logs: Vec<HashMap<String, String>> = conn.query_map(
            "SELECT * FROM conta_logs WHERE conta_id = ? ORDER BY data_acao DESC LIMIT ? OFFSET ?",
            (conta_id, limit, offset),
            |row| {
                let mut map = HashMap::new();
                map.insert("id".to_string(), row.get::<u32, _>("id").unwrap().to_string());
                map.insert("usuario_id".to_string(), row.get::<u32, _>("usuario_id").unwrap().to_string());
                map.insert("acao".to_string(), row.get::<String, _>("acao").unwrap());
                map.insert("modulo".to_string(), row.get::<String, _>("modulo").unwrap());
                map.insert("descricao".to_string(), row.get::<String, _>("descricao").unwrap_or_default());
                map.insert("data_acao".to_string(), row.get::<String, _>("data_acao").unwrap());
                map
            },
        )?;
        
        Ok(logs)
    }
}

// Handlers HTTP
async fn login(
    req: web::Json<LoginRequest>,
    data: web::Data<SistemaGestaoRust>,
) -> Result<HttpResponse, actix_web::Error> {
    let mut conn = data.pool.get_conn().map_err(|e| actix_web::error::ErrorInternalServerError(e))?;
    
    // Buscar usuário
    let user: Option<(u32, String, String, String, String, String)> = conn.query_first(
        "SELECT id, usuario, senha_hash, nome_completo, email, tipo FROM usuarios WHERE usuario = ?",
        (req.usuario.clone(),)
    ).map_err(|e| actix_web::error::ErrorInternalServerError(e))?;
    
    let (id, usuario, senha_hash, nome_completo, email, tipo) = match user {
        Some(user) => user,
        None => return Ok(HttpResponse::Unauthorized().json(ApiResponse::<()> {
            success: false,
            data: None,
            error: Some("Credenciais inválidas".to_string()),
            message: None,
        })),
    };
    
    // Verificar senha (simplificado para exemplo)
    if senha_hash != req.senha {
        return Ok(HttpResponse::Unauthorized().json(ApiResponse::<()> {
            success: false,
            data: None,
            error: Some("Credenciais inválidas".to_string()),
            message: None,
        }));
    }
    
    // Gerar token JWT
    let claims = Claims {
        id,
        usuario: usuario.clone(),
        tipo,
        exp: (Utc::now() + Duration::hours(24)).timestamp() as usize,
    };
    
    let token = encode(&Header::default(), &claims, &EncodingKey::from_secret("sua-chave-secreta".as_ref()))
        .map_err(|e| actix_web::error::ErrorInternalServerError(e))?;
    
    let response = LoginResponse {
        success: true,
        token,
        user: Usuario {
            id,
            usuario,
            nome_completo,
            email,
            tipo,
        },
    };
    
    Ok(HttpResponse::Ok().json(response))
}

async fn get_contas(
    data: web::Data<SistemaGestaoRust>,
    claims: web::ReqData<Claims>,
) -> Result<HttpResponse, actix_web::Error> {
    let contas = data.get_contas(claims.id).map_err(|e| actix_web::error::ErrorInternalServerError(e))?;
    
    let response = ApiResponse {
        success: true,
        data: Some(contas),
        error: None,
        message: None,
    };
    
    Ok(HttpResponse::Ok().json(response))
}

async fn create_conta(
    req: web::Json<serde_json::Value>,
    data: web::Data<SistemaGestaoRust>,
    claims: web::ReqData<Claims>,
) -> Result<HttpResponse, actix_web::Error> {
    let nome = req["nome"].as_str().unwrap_or("").to_string();
    let descricao = req["descricao"].as_str().map(|s| s.to_string());
    let tipo = req["tipo"].as_str().unwrap_or("pessoal").to_string();
    
    let conta_id = data.create_conta(nome.clone(), descricao, tipo, claims.id)
        .map_err(|e| actix_web::error::ErrorInternalServerError(e))?;
    
    let response = ApiResponse {
        success: true,
        data: Some(serde_json::json!({
            "id": conta_id,
            "nome": nome
        })),
        error: None,
        message: Some("Conta criada com sucesso".to_string()),
    };
    
    Ok(HttpResponse::Created().json(response))
}

async fn update_conta(
    path: web::Path<u32>,
    req: web::Json<serde_json::Value>,
    data: web::Data<SistemaGestaoRust>,
    claims: web::ReqData<Claims>,
) -> Result<HttpResponse, actix_web::Error> {
    let conta_id = path.into_inner();
    let nome = req["nome"].as_str().unwrap_or("").to_string();
    let descricao = req["descricao"].as_str().map(|s| s.to_string());
    let tipo = req["tipo"].as_str().unwrap_or("pessoal").to_string();
    let status = req["status"].as_str().unwrap_or("ativa").to_string();
    
    data.update_conta(conta_id, nome, descricao, tipo, status, claims.id)
        .map_err(|e| actix_web::error::ErrorInternalServerError(e))?;
    
    let response = ApiResponse {
        success: true,
        data: None,
        error: None,
        message: Some("Conta atualizada com sucesso".to_string()),
    };
    
    Ok(HttpResponse::Ok().json(response))
}

async fn delete_conta(
    path: web::Path<u32>,
    data: web::Data<SistemaGestaoRust>,
    claims: web::ReqData<Claims>,
) -> Result<HttpResponse, actix_web::Error> {
    let conta_id = path.into_inner();
    
    data.delete_conta(conta_id, claims.id)
        .map_err(|e| actix_web::error::ErrorInternalServerError(e))?;
    
    let response = ApiResponse {
        success: true,
        data: None,
        error: None,
        message: Some("Conta excluída com sucesso".to_string()),
    };
    
    Ok(HttpResponse::Ok().json(response))
}

async fn get_membros(
    path: web::Path<u32>,
    data: web::Data<SistemaGestaoRust>,
) -> Result<HttpResponse, actix_web::Error> {
    let conta_id = path.into_inner();
    
    let membros = data.get_membros(conta_id).map_err(|e| actix_web::error::ErrorInternalServerError(e))?;
    
    let response = ApiResponse {
        success: true,
        data: Some(membros),
        error: None,
        message: None,
    };
    
    Ok(HttpResponse::Ok().json(response))
}

async fn add_membro(
    path: web::Path<u32>,
    req: web::Json<serde_json::Value>,
    data: web::Data<SistemaGestaoRust>,
    claims: web::ReqData<Claims>,
) -> Result<HttpResponse, actix_web::Error> {
    let conta_id = path.into_inner();
    let usuario_id = req["usuario_id"].as_u64().unwrap_or(0) as u32;
    let papel = req["papel"].as_str().unwrap_or("membro").to_string();
    
    data.add_membro(conta_id, usuario_id, papel, claims.id)
        .map_err(|e| actix_web::error::ErrorInternalServerError(e))?;
    
    let response = ApiResponse {
        success: true,
        data: None,
        error: None,
        message: Some("Membro adicionado com sucesso".to_string()),
    };
    
    Ok(HttpResponse::Created().json(response))
}

async fn convidar_membro(
    path: web::Path<u32>,
    req: web::Json<serde_json::Value>,
    data: web::Data<SistemaGestaoRust>,
    claims: web::ReqData<Claims>,
) -> Result<HttpResponse, actix_web::Error> {
    let conta_id = path.into_inner();
    let email = req["email"].as_str().unwrap_or("").to_string();
    let papel = req["papel"].as_str().unwrap_or("membro").to_string();
    
    let codigo_convite = data.convidar_membro(conta_id, email.clone(), papel, claims.id)
        .map_err(|e| actix_web::error::ErrorInternalServerError(e))?;
    
    let response = ApiResponse {
        success: true,
        data: Some(serde_json::json!({
            "codigo_convite": codigo_convite,
            "email": email
        })),
        error: None,
        message: Some("Convite criado com sucesso".to_string()),
    };
    
    Ok(HttpResponse::Created().json(response))
}

async fn get_logs(
    path: web::Path<u32>,
    query: web::Query<HashMap<String, String>>,
    data: web::Data<SistemaGestaoRust>,
) -> Result<HttpResponse, actix_web::Error> {
    let conta_id = path.into_inner();
    let limit = query.get("limit").and_then(|s| s.parse().ok()).unwrap_or(50);
    let offset = query.get("offset").and_then(|s| s.parse().ok()).unwrap_or(0);
    
    let logs = data.get_logs(conta_id, limit, offset).map_err(|e| actix_web::error::ErrorInternalServerError(e))?;
    
    let response = ApiResponse {
        success: true,
        data: Some(logs),
        error: None,
        message: None,
    };
    
    Ok(HttpResponse::Ok().json(response))
}

async fn health_check(
    data: web::Data<SistemaGestaoRust>,
) -> Result<HttpResponse, actix_web::Error> {
    // Verificar conexão com banco
    let _ = data.pool.get_conn().map_err(|e| actix_web::error::ErrorInternalServerError(e))?;
    
    let response = serde_json::json!({
        "status": "ok",
        "timestamp": Utc::now().format("%Y-%m-%dT%H:%M:%S%.3fZ").to_string(),
        "service": "gestao-contas-rust",
        "version": "1.0.0",
        "database": "connected"
    });
    
    Ok(HttpResponse::Ok().json(response))
}

// Middleware de autenticação JWT
async fn authenticate_token(
    req: actix_web::HttpRequest,
    next: actix_web::web::Next,
) -> Result<actix_web::web::ServiceRequest, actix_web::Error> {
    let auth_header = req.headers().get("Authorization");
    
    if let Some(header) = auth_header {
        if let Ok(header_str) = header.to_str() {
            if header_str.starts_with("Bearer ") {
                let token = &header_str[7..];
                
                let validation = Validation::new(Algorithm::HS256);
                let token_data = decode::<Claims>(
                    token,
                    &DecodingKey::from_secret("sua-chave-secreta".as_ref()),
                    &validation,
                );
                
                if let Ok(token_data) = token_data {
                    req.extensions_mut().insert(token_data.claims);
                    return Ok(next.call(req).await?);
                }
            }
        }
    }
    
    Err(actix_web::error::ErrorUnauthorized("Token de acesso necessário"))
}

#[actix_web::main]
async fn main() -> std::io::Result<()> {
    // Configurar logging
    std::env::set_var("RUST_LOG", "actix_web=info");
    env_logger::init();
    
    println!("🚀 Servidor Rust rodando na porta 8081");
    println!("📡 API disponível em: http://localhost:8081");
    println!("🔍 Health check: http://localhost:8081/health");
    println!("🔐 Autenticação: POST /auth/login");
    println!("📋 Contas: GET /api/contas");
    
    let sistema = SistemaGestaoRust::new();
    
    HttpServer::new(move || {
        App::new()
            .app_data(web::Data::new(sistema.clone()))
            .wrap(Logger::default())
            .service(
                web::scope("/auth")
                    .route("/login", web::post().to(login))
            )
            .service(
                web::scope("/api")
                    .wrap_fn(authenticate_token)
                    .route("/contas", web::get().to(get_contas))
                    .route("/contas", web::post().to(create_conta))
                    .route("/contas/{id}", web::put().to(update_conta))
                    .route("/contas/{id}", web::delete().to(delete_conta))
                    .route("/contas/{id}/membros", web::get().to(get_membros))
                    .route("/contas/{id}/membros", web::post().to(add_membro))
                    .route("/contas/{id}/convidar", web::post().to(convidar_membro))
                    .route("/contas/{id}/logs", web::get().to(get_logs))
            )
            .route("/health", web::get().to(health_check))
    })
    .bind("127.0.0.1:8081")?
    .run()
    .await
}

<?php
// criar_conta.php - API para criar nova conta

session_start();
require_once 'includes/db_connect.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Acesso negado']);
    exit();
}

$userId = $_SESSION['user_id'];

// Verificar se é uma requisição POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit();
}

// Obter dados do formulário
$nome = trim($_POST['nome'] ?? '');
$descricao = trim($_POST['descricao'] ?? '');
$tipo = $_POST['tipo'] ?? 'pessoal';

// Validar dados
if (empty($nome)) {
    echo json_encode(['success' => false, 'message' => 'Nome da conta é obrigatório']);
    exit();
}

if (!in_array($tipo, ['pessoal', 'empresarial', 'familia'])) {
    echo json_encode(['success' => false, 'message' => 'Tipo de conta inválido']);
    exit();
}

try {
    // Gerar código único para a conta
    $codigoConta = 'CONTA_' . $userId . '_' . time() . '_' . rand(1000, 9999);
    
    // Criar a conta
    $stmt = $pdo->prepare("
        INSERT INTO contas (nome, descricao, codigo_conta, tipo, criado_por) 
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->execute([$nome, $descricao, $codigoConta, $tipo, $userId]);
    
    $contaId = $pdo->lastInsertId();
    
    // Adicionar o usuário como proprietário da conta
    $stmt = $pdo->prepare("
        INSERT INTO conta_membros (conta_id, usuario_id, papel, status, data_aceite) 
        VALUES (?, ?, 'proprietario', 'ativo', NOW())
    ");
    $stmt->execute([$contaId, $userId]);
    
    // Criar permissões padrão para o proprietário
    $permissoesPadrao = [
        ['financeiro', 'visualizar_saldo', true],
        ['financeiro', 'editar_transacoes', true],
        ['financeiro', 'excluir_transacoes', true],
        ['financeiro', 'gerar_relatorios', true],
        ['produtividade', 'visualizar_tarefas', true],
        ['produtividade', 'editar_tarefas', true],
        ['produtividade', 'excluir_tarefas', true],
        ['produtividade', 'gerar_relatorios', true],
        ['sistema', 'gerenciar_usuarios', true],
        ['sistema', 'gerenciar_permissoes', true],
        ['sistema', 'visualizar_logs', true]
    ];
    
    foreach ($permissoesPadrao as $permissao) {
        $stmt = $pdo->prepare("
            INSERT INTO conta_permissoes (conta_id, usuario_id, modulo, permissao, permitido) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([$contaId, $userId, $permissao[0], $permissao[1], $permissao[2]]);
    }
    
    // Registrar log
    $stmt = $pdo->prepare("
        INSERT INTO conta_logs (conta_id, usuario_id, acao, modulo, detalhes) 
        VALUES (?, ?, 'conta_criada', 'sistema', ?)
    ");
    $stmt->execute([$contaId, $userId, "Conta '{$nome}' criada"]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Conta criada com sucesso!',
        'conta_id' => $contaId
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao criar conta: ' . $e->getMessage()
    ]);
}
?>

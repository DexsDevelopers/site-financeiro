<?php
// criar_usuario_conta.php - Criar usuário para conta específica

session_start();
require_once 'includes/db_connect.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Acesso negado']);
    exit();
}

$userId = $_SESSION['user_id'];

// Verificar se é uma requisição POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit();
}

// Obter dados do formulário
$contaId = (int)($_POST['conta_id'] ?? 0);
$nome = trim($_POST['nome'] ?? '');
$email = trim($_POST['email'] ?? '');
$senha = $_POST['senha'] ?? '';
$confirmarSenha = $_POST['confirmar_senha'] ?? '';
$papel = $_POST['papel'] ?? 'membro';

// Permissões granulares
$permissoes = [
    'financeiro' => isset($_POST['perm_financeiro']) ? (bool)$_POST['perm_financeiro'] : false,
    'produtividade' => isset($_POST['perm_produtividade']) ? (bool)$_POST['perm_produtividade'] : false,
    'academy' => isset($_POST['perm_academy']) ? (bool)$_POST['perm_academy'] : false,
    'ver_saldo' => isset($_POST['perm_ver_saldo']) ? (bool)$_POST['perm_ver_saldo'] : false,
    'editar_financeiro' => isset($_POST['perm_editar_financeiro']) ? (bool)$_POST['perm_editar_financeiro'] : false,
    'excluir_financeiro' => isset($_POST['perm_excluir_financeiro']) ? (bool)$_POST['perm_excluir_financeiro'] : false
];

// Validar dados
if ($contaId <= 0) {
    echo json_encode(['success' => false, 'message' => 'ID da conta inválido']);
    exit();
}

if (empty($nome)) {
    echo json_encode(['success' => false, 'message' => 'Nome é obrigatório']);
    exit();
}

if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'E-mail inválido']);
    exit();
}

if (empty($senha) || strlen($senha) < 6) {
    echo json_encode(['success' => false, 'message' => 'Senha deve ter pelo menos 6 caracteres']);
    exit();
}

if ($senha !== $confirmarSenha) {
    echo json_encode(['success' => false, 'message' => 'Senhas não coincidem']);
    exit();
}

if (!in_array($papel, ['membro', 'administrador', 'visualizador'])) {
    echo json_encode(['success' => false, 'message' => 'Papel inválido']);
    exit();
}

try {
    // Verificar se o usuário tem permissão para criar usuários nesta conta
    $stmt = $pdo->prepare("
        SELECT cm.papel 
        FROM conta_membros cm 
        WHERE cm.conta_id = ? AND cm.usuario_id = ? AND cm.status = 'ativo'
    ");
    $stmt->execute([$contaId, $userId]);
    $membro = $stmt->fetch();
    
    if (!$membro || !in_array($membro['papel'], ['proprietario', 'administrador'])) {
        echo json_encode(['success' => false, 'message' => 'Você não tem permissão para criar usuários nesta conta']);
        exit();
    }
    
    // Verificar se o e-mail já existe
    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE email = ?");
    $stmt->execute([$email]);
    
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Este e-mail já está em uso']);
        exit();
    }
    
    // Criar o usuário
    $senhaHash = password_hash($senha, PASSWORD_DEFAULT);
    
    $stmt = $pdo->prepare("
        INSERT INTO usuarios (nome, email, senha, data_criacao) 
        VALUES (?, ?, ?, NOW())
    ");
    $stmt->execute([$nome, $email, $senhaHash]);
    
    $novoUsuarioId = $pdo->lastInsertId();
    
    // Adicionar o usuário como membro da conta
    $stmt = $pdo->prepare("
        INSERT INTO conta_membros (conta_id, usuario_id, papel, status, data_aceite, convidado_por) 
        VALUES (?, ?, ?, 'ativo', NOW(), ?)
    ");
    $stmt->execute([$contaId, $novoUsuarioId, $papel, $userId]);
    
    // Criar permissões específicas
    $permissoesParaInserir = [
        ['financeiro', 'visualizar_saldo', $permissoes['ver_saldo']],
        ['financeiro', 'editar_transacoes', $permissoes['editar_financeiro']],
        ['financeiro', 'excluir_transacoes', $permissoes['excluir_financeiro']],
        ['financeiro', 'gerar_relatorios', $permissoes['financeiro']],
        ['produtividade', 'visualizar_tarefas', $permissoes['produtividade']],
        ['produtividade', 'editar_tarefas', $permissoes['produtividade']],
        ['produtividade', 'excluir_tarefas', $permissoes['produtividade']],
        ['produtividade', 'gerar_relatorios', $permissoes['produtividade']],
        ['academy', 'visualizar_cursos', $permissoes['academy']],
        ['academy', 'editar_cursos', $permissoes['academy']],
        ['academy', 'excluir_cursos', $permissoes['academy']],
        ['academy', 'gerar_relatorios', $permissoes['academy']]
    ];
    
    foreach ($permissoesParaInserir as $permissao) {
        $stmt = $pdo->prepare("
            INSERT INTO conta_permissoes (conta_id, usuario_id, modulo, permissao, permitido) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([$contaId, $novoUsuarioId, $permissao[0], $permissao[1], $permissao[2]]);
    }
    
    // Registrar log
    $stmt = $pdo->prepare("
        INSERT INTO conta_logs (conta_id, usuario_id, acao, modulo, detalhes) 
        VALUES (?, ?, 'usuario_criado', 'sistema', ?)
    ");
    $stmt->execute([$contaId, $userId, "Usuário '{$nome}' criado com papel '{$papel}'"]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Usuário criado com sucesso!',
        'usuario_id' => $novoUsuarioId,
        'login' => $email,
        'senha' => $senha
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao criar usuário: ' . $e->getMessage()
    ]);
}
?>

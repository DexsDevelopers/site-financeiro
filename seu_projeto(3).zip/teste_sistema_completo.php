<?php
// teste_sistema_completo.php - Teste completo do sistema de gestão

session_start();
require_once 'includes/db_connect.php';

echo "<h2>🧪 TESTE COMPLETO DO SISTEMA DE GESTÃO</h2>";

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    echo "❌ Usuário não está logado. Faça login primeiro.<br>";
    echo "<a href='login.php' class='btn btn-primary'>Fazer Login</a><br><br>";
    exit();
}

$userId = $_SESSION['user_id'];
echo "✅ Usuário logado: ID $userId<br><br>";

// 1. Verificar estrutura das tabelas
echo "<h3>1. Verificando Estrutura das Tabelas</h3>";

$tabelas_necessarias = [
    'contas' => 'Tabela de contas/organizações',
    'conta_membros' => 'Tabela de membros das contas',
    'conta_permissoes' => 'Tabela de permissões granulares',
    'conta_convites' => 'Tabela de convites',
    'conta_logs' => 'Tabela de logs de atividades'
];

$tabelas_ok = 0;

foreach ($tabelas_necessarias as $tabela => $descricao) {
    try {
        $stmt = $pdo->query("SHOW TABLES LIKE '$tabela'");
        if ($stmt->fetch()) {
            echo "✅ $tabela - $descricao<br>";
            $tabelas_ok++;
        } else {
            echo "❌ $tabela - $descricao (NÃO ENCONTRADA)<br>";
        }
    } catch (Exception $e) {
        echo "❌ $tabela - $descricao (ERRO: " . $e->getMessage() . ")<br>";
    }
}

echo "<p><strong>Tabelas OK: $tabelas_ok/" . count($tabelas_necessarias) . "</strong></p>";

echo "<hr>";

// 2. Verificar arquivos do sistema
echo "<h3>2. Verificando Arquivos do Sistema</h3>";

$arquivos_sistema = [
    'gestao_contas.php' => 'Interface principal de gestão',
    'criar_conta.php' => 'API para criar contas',
    'criar_usuario_conta.php' => 'API para criar usuários',
    'convidar_membro.php' => 'API para convidar membros',
    'aceitar_convite.php' => 'API para aceitar convites',
    'recusar_convite.php' => 'API para recusar convites',
    'buscar_membros_conta.php' => 'API para buscar membros',
    'buscar_permissoes_conta.php' => 'API para buscar permissões',
    'atualizar_permissao.php' => 'API para atualizar permissões',
    'definir_conta_ativa.php' => 'API para definir conta ativa',
    'excluir_conta.php' => 'API para excluir conta',
    'remover_membro.php' => 'API para remover membro',
    'includes/verificar_permissoes.php' => 'Sistema de permissões',
    'includes/verificar_acesso_modulo.php' => 'Verificação de acesso'
];

$arquivos_ok = 0;

foreach ($arquivos_sistema as $arquivo => $descricao) {
    if (file_exists($arquivo)) {
        echo "✅ $arquivo - $descricao<br>";
        $arquivos_ok++;
    } else {
        echo "❌ $arquivo - $descricao (NÃO ENCONTRADO)<br>";
    }
}

echo "<p><strong>Arquivos OK: $arquivos_ok/" . count($arquivos_sistema) . "</strong></p>";

echo "<hr>";

// 3. Verificar contas do usuário
echo "<h3>3. Verificando Contas do Usuário</h3>";

try {
    $stmt = $pdo->prepare("
        SELECT 
            c.*,
            cm.papel,
            cm.status as status_membro
        FROM contas c
        JOIN conta_membros cm ON c.id = cm.conta_id
        WHERE cm.usuario_id = ? AND cm.status = 'ativo'
        ORDER BY c.data_criacao DESC
    ");
    $stmt->execute([$userId]);
    $contas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "📊 Total de contas: " . count($contas) . "<br>";
    
    if (!empty($contas)) {
        echo "<table border='1' style='border-collapse: collapse; width: 100%; margin: 1rem 0;'>";
        echo "<tr><th>ID</th><th>Nome</th><th>Tipo</th><th>Papel</th><th>Status</th><th>Data Criação</th></tr>";
        
        foreach ($contas as $conta) {
            echo "<tr>";
            echo "<td>" . $conta['id'] . "</td>";
            echo "<td>" . htmlspecialchars($conta['nome']) . "</td>";
            echo "<td>" . ucfirst($conta['tipo']) . "</td>";
            echo "<td>" . ucfirst($conta['papel']) . "</td>";
            echo "<td>" . ucfirst($conta['status']) . "</td>";
            echo "<td>" . date('d/m/Y H:i', strtotime($conta['data_criacao'])) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "⚠️ Nenhuma conta encontrada<br>";
        echo "💡 <a href='criar_sistema_gestao_contas.php'>Execute o script de criação</a> para criar a conta padrão<br>";
    }
    
} catch (Exception $e) {
    echo "❌ Erro ao verificar contas: " . $e->getMessage() . "<br>";
}

echo "<hr>";

// 4. Verificar menu do sistema
echo "<h3>4. Verificando Menu do Sistema</h3>";

$conteudo_menu = file_get_contents('includes/load_menu_config.php');

$itens_menu = [
    'gestao_contas.php' => 'Gestão de Contas',
    'configurar_permissoes.php' => 'Configurar Permissões',
    'logs_atividades.php' => 'Logs de Atividades'
];

$menu_ok = 0;

foreach ($itens_menu as $arquivo => $nome) {
    if (strpos($conteudo_menu, $arquivo) !== false) {
        echo "✅ $nome ($arquivo) - Adicionado ao menu<br>";
        $menu_ok++;
    } else {
        echo "❌ $nome ($arquivo) - NÃO encontrado no menu<br>";
    }
}

echo "<p><strong>Itens do menu OK: $menu_ok/" . count($itens_menu) . "</strong></p>";

echo "<hr>";

// 5. Teste de funcionalidades
echo "<h3>5. Teste de Funcionalidades</h3>";

echo "🔧 Testando funcionalidades básicas:<br>";

// Testar criação de log
try {
    require_once 'includes/verificar_permissoes.php';
    $sistemaPermissoes = new SistemaPermissoes($pdo, $userId);
    $resultado = $sistemaPermissoes->registrarAtividade('teste_sistema', 'sistema', 'Teste do sistema de gestão');
    echo "Registrar atividade: " . ($resultado ? '✅ OK' : '❌ ERRO') . "<br>";
} catch (Exception $e) {
    echo "Registrar atividade: ❌ ERRO - " . $e->getMessage() . "<br>";
}

// Testar obter todas as permissões
try {
    $sistemaPermissoes = new SistemaPermissoes($pdo, $userId);
    $permissoes = $sistemaPermissoes->obterTodasPermissoes();
    echo "Obter permissões: " . (is_array($permissoes) ? '✅ OK' : '❌ ERRO') . "<br>";
    echo "Total de permissões: " . count($permissoes) . "<br>";
} catch (Exception $e) {
    echo "Obter permissões: ❌ ERRO - " . $e->getMessage() . "<br>";
}

echo "<hr>";

// 6. Verificar interface de gestão
echo "<h3>6. Verificando Interface de Gestão</h3>";

$conteudo_gestao = file_get_contents('gestao_contas.php');

$funcionalidades_interface = [
    'modalCriarUsuario' => 'Modal para criar usuário',
    'modalGerenciarMembros' => 'Modal para gerenciar membros',
    'modalConfigurarPermissoes' => 'Modal para configurar permissões',
    'criarUsuario(' => 'Função para criar usuário',
    'gerenciarMembros(' => 'Função para gerenciar membros',
    'configurarPermissoes(' => 'Função para configurar permissões',
    'atualizarPermissao(' => 'Função para atualizar permissão'
];

$interface_ok = 0;

foreach ($funcionalidades_interface as $funcionalidade => $descricao) {
    if (strpos($conteudo_gestao, $funcionalidade) !== false) {
        echo "✅ $descricao<br>";
        $interface_ok++;
    } else {
        echo "❌ $descricao (NÃO ENCONTRADA)<br>";
    }
}

echo "<p><strong>Funcionalidades da interface OK: $interface_ok/" . count($funcionalidades_interface) . "</strong></p>";

echo "<hr>";

// 7. Resumo final
echo "<h2>📊 RESUMO FINAL</h2>";

$total_verificacoes = count($tabelas_necessarias) + count($arquivos_sistema) + count($itens_menu) + 3 + count($funcionalidades_interface);
$verificacoes_ok = $tabelas_ok + $arquivos_ok + $menu_ok + 3 + $interface_ok;

echo "<p><strong>Verificações OK: $verificacoes_ok/$total_verificacoes</strong></p>";

if ($verificacoes_ok >= $total_verificacoes * 0.8) {
    echo "<div style='background: #d4edda; padding: 1rem; border-radius: 8px; margin: 1rem 0;'>";
    echo "<h4>✅ Sistema de Gestão de Contas Funcionando!</h4>";
    echo "<p>O sistema está pronto para uso. Você pode:</p>";
    echo "<ul>";
    echo "<li>🏢 <a href='gestao_contas.php'>Gerenciar suas contas</a></li>";
    echo "<li>👥 Criar usuários com login/senha</li>";
    echo "<li>🔐 Configurar permissões granulares</li>";
    echo "<li>📊 Controlar acesso a módulos específicos</li>";
    echo "<li>📝 Visualizar logs de atividades</li>";
    echo "</ul>";
    echo "</div>";
} else {
    echo "<div style='background: #f8d7da; padding: 1rem; border-radius: 8px; margin: 1rem 0;'>";
    echo "<h4>❌ Sistema Precisa de Ajustes</h4>";
    echo "<p>Algumas funcionalidades ainda precisam ser implementadas. Verifique os itens marcados com ❌ acima.</p>";
    echo "<ol>";
    echo "<li>Execute <a href='criar_sistema_gestao_contas.php'>criar_sistema_gestao_contas.php</a> se as tabelas não existirem</li>";
    echo "<li>Verifique se todos os arquivos foram criados</li>";
    echo "<li>Teste as funcionalidades individualmente</li>";
    echo "</ol>";
    echo "</div>";
}

echo "<hr>";
echo "<p><strong>✅ Teste concluído!</strong> Use as recomendações acima para resolver os problemas.</p>";
?>

<?php
// verificar_arquivos_gestao.php - Verificar se todos os arquivos estão corretos para a gestão funcionar

// Configurações de erro
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "<h1>🔍 VERIFICAÇÃO DE ARQUIVOS PARA GESTÃO DE CONTAS</h1>";
echo "<p>Este script verifica se todos os arquivos estão corretos para o sistema de gestão de contas funcionar.</p>";

$problemas = [];
$sucessos = [];

// 1. Verificar arquivos principais
echo "<h2>1. Verificando Arquivos Principais</h2>";

$arquivos_principais = [
    'gestao_contas_unificada.php' => 'Página principal de gestão de contas',
    'login.php' => 'Sistema de login',
    'logout.php' => 'Sistema de logout',
    'templates/header.php' => 'Header do sistema',
    'includes/db_connect.php' => 'Conexão com banco de dados',
    'includes/load_menu_config.php' => 'Configuração do menu',
    'criar_tabelas_gestao_completa.php' => 'Script para criar tabelas'
];

foreach ($arquivos_principais as $arquivo => $descricao) {
    if (file_exists($arquivo)) {
        echo "✅ <strong>$arquivo</strong> - $descricao<br>";
        $sucessos[] = $arquivo;
    } else {
        echo "❌ <strong>$arquivo</strong> - $descricao (NÃO ENCONTRADO)<br>";
        $problemas[] = $arquivo;
    }
}

// 2. Verificar conexão com banco
echo "<h2>2. Verificando Conexão com Banco de Dados</h2>";

try {
    require_once 'includes/db_connect.php';
    echo "✅ Conexão com banco de dados funcionando<br>";
    $sucessos[] = 'Conexão com banco';
} catch (Exception $e) {
    echo "❌ Erro na conexão com banco: " . $e->getMessage() . "<br>";
    $problemas[] = 'Conexão com banco';
}

// 3. Verificar tabelas necessárias
echo "<h2>3. Verificando Tabelas Necessárias</h2>";

$tabelas_necessarias = [
    'contas' => 'Contas principais',
    'conta_membros' => 'Membros das contas',
    'conta_permissoes' => 'Permissões granulares',
    'conta_convites' => 'Convites para contas',
    'conta_logs' => 'Logs de auditoria',
    'usuarios' => 'Usuários do sistema'
];

foreach ($tabelas_necessarias as $tabela => $descricao) {
    try {
        $stmt = $pdo->query("SHOW TABLES LIKE '$tabela'");
        if ($stmt->rowCount() > 0) {
            $count = $pdo->query("SELECT COUNT(*) as total FROM $tabela")->fetch(PDO::FETCH_ASSOC)['total'];
            echo "✅ <strong>$tabela</strong> - $descricao ($count registros)<br>";
            $sucessos[] = "Tabela $tabela";
        } else {
            echo "❌ <strong>$tabela</strong> - $descricao (NÃO ENCONTRADA)<br>";
            $problemas[] = "Tabela $tabela";
        }
    } catch (Exception $e) {
        echo "❌ <strong>$tabela</strong> - Erro: " . $e->getMessage() . "<br>";
        $problemas[] = "Tabela $tabela";
    }
}

// 4. Verificar usuário admin
echo "<h2>4. Verificando Usuário Admin</h2>";

try {
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM usuarios WHERE tipo = 'admin'");
    $admin_count = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    if ($admin_count > 0) {
        echo "✅ Usuário admin encontrado ($admin_count usuário(s))<br>";
        $sucessos[] = 'Usuário admin';
    } else {
        echo "❌ Nenhum usuário admin encontrado<br>";
        $problemas[] = 'Usuário admin';
    }
} catch (Exception $e) {
    echo "❌ Erro ao verificar usuário admin: " . $e->getMessage() . "<br>";
    $problemas[] = 'Usuário admin';
}

// 5. Verificar contas
echo "<h2>5. Verificando Contas</h2>";

try {
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM contas");
    $contas_count = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    if ($contas_count > 0) {
        echo "✅ Contas encontradas ($contas_count conta(s))<br>";
        $sucessos[] = 'Contas';
    } else {
        echo "❌ Nenhuma conta encontrada<br>";
        $problemas[] = 'Contas';
    }
} catch (Exception $e) {
    echo "❌ Erro ao verificar contas: " . $e->getMessage() . "<br>";
    $problemas[] = 'Contas';
}

// 6. Verificar membros de contas
echo "<h2>6. Verificando Membros de Contas</h2>";

try {
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM conta_membros");
    $membros_count = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    if ($membros_count > 0) {
        echo "✅ Membros de contas encontrados ($membros_count membro(s))<br>";
        $sucessos[] = 'Membros de contas';
    } else {
        echo "❌ Nenhum membro de conta encontrado<br>";
        $problemas[] = 'Membros de contas';
    }
} catch (Exception $e) {
    echo "❌ Erro ao verificar membros de contas: " . $e->getMessage() . "<br>";
    $problemas[] = 'Membros de contas';
}

// 7. Verificar estrutura do banco
echo "<h2>7. Verificando Estrutura do Banco</h2>";

try {
    // Verificar se as foreign keys estão funcionando
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM conta_membros cm JOIN contas c ON cm.conta_id = c.id");
    $relacionamentos_count = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    if ($relacionamentos_count > 0) {
        echo "✅ Relacionamentos funcionando ($relacionamentos_count relacionamento(s))<br>";
        $sucessos[] = 'Relacionamentos';
    } else {
        echo "❌ Problema nos relacionamentos<br>";
        $problemas[] = 'Relacionamentos';
    }
} catch (Exception $e) {
    echo "❌ Erro ao verificar relacionamentos: " . $e->getMessage() . "<br>";
    $problemas[] = 'Relacionamentos';
}

// 8. Verificar permissões de arquivos
echo "<h2>8. Verificando Permissões de Arquivos</h2>";

$arquivos_verificar = [
    'gestao_contas_unificada.php',
    'login.php',
    'logout.php',
    'templates/header.php',
    'includes/db_connect.php',
    'includes/load_menu_config.php'
];

foreach ($arquivos_verificar as $arquivo) {
    if (file_exists($arquivo)) {
        if (is_readable($arquivo)) {
            echo "✅ <strong>$arquivo</strong> - Legível<br>";
            $sucessos[] = "Permissão $arquivo";
        } else {
            echo "❌ <strong>$arquivo</strong> - Não legível<br>";
            $problemas[] = "Permissão $arquivo";
        }
    }
}

// 9. Verificar sintaxe PHP
echo "<h2>9. Verificando Sintaxe PHP</h2>";

$arquivos_php = [
    'gestao_contas_unificada.php',
    'login.php',
    'logout.php',
    'templates/header.php',
    'includes/db_connect.php',
    'includes/load_menu_config.php'
];

foreach ($arquivos_php as $arquivo) {
    if (file_exists($arquivo)) {
        $output = shell_exec("php -l $arquivo 2>&1");
        if (strpos($output, 'No syntax errors') !== false) {
            echo "✅ <strong>$arquivo</strong> - Sintaxe OK<br>";
            $sucessos[] = "Sintaxe $arquivo";
        } else {
            echo "❌ <strong>$arquivo</strong> - Erro de sintaxe: $output<br>";
            $problemas[] = "Sintaxe $arquivo";
        }
    }
}

// 10. Resumo final
echo "<h2>10. Resumo Final</h2>";

$total_sucessos = count($sucessos);
$total_problemas = count($problemas);

echo "<div style='background: #d4edda; padding: 15px; border: 1px solid #c3e6cb; border-radius: 5px; margin: 10px 0;'>";
echo "<h3>✅ SUCESSOS ($total_sucessos)</h3>";
echo "<ul>";
foreach ($sucessos as $sucesso) {
    echo "<li>✅ $sucesso</li>";
}
echo "</ul>";
echo "</div>";

if ($total_problemas > 0) {
    echo "<div style='background: #f8d7da; padding: 15px; border: 1px solid #f5c6cb; border-radius: 5px; margin: 10px 0;'>";
    echo "<h3>❌ PROBLEMAS ($total_problemas)</h3>";
    echo "<ul>";
    foreach ($problemas as $problema) {
        echo "<li>❌ $problema</li>";
    }
    echo "</ul>";
    echo "</div>";
}

// 11. Recomendações
echo "<h2>11. Recomendações</h2>";

if ($total_problemas == 0) {
    echo "<div style='background: #d1ecf1; padding: 15px; border: 1px solid #bee5eb; border-radius: 5px; margin: 10px 0;'>";
    echo "<h3>🎉 SISTEMA PRONTO PARA USO!</h3>";
    echo "<p>Todos os arquivos estão corretos e o sistema de gestão de contas está funcionando.</p>";
    echo "<p><strong>Próximos passos:</strong></p>";
    echo "<ol>";
    echo "<li>🔗 Acesse <strong>gestao_contas_unificada.php</strong></li>";
    echo "<li>👤 Faça login com as credenciais do admin</li>";
    echo "<li>🏢 Teste as funcionalidades de gestão de contas</li>";
    echo "</ol>";
    echo "</div>";
} else {
    echo "<div style='background: #fff3cd; padding: 15px; border: 1px solid #ffeaa7; border-radius: 5px; margin: 10px 0;'>";
    echo "<h3>⚠️ SISTEMA PRECISA DE CORREÇÕES</h3>";
    echo "<p>Há $total_problemas problema(s) que precisam ser corrigidos.</p>";
    echo "<p><strong>Soluções:</strong></p>";
    echo "<ol>";
    echo "<li>🔧 Execute <strong>criar_tabelas_gestao_completa.php</strong> para criar as tabelas</li>";
    echo "<li>👤 Verifique se o usuário admin foi criado</li>";
    echo "<li>🔗 Verifique se todos os arquivos existem</li>";
    echo "<li>📋 Verifique as permissões dos arquivos</li>";
    echo "</ol>";
    echo "</div>";
}

echo "<hr>";
echo "<p><strong>📅 Data/Hora:</strong> " . date('d/m/Y H:i:s') . "</p>";
echo "<p><strong>🔧 Script:</strong> verificar_arquivos_gestao.php</p>";
echo "<p><strong>📋 Versão:</strong> 1.0</p>";
?>

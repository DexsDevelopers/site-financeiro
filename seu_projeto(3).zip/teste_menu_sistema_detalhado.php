<?php
// teste_menu_sistema_detalhado.php - Teste detalhado do menu do sistema

session_start();
require_once 'includes/db_connect.php';
require_once 'includes/load_menu_config.php';

echo "<h2>🧪 TESTE DETALHADO DO MENU DO SISTEMA</h2>";

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    echo "❌ Usuário não está logado. Faça login primeiro.<br>";
    echo "<a href='login.php' class='btn btn-primary'>Fazer Login</a><br><br>";
    exit();
}

$userId = $_SESSION['user_id'];
echo "✅ Usuário logado: ID $userId<br><br>";

// 1. Verificar configuração do menu
echo "<h3>1. Verificando Configuração do Menu</h3>";

if (isset($menu_config)) {
    echo "✅ Configuração do menu carregada<br>";
    
    // Verificar seções visíveis
    if (isset($menu_config['secoes_visiveis'])) {
        echo "📋 Seções visíveis:<br>";
        foreach ($menu_config['secoes_visiveis'] as $secao => $visivel) {
            $status = $visivel ? '✅' : '❌';
            echo "$status $secao: " . ($visivel ? 'VISÍVEL' : 'OCULTA') . "<br>";
        }
    }
    
    // Verificar páginas do sistema
    if (isset($menu_config['paginas_visiveis']['sistema'])) {
        echo "<br>📄 Páginas do sistema:<br>";
        foreach ($menu_config['paginas_visiveis']['sistema'] as $pagina) {
            echo "&nbsp;&nbsp;- $pagina<br>";
        }
    }
} else {
    echo "❌ Configuração do menu não carregada<br>";
}

echo "<hr>";

// 2. Verificar seções e páginas
echo "<h3>2. Verificando Seções e Páginas</h3>";

if (isset($secoesPaginas)) {
    echo "✅ Seções e páginas carregadas<br>";
    
    foreach ($secoesPaginas as $secao => $paginas) {
        echo "<br><strong>$secao:</strong><br>";
        foreach ($paginas as $pagina) {
            echo "&nbsp;&nbsp;- $pagina<br>";
        }
    }
} else {
    echo "❌ Seções e páginas não carregadas<br>";
}

echo "<hr>";

// 3. Verificar informações das seções
echo "<h3>3. Verificando Informações das Seções</h3>";

if (isset($secoesInfo)) {
    echo "✅ Informações das seções carregadas<br>";
    
    foreach ($secoesInfo as $secao => $info) {
        echo "<br><strong>$secao:</strong><br>";
        echo "&nbsp;&nbsp;- Nome: {$info['nome']}<br>";
        echo "&nbsp;&nbsp;- Ícone: {$info['icone']}<br>";
        echo "&nbsp;&nbsp;- Cor: {$info['cor']}<br>";
    }
} else {
    echo "❌ Informações das seções não carregadas<br>";
}

echo "<hr>";

// 4. Verificar informações das páginas
echo "<h3>4. Verificando Informações das Páginas</h3>";

if (isset($paginasInfo)) {
    echo "✅ Informações das páginas carregadas<br>";
    
    $paginasSistema = array_filter($paginasInfo, function($key) {
        return in_array($key, ['gestao_contas.php', 'configurar_permissoes.php', 'logs_atividades.php', 'perfil.php']);
    }, ARRAY_FILTER_USE_KEY);
    
    if (!empty($paginasSistema)) {
        echo "<br>📄 Páginas do sistema encontradas:<br>";
        foreach ($paginasSistema as $pagina => $info) {
            echo "&nbsp;&nbsp;- $pagina: {$info['nome']} ({$info['icone']})<br>";
        }
    } else {
        echo "❌ Páginas do sistema não encontradas<br>";
    }
} else {
    echo "❌ Informações das páginas não carregadas<br>";
}

echo "<hr>";

// 5. Verificar seção ativa
echo "<h3>5. Verificando Seção Ativa</h3>";

if (isset($secaoAtiva)) {
    echo "✅ Seção ativa: $secaoAtiva<br>";
} else {
    echo "❌ Seção ativa não definida<br>";
}

echo "<hr>";

// 6. Teste de renderização do menu
echo "<h3>6. Teste de Renderização do Menu</h3>";

echo "<div style='background: #f8f9fa; padding: 1rem; border-radius: 8px; margin: 1rem 0;'>";
echo "<h6>Estrutura do Menu que seria renderizada:</h6>";

if (isset($secoesPaginas) && isset($secoesInfo)) {
    foreach ($secoesPaginas as $secao => $paginas) {
        if (!empty($paginas) && isset($secoesInfo[$secao])) {
            $info = $secoesInfo[$secao];
            echo "<div style='margin: 0.5rem 0; padding: 0.5rem; background: white; border-radius: 4px;'>";
            echo "<strong><i class='bi {$info['icone']}' style='color: {$info['cor']};'></i> {$info['nome']}</strong><br>";
            
            foreach ($paginas as $pagina) {
                if (isset($paginasInfo[$pagina])) {
                    $paginaInfo = $paginasInfo[$pagina];
                    echo "&nbsp;&nbsp;• <i class='bi {$paginaInfo['icone']}'></i> {$paginaInfo['nome']} ($pagina)<br>";
                }
            }
            echo "</div>";
        }
    }
} else {
    echo "❌ Dados necessários não carregados<br>";
}

echo "</div>";

echo "<hr>";

// 7. Verificar se a seção sistema está presente
echo "<h3>7. Verificando Seção Sistema</h3>";

$sistemaPresente = false;

if (isset($secoesPaginas['sistema'])) {
    echo "✅ Seção 'sistema' encontrada em secoesPaginas<br>";
    $sistemaPresente = true;
} else {
    echo "❌ Seção 'sistema' NÃO encontrada em secoesPaginas<br>";
}

if (isset($secoesInfo['sistema'])) {
    echo "✅ Seção 'sistema' encontrada em secoesInfo<br>";
    $sistemaPresente = true;
} else {
    echo "❌ Seção 'sistema' NÃO encontrada em secoesInfo<br>";
}

if (isset($menu_config['secoes_visiveis']['sistema']) && $menu_config['secoes_visiveis']['sistema']) {
    echo "✅ Seção 'sistema' está marcada como visível<br>";
    $sistemaPresente = true;
} else {
    echo "❌ Seção 'sistema' NÃO está marcada como visível<br>";
}

echo "<hr>";

// 8. Resumo final
echo "<h2>📊 RESUMO FINAL</h2>";

if ($sistemaPresente) {
    echo "<div style='background: #d4edda; padding: 1rem; border-radius: 8px; margin: 1rem 0;'>";
    echo "<h4>✅ Seção Sistema Encontrada!</h4>";
    echo "<p>A seção 'Sistema' está configurada corretamente. Se não está aparecendo no menu, pode ser um problema de cache ou renderização.</p>";
    echo "<p><strong>Soluções:</strong></p>";
    echo "<ul>";
    echo "<li>Limpe o cache do navegador</li>";
    echo "<li>Recarregue a página (Ctrl+F5)</li>";
    echo "<li>Verifique se há erros JavaScript no console</li>";
    echo "<li>Teste em uma aba anônima</li>";
    echo "</ul>";
    echo "</div>";
} else {
    echo "<div style='background: #f8d7da; padding: 1rem; border-radius: 8px; margin: 1rem 0;'>";
    echo "<h4>❌ Seção Sistema NÃO Encontrada</h4>";
    echo "<p>A seção 'Sistema' não está sendo carregada corretamente. Execute o script de correção:</p>";
    echo "<p><a href='corrigir_sistema_gestao.php' class='btn btn-primary'>Corrigir Sistema</a></p>";
    echo "</div>";
}

echo "<hr>";
echo "<p><strong>✅ Teste concluído!</strong> Use as recomendações acima para resolver o problema.</p>";
?>

package main

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"strconv"
	"time"

	"github.com/gorilla/mux"
	"github.com/gorilla/handlers"
	_ "github.com/go-sql-driver/mysql"
	"github.com/golang-jwt/jwt/v5"
	"golang.org/x/crypto/bcrypt"
)

// Estruturas de dados
type Conta struct {
	ID          int       `json:"id"`
	Nome        string    `json:"nome"`
	Descricao   string    `json:"descricao"`
	CodigoConta string    `json:"codigo_conta"`
	Tipo        string    `json:"tipo"`
	Status      string    `json:"status"`
	DataCriacao time.Time `json:"data_criacao"`
	Papel       string    `json:"papel"`
}

type Membro struct {
	ID         int       `json:"id"`
	ContaID    int       `json:"conta_id"`
	UsuarioID  int       `json:"usuario_id"`
	Papel      string    `json:"papel"`
	Status     string    `json:"status"`
	DataConvite time.Time `json:"data_convite"`
	DataAceite *time.Time `json:"data_aceite"`
}

type Usuario struct {
	ID           int    `json:"id"`
	Usuario      string `json:"usuario"`
	NomeCompleto string `json:"nome_completo"`
	Email        string `json:"email"`
	Tipo         string `json:"tipo"`
}

type LoginRequest struct {
	Usuario string `json:"usuario"`
	Senha   string `json:"senha"`
}

type LoginResponse struct {
	Success bool   `json:"success"`
	Token   string `json:"token"`
	User    Usuario `json:"user"`
}

type ApiResponse struct {
	Success bool        `json:"success"`
	Data    interface{} `json:"data,omitempty"`
	Error   string      `json:"error,omitempty"`
	Message string      `json:"message,omitempty"`
}

type SistemaGestaoGo struct {
	db *sql.DB
}

func NewSistemaGestaoGo() *SistemaGestaoGo {
	// Configuração do banco de dados
	dsn := "u853242961_user7:Lucastav8012@@tcp(localhost:3306)/u853242961_financeiro?charset=utf8mb4&parseTime=true"
	
	db, err := sql.Open("mysql", dsn)
	if err != nil {
		log.Fatal("Erro ao conectar banco:", err)
	}

	// Testar conexão
	if err := db.Ping(); err != nil {
		log.Fatal("Erro ao testar conexão:", err)
	}

	// Configurar pool de conexões
	db.SetMaxOpenConns(25)
	db.SetMaxIdleConns(25)
	db.SetConnMaxLifetime(5 * time.Minute)

	return &SistemaGestaoGo{db: db}
}

func (s *SistemaGestaoGo) Close() {
	s.db.Close()
}

// Middleware de autenticação JWT
func (s *SistemaGestaoGo) authenticateToken(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		authHeader := r.Header.Get("Authorization")
		if authHeader == "" {
			http.Error(w, "Token de acesso necessário", http.StatusUnauthorized)
			return
		}

		tokenString := authHeader[7:] // Remove "Bearer "
		
		token, err := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
			return []byte("sua-chave-secreta"), nil
		})

		if err != nil || !token.Valid {
			http.Error(w, "Token inválido", http.StatusForbidden)
			return
		}

		claims := token.Claims.(jwt.MapClaims)
		r.Header.Set("User-ID", fmt.Sprintf("%.0f", claims["id"]))
		r.Header.Set("User-Tipo", fmt.Sprintf("%v", claims["tipo"]))

		next(w, r)
	}
}

// Handlers de autenticação
func (s *SistemaGestaoGo) loginHandler(w http.ResponseWriter, r *http.Request) {
	var req LoginRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Erro ao decodificar JSON", http.StatusBadRequest)
		return
	}

	// Buscar usuário no banco
	var user Usuario
	var senhaHash string
	
	err := s.db.QueryRow(`
		SELECT id, usuario, senha_hash, nome_completo, email, tipo 
		FROM usuarios 
		WHERE usuario = ?
	`, req.Usuario).Scan(&user.ID, &user.Usuario, &senhaHash, &user.NomeCompleto, &user.Email, &user.Tipo)

	if err != nil {
		json.NewEncoder(w).Encode(ApiResponse{
			Success: false,
			Error:   "Credenciais inválidas",
		})
		return
	}

	// Verificar senha
	if err := bcrypt.CompareHashAndPassword([]byte(senhaHash), []byte(req.Senha)); err != nil {
		json.NewEncoder(w).Encode(ApiResponse{
			Success: false,
			Error:   "Credenciais inválidas",
		})
		return
	}

	// Gerar token JWT
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		"id":      user.ID,
		"usuario": user.Usuario,
		"tipo":    user.Tipo,
		"exp":     time.Now().Add(time.Hour * 24).Unix(),
	})

	tokenString, err := token.SignedString([]byte("sua-chave-secreta"))
	if err != nil {
		http.Error(w, "Erro ao gerar token", http.StatusInternalServerError)
		return
	}

	response := LoginResponse{
		Success: true,
		Token:   tokenString,
		User:    user,
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}

// Handlers de contas
func (s *SistemaGestaoGo) getContasHandler(w http.ResponseWriter, r *http.Request) {
	userID := r.Header.Get("User-ID")
	
	rows, err := s.db.Query(`
		SELECT 
			c.id, c.nome, c.descricao, c.codigo_conta, c.tipo, c.status, c.data_criacao,
			cm.papel
		FROM contas c
		JOIN conta_membros cm ON c.id = cm.conta_id
		WHERE cm.usuario_id = ? AND cm.status = 'ativo'
		ORDER BY c.data_criacao DESC
	`, userID)

	if err != nil {
		http.Error(w, "Erro ao buscar contas", http.StatusInternalServerError)
		return
	}
	defer rows.Close()

	var contas []Conta
	for rows.Next() {
		var conta Conta
		err := rows.Scan(
			&conta.ID, &conta.Nome, &conta.Descricao, &conta.CodigoConta,
			&conta.Tipo, &conta.Status, &conta.DataCriacao, &conta.Papel,
		)
		if err != nil {
			log.Printf("Erro ao escanear conta: %v", err)
			continue
		}
		contas = append(contas, conta)
	}

	response := ApiResponse{
		Success: true,
		Data:    contas,
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}

func (s *SistemaGestaoGo) createContaHandler(w http.ResponseWriter, r *http.Request) {
	userID := r.Header.Get("User-ID")
	
	var conta struct {
		Nome      string `json:"nome"`
		Descricao string `json:"descricao"`
		Tipo      string `json:"tipo"`
	}

	if err := json.NewDecoder(r.Body).Decode(&conta); err != nil {
		http.Error(w, "Erro ao decodificar JSON", http.StatusBadRequest)
		return
	}

	// Gerar código único
	codigoConta := fmt.Sprintf("CONTA-%d", time.Now().Unix())
	
	// Iniciar transação
	tx, err := s.db.Begin()
	if err != nil {
		http.Error(w, "Erro ao iniciar transação", http.StatusInternalServerError)
		return
	}

	// Criar conta
	result, err := tx.Exec(`
		INSERT INTO contas (nome, descricao, codigo_conta, tipo, criado_por) 
		VALUES (?, ?, ?, ?, ?)
	`, conta.Nome, conta.Descricao, codigoConta, conta.Tipo, userID)

	if err != nil {
		tx.Rollback()
		http.Error(w, "Erro ao criar conta", http.StatusInternalServerError)
		return
	}

	contaID, _ := result.LastInsertId()

	// Adicionar criador como proprietário
	_, err = tx.Exec(`
		INSERT INTO conta_membros (conta_id, usuario_id, papel, status, data_aceite) 
		VALUES (?, ?, 'proprietario', 'ativo', NOW())
	`, contaID, userID)

	if err != nil {
		tx.Rollback()
		http.Error(w, "Erro ao adicionar membro", http.StatusInternalServerError)
		return
	}

	// Log da ação
	_, err = tx.Exec(`
		INSERT INTO conta_logs (conta_id, usuario_id, acao, modulo, descricao) 
		VALUES (?, ?, 'criar_conta', 'sistema', ?)
	`, contaID, userID, fmt.Sprintf("Conta \"%s\" criada", conta.Nome))

	if err != nil {
		tx.Rollback()
		http.Error(w, "Erro ao criar log", http.StatusInternalServerError)
		return
	}

	if err := tx.Commit(); err != nil {
		http.Error(w, "Erro ao confirmar transação", http.StatusInternalServerError)
		return
	}

	response := ApiResponse{
		Success: true,
		Data:    map[string]interface{}{"id": contaID, "nome": conta.Nome},
		Message: "Conta criada com sucesso",
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}

func (s *SistemaGestaoGo) updateContaHandler(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	contaID := vars["id"]
	userID := r.Header.Get("User-ID")

	// Verificar permissão
	var papel string
	err := s.db.QueryRow(`
		SELECT papel FROM conta_membros 
		WHERE conta_id = ? AND usuario_id = ? AND status = 'ativo'
	`, contaID, userID).Scan(&papel)

	if err != nil || (papel != "proprietario" && papel != "administrador") {
		http.Error(w, "Sem permissão para editar esta conta", http.StatusForbidden)
		return
	}

	var updateData struct {
		Nome      string `json:"nome"`
		Descricao string `json:"descricao"`
		Tipo      string `json:"tipo"`
		Status    string `json:"status"`
	}

	if err := json.NewDecoder(r.Body).Decode(&updateData); err != nil {
		http.Error(w, "Erro ao decodificar JSON", http.StatusBadRequest)
		return
	}

	_, err = s.db.Exec(`
		UPDATE contas 
		SET nome = ?, descricao = ?, tipo = ?, status = ? 
		WHERE id = ?
	`, updateData.Nome, updateData.Descricao, updateData.Tipo, updateData.Status, contaID)

	if err != nil {
		http.Error(w, "Erro ao atualizar conta", http.StatusInternalServerError)
		return
	}

	// Log da ação
	s.db.Exec(`
		INSERT INTO conta_logs (conta_id, usuario_id, acao, modulo, descricao) 
		VALUES (?, ?, 'editar_conta', 'sistema', ?)
	`, contaID, userID, fmt.Sprintf("Conta \"%s\" editada", updateData.Nome))

	response := ApiResponse{
		Success: true,
		Message: "Conta atualizada com sucesso",
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}

func (s *SistemaGestaoGo) deleteContaHandler(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	contaID := vars["id"]
	userID := r.Header.Get("User-ID")

	// Verificar se é proprietário
	var papel string
	err := s.db.QueryRow(`
		SELECT papel FROM conta_membros 
		WHERE conta_id = ? AND usuario_id = ? AND status = 'ativo'
	`, contaID, userID).Scan(&papel)

	if err != nil || papel != "proprietario" {
		http.Error(w, "Apenas o proprietário pode excluir a conta", http.StatusForbidden)
		return
	}

	_, err = s.db.Exec("DELETE FROM contas WHERE id = ?", contaID)
	if err != nil {
		http.Error(w, "Erro ao excluir conta", http.StatusInternalServerError)
		return
	}

	response := ApiResponse{
		Success: true,
		Message: "Conta excluída com sucesso",
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}

// Handlers de membros
func (s *SistemaGestaoGo) getMembrosHandler(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	contaID := vars["id"]

	rows, err := s.db.Query(`
		SELECT 
			cm.id, cm.conta_id, cm.usuario_id, cm.papel, cm.status, 
			cm.data_convite, cm.data_aceite,
			u.usuario, u.nome_completo, u.email
		FROM conta_membros cm
		JOIN usuarios u ON cm.usuario_id = u.id
		WHERE cm.conta_id = ?
		ORDER BY cm.data_convite DESC
	`, contaID)

	if err != nil {
		http.Error(w, "Erro ao buscar membros", http.StatusInternalServerError)
		return
	}
	defer rows.Close()

	var membros []map[string]interface{}
	for rows.Next() {
		var membro Membro
		var usuario, nomeCompleto, email string
		
		err := rows.Scan(
			&membro.ID, &membro.ContaID, &membro.UsuarioID, &membro.Papel, &membro.Status,
			&membro.DataConvite, &membro.DataAceite, &usuario, &nomeCompleto, &email,
		)
		if err != nil {
			log.Printf("Erro ao escanear membro: %v", err)
			continue
		}

		membroData := map[string]interface{}{
			"id":            membro.ID,
			"conta_id":      membro.ContaID,
			"usuario_id":    membro.UsuarioID,
			"papel":         membro.Papel,
			"status":        membro.Status,
			"data_convite":  membro.DataConvite,
			"data_aceite":   membro.DataAceite,
			"usuario":       usuario,
			"nome_completo": nomeCompleto,
			"email":         email,
		}
		membros = append(membros, membroData)
	}

	response := ApiResponse{
		Success: true,
		Data:    membros,
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}

func (s *SistemaGestaoGo) addMembroHandler(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	contaID := vars["id"]
	userID := r.Header.Get("User-ID")

	// Verificar permissão
	var papel string
	err := s.db.QueryRow(`
		SELECT papel FROM conta_membros 
		WHERE conta_id = ? AND usuario_id = ? AND status = 'ativo'
	`, contaID, userID).Scan(&papel)

	if err != nil || (papel != "proprietario" && papel != "administrador") {
		http.Error(w, "Sem permissão para adicionar membros", http.StatusForbidden)
		return
	}

	var membroData struct {
		UsuarioID int    `json:"usuario_id"`
		Papel     string `json:"papel"`
	}

	if err := json.NewDecoder(r.Body).Decode(&membroData); err != nil {
		http.Error(w, "Erro ao decodificar JSON", http.StatusBadRequest)
		return
	}

	_, err = s.db.Exec(`
		INSERT INTO conta_membros (conta_id, usuario_id, papel, status, data_aceite, convidado_por) 
		VALUES (?, ?, ?, 'ativo', NOW(), ?)
	`, contaID, membroData.UsuarioID, membroData.Papel, userID)

	if err != nil {
		http.Error(w, "Erro ao adicionar membro", http.StatusInternalServerError)
		return
	}

	response := ApiResponse{
		Success: true,
		Message: "Membro adicionado com sucesso",
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}

// Handlers de convites
func (s *SistemaGestaoGo) convidarMembroHandler(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	contaID := vars["id"]
	userID := r.Header.Get("User-ID")

	var conviteData struct {
		Email string `json:"email"`
		Papel string `json:"papel"`
	}

	if err := json.NewDecoder(r.Body).Decode(&conviteData); err != nil {
		http.Error(w, "Erro ao decodificar JSON", http.StatusBadRequest)
		return
	}

	codigoConvite := fmt.Sprintf("CONV-%d-%s", time.Now().Unix(), generateRandomString(9))
	dataExpiracao := time.Now().Add(7 * 24 * time.Hour) // 7 dias

	_, err := s.db.Exec(`
		INSERT INTO conta_convites (conta_id, email, codigo_convite, papel, data_expiracao, convidado_por) 
		VALUES (?, ?, ?, ?, ?, ?)
	`, contaID, conviteData.Email, codigoConvite, conviteData.Papel, dataExpiracao, userID)

	if err != nil {
		http.Error(w, "Erro ao criar convite", http.StatusInternalServerError)
		return
	}

	response := ApiResponse{
		Success: true,
		Data: map[string]interface{}{
			"codigo_convite":  codigoConvite,
			"email":           conviteData.Email,
			"data_expiracao":  dataExpiracao,
		},
		Message: "Convite criado com sucesso",
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}

// Health check
func (s *SistemaGestaoGo) healthCheckHandler(w http.ResponseWriter, r *http.Request) {
	// Verificar conexão com banco
	if err := s.db.Ping(); err != nil {
		http.Error(w, "Erro de conexão com banco", http.StatusServiceUnavailable)
		return
	}

	response := map[string]interface{}{
		"status":    "ok",
		"timestamp": time.Now().Format(time.RFC3339),
		"service":   "gestao-contas-go",
		"version":   "1.0.0",
		"database":  "connected",
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}

// Função auxiliar para gerar string aleatória
func generateRandomString(length int) string {
	const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	b := make([]byte, length)
	for i := range b {
		b[i] = charset[time.Now().UnixNano()%int64(len(charset))]
	}
	return string(b)
}

func main() {
	// Criar instância do sistema
	sistema := NewSistemaGestaoGo()
	defer sistema.Close()

	// Configurar roteador
	r := mux.NewRouter()

	// Rotas de autenticação
	r.HandleFunc("/auth/login", sistema.loginHandler).Methods("POST")

	// Rotas de contas (com autenticação)
	r.HandleFunc("/api/contas", sistema.authenticateToken(sistema.getContasHandler)).Methods("GET")
	r.HandleFunc("/api/contas", sistema.authenticateToken(sistema.createContaHandler)).Methods("POST")
	r.HandleFunc("/api/contas/{id}", sistema.authenticateToken(sistema.updateContaHandler)).Methods("PUT")
	r.HandleFunc("/api/contas/{id}", sistema.authenticateToken(sistema.deleteContaHandler)).Methods("DELETE")

	// Rotas de membros
	r.HandleFunc("/api/contas/{id}/membros", sistema.authenticateToken(sistema.getMembrosHandler)).Methods("GET")
	r.HandleFunc("/api/contas/{id}/membros", sistema.authenticateToken(sistema.addMembroHandler)).Methods("POST")

	// Rotas de convites
	r.HandleFunc("/api/contas/{id}/convidar", sistema.authenticateToken(sistema.convidarMembroHandler)).Methods("POST")

	// Health check
	r.HandleFunc("/health", sistema.healthCheckHandler).Methods("GET")

	// Configurar CORS
	c := handlers.CORS(
		handlers.AllowedOrigins([]string{"*"}),
		handlers.AllowedMethods([]string{"GET", "POST", "PUT", "DELETE", "OPTIONS"}),
		handlers.AllowedHeaders([]string{"Content-Type", "Authorization"}),
	)

	// Configurar servidor
	server := &http.Server{
		Addr:         ":8080",
		Handler:      c(r),
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 15 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	fmt.Println("🚀 Servidor Go rodando na porta 8080")
	fmt.Println("📡 API disponível em: http://localhost:8080")
	fmt.Println("🔍 Health check: http://localhost:8080/health")
	fmt.Println("🔐 Autenticação: POST /auth/login")
	fmt.Println("📋 Contas: GET /api/contas")

	log.Fatal(server.ListenAndServe())
}

<?php
// logs_atividades_simples.php - Versão simplificada para logs de atividades

session_start();
require_once 'includes/db_connect.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$userId = $_SESSION['user_id'];

// Buscar contas do usuário
try {
    $stmt = $pdo->prepare("
        SELECT 
            c.*,
            cm.papel,
            cm.status as status_membro
        FROM contas c
        JOIN conta_membros cm ON c.id = cm.conta_id
        WHERE cm.usuario_id = ? AND cm.status = 'ativo'
        ORDER BY c.data_criacao DESC
    ");
    $stmt->execute([$userId]);
    $contas = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $contas = [];
}

// Buscar logs da conta ativa
$logs = [];
$contaAtiva = null;
$filtros = [
    'conta_id' => $_GET['conta_id'] ?? null,
    'modulo' => $_GET['modulo'] ?? null,
    'acao' => $_GET['acao'] ?? null,
    'data_inicio' => $_GET['data_inicio'] ?? null,
    'data_fim' => $_GET['data_fim'] ?? null,
    'usuario_id' => $_GET['usuario_id'] ?? null
];

if ($filtros['conta_id']) {
    $contaId = (int)$filtros['conta_id'];
    
    try {
        // Verificar se o usuário tem acesso à conta
        $stmt = $pdo->prepare("
            SELECT cm.papel 
            FROM conta_membros cm 
            WHERE cm.conta_id = ? AND cm.usuario_id = ? AND cm.status = 'ativo'
        ");
        $stmt->execute([$contaId, $userId]);
        $membro = $stmt->fetch();
        
        if ($membro && in_array($membro['papel'], ['proprietario', 'administrador'])) {
            // Buscar logs da conta
            $sql = "
                SELECT 
                    cl.*,
                    u.nome as nome_usuario,
                    c.nome as nome_conta
                FROM conta_logs cl
                LEFT JOIN usuarios u ON cl.usuario_id = u.id
                LEFT JOIN contas c ON cl.conta_id = c.id
                WHERE cl.conta_id = ?
            ";
            $params = [$contaId];
            
            // Aplicar filtros
            if ($filtros['modulo']) {
                $sql .= " AND cl.modulo = ?";
                $params[] = $filtros['modulo'];
            }
            
            if ($filtros['acao']) {
                $sql .= " AND cl.acao = ?";
                $params[] = $filtros['acao'];
            }
            
            if ($filtros['usuario_id']) {
                $sql .= " AND cl.usuario_id = ?";
                $params[] = $filtros['usuario_id'];
            }
            
            if ($filtros['data_inicio']) {
                $sql .= " AND DATE(cl.data_acao) >= ?";
                $params[] = $filtros['data_inicio'];
            }
            
            if ($filtros['data_fim']) {
                $sql .= " AND DATE(cl.data_acao) <= ?";
                $params[] = $filtros['data_fim'];
            }
            
            $sql .= " ORDER BY cl.data_acao DESC LIMIT 100";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Buscar informações da conta
            $stmt = $pdo->prepare("SELECT * FROM contas WHERE id = ?");
            $stmt->execute([$contaId]);
            $contaAtiva = $stmt->fetch(PDO::FETCH_ASSOC);
        }
    } catch (PDOException $e) {
        $logs = [];
    }
}

// Buscar usuários da conta para filtro
$usuariosConta = [];
if ($contaAtiva) {
    try {
        $stmt = $pdo->prepare("
            SELECT DISTINCT cl.usuario_id, u.nome
            FROM conta_logs cl
            LEFT JOIN usuarios u ON cl.usuario_id = u.id
            WHERE cl.conta_id = ?
            ORDER BY u.nome
        ");
        $stmt->execute([$contaAtiva['id']]);
        $usuariosConta = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $usuariosConta = [];
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logs de Atividades - Painel Financeiro</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    
    <style>
        body {
            background: linear-gradient(135deg, #0c0c0c 0%, #1a1a1a 100%);
            color: #ffffff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .card-glass {
            background: rgba(30, 30, 30, 0.8);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 15px;
        }
        
        .btn-primary {
            background: linear-gradient(45deg, #e50914, #ff6b6b);
            border: none;
            border-radius: 8px;
            padding: 0.75rem 1.5rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(229, 9, 20, 0.3);
        }
        
        .log-item {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            padding: 1rem;
            margin-bottom: 1rem;
        }
        
        .badge-modulo {
            font-size: 0.8rem;
            padding: 0.4rem 0.8rem;
            border-radius: 15px;
        }
        
        .badge-financeiro { background: linear-gradient(45deg, #fd7e14, #e8590c); }
        .badge-produtividade { background: linear-gradient(45deg, #0d6efd, #0b5ed7); }
        .badge-academy { background: linear-gradient(45deg, #198754, #146c43); }
        .badge-sistema { background: linear-gradient(45deg, #6c757d, #5a6268); }
        
        .table-dark {
            --bs-table-bg: rgba(30, 30, 30, 0.8);
        }
        
        .table-dark th {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .table-dark td {
            border-color: rgba(255, 255, 255, 0.1);
        }
    </style>
</head>
<body>
    <?php include 'templates/header.php'; ?>
    
    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12">
                <!-- Header -->
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h2 class="text-white mb-0">
                            <i class="bi bi-journal-text me-2"></i>Logs de Atividades
                        </h2>
                        <p class="text-muted mb-0">Monitore todas as atividades do sistema</p>
                    </div>
                    <a href="gestao_contas.php" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-left me-2"></i>Voltar
                    </a>
                </div>
                
                <!-- Seleção de Conta -->
                <?php if (!empty($contas)): ?>
                <div class="card card-glass mb-4">
                    <div class="card-body">
                        <h5 class="card-title text-white">
                            <i class="bi bi-building me-2"></i>Selecionar Conta
                        </h5>
                        <div class="row">
                            <?php foreach ($contas as $conta): ?>
                            <div class="col-md-6 mb-3">
                                <div class="card log-item">
                                    <div class="card-body">
                                        <h6 class="card-title text-white"><?php echo htmlspecialchars($conta['nome']); ?></h6>
                                        <p class="card-text text-muted"><?php echo htmlspecialchars($conta['descricao'] ?? ''); ?></p>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <span class="badge bg-<?php echo $conta['papel'] === 'proprietario' ? 'danger' : ($conta['papel'] === 'administrador' ? 'warning' : 'primary'); ?>">
                                                <?php echo ucfirst($conta['papel']); ?>
                                            </span>
                                            <a href="?conta_id=<?php echo $conta['id']; ?>" 
                                               class="btn btn-sm btn-primary">
                                                <i class="bi bi-eye me-1"></i>Ver Logs
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- Filtros -->
                <?php if ($contaAtiva): ?>
                <div class="card card-glass mb-4">
                    <div class="card-header">
                        <h5 class="card-title text-white mb-0">
                            <i class="bi bi-funnel me-2"></i>Filtros
                        </h5>
                    </div>
                    <div class="card-body">
                        <form method="GET" action="">
                            <input type="hidden" name="conta_id" value="<?php echo $contaAtiva['id']; ?>">
                            <div class="row">
                                <div class="col-md-3 mb-3">
                                    <label for="modulo" class="form-label">Módulo</label>
                                    <select class="form-select" id="modulo" name="modulo">
                                        <option value="">Todos os módulos</option>
                                        <option value="financeiro" <?php echo $filtros['modulo'] === 'financeiro' ? 'selected' : ''; ?>>Financeiro</option>
                                        <option value="produtividade" <?php echo $filtros['modulo'] === 'produtividade' ? 'selected' : ''; ?>>Produtividade</option>
                                        <option value="academy" <?php echo $filtros['modulo'] === 'academy' ? 'selected' : ''; ?>>Academy</option>
                                        <option value="sistema" <?php echo $filtros['modulo'] === 'sistema' ? 'selected' : ''; ?>>Sistema</option>
                                    </select>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label for="acao" class="form-label">Ação</label>
                                    <select class="form-select" id="acao" name="acao">
                                        <option value="">Todas as ações</option>
                                        <option value="usuario_criado" <?php echo $filtros['acao'] === 'usuario_criado' ? 'selected' : ''; ?>>Usuário Criado</option>
                                        <option value="permissao_alterada" <?php echo $filtros['acao'] === 'permissao_alterada' ? 'selected' : ''; ?>>Permissão Alterada</option>
                                        <option value="membro_removido" <?php echo $filtros['acao'] === 'membro_removido' ? 'selected' : ''; ?>>Membro Removido</option>
                                        <option value="convite_aceito" <?php echo $filtros['acao'] === 'convite_aceito' ? 'selected' : ''; ?>>Convite Aceito</option>
                                        <option value="convite_recusado" <?php echo $filtros['acao'] === 'convite_recusado' ? 'selected' : ''; ?>>Convite Recusado</option>
                                    </select>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label for="usuario_id" class="form-label">Usuário</label>
                                    <select class="form-select" id="usuario_id" name="usuario_id">
                                        <option value="">Todos os usuários</option>
                                        <?php foreach ($usuariosConta as $usuario): ?>
                                        <option value="<?php echo $usuario['usuario_id']; ?>" 
                                                <?php echo $filtros['usuario_id'] == $usuario['usuario_id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($usuario['nome']); ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label for="data_inicio" class="form-label">Data Início</label>
                                    <input type="date" class="form-control" id="data_inicio" name="data_inicio" 
                                           value="<?php echo $filtros['data_inicio']; ?>">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3 mb-3">
                                    <label for="data_fim" class="form-label">Data Fim</label>
                                    <input type="date" class="form-control" id="data_fim" name="data_fim" 
                                           value="<?php echo $filtros['data_fim']; ?>">
                                </div>
                                <div class="col-md-9 mb-3 d-flex align-items-end">
                                    <button type="submit" class="btn btn-primary me-2">
                                        <i class="bi bi-search me-2"></i>Filtrar
                                    </button>
                                    <a href="?conta_id=<?php echo $contaAtiva['id']; ?>" class="btn btn-outline-secondary">
                                        <i class="bi bi-x-circle me-2"></i>Limpar
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- Logs -->
                <?php if ($contaAtiva): ?>
                <div class="card card-glass">
                    <div class="card-header">
                        <h5 class="card-title text-white mb-0">
                            <i class="bi bi-list-ul me-2"></i>Logs - <?php echo htmlspecialchars($contaAtiva['nome']); ?>
                            <span class="badge bg-primary ms-2"><?php echo count($logs); ?> registros</span>
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($logs)): ?>
                        <div class="table-responsive">
                            <table class="table table-dark table-hover">
                                <thead>
                                    <tr>
                                        <th>Data/Hora</th>
                                        <th>Usuário</th>
                                        <th>Módulo</th>
                                        <th>Ação</th>
                                        <th>Detalhes</th>
                                        <th>IP</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($logs as $log): ?>
                                    <tr>
                                        <td>
                                            <small><?php echo date('d/m/Y H:i:s', strtotime($log['data_acao'])); ?></small>
                                        </td>
                                        <td>
                                            <strong><?php echo htmlspecialchars($log['nome_usuario'] ?? 'Sistema'); ?></strong>
                                        </td>
                                        <td>
                                            <span class="badge badge-<?php echo $log['modulo']; ?> badge-modulo">
                                                <?php echo ucfirst($log['modulo']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <code><?php echo htmlspecialchars($log['acao']); ?></code>
                                        </td>
                                        <td>
                                            <small><?php echo htmlspecialchars($log['detalhes'] ?? ''); ?></small>
                                        </td>
                                        <td>
                                            <small><?php echo htmlspecialchars($log['ip_address'] ?? ''); ?></small>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php else: ?>
                        <div class="text-center py-5">
                            <i class="bi bi-journal-x text-muted" style="font-size: 3rem;"></i>
                            <h5 class="text-white mt-3">Nenhum Log Encontrado</h5>
                            <p class="text-muted">Não há registros de atividades para os filtros selecionados.</p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php else: ?>
                <div class="card card-glass">
                    <div class="card-body text-center">
                        <i class="bi bi-building text-muted" style="font-size: 3rem;"></i>
                        <h5 class="text-white mt-3">Selecione uma Conta</h5>
                        <p class="text-muted">Escolha uma conta para visualizar os logs de atividades.</p>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

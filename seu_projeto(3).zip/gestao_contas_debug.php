<?php
// gestao_contas_debug.php - Versão com debug para diagnosticar problema das contas

session_start();
require_once 'includes/db_connect.php';

// Ativar debug
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$userId = $_SESSION['user_id'];

echo "<h2>🔍 GESTÃO DE CONTAS - VERSÃO DEBUG</h2>";
echo "<p>Usuário ID: $userId</p>";

// Buscar contas do usuário
$contasUsuario = [];
$membrosContas = [];

try {
    echo "<h3>🔍 Buscando contas do usuário...</h3>";
    
    // Buscar contas onde o usuário é membro
    $stmt = $pdo->prepare("
        SELECT 
            c.*,
            cm.papel,
            cm.status as status_membro,
            u.nome as nome_proprietario
        FROM contas c
        JOIN conta_membros cm ON c.id = cm.conta_id
        LEFT JOIN usuarios u ON c.criado_por = u.id
        WHERE cm.usuario_id = ? AND cm.status = 'ativo'
        ORDER BY c.data_criacao DESC
    ");
    $stmt->execute([$userId]);
    $contasUsuario = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<p>✅ Consulta executada com sucesso</p>";
    echo "<p>📊 Contas encontradas: " . count($contasUsuario) . "</p>";
    
    if (!empty($contasUsuario)) {
        echo "<h4>📋 Contas do usuário:</h4>";
        foreach ($contasUsuario as $conta) {
            echo "<div style='background: #f8f9fa; padding: 10px; margin: 5px; border-radius: 5px;'>";
            echo "<strong>ID:</strong> {$conta['id']}<br>";
            echo "<strong>Nome:</strong> {$conta['nome']}<br>";
            echo "<strong>Descrição:</strong> {$conta['descricao']}<br>";
            echo "<strong>Tipo:</strong> {$conta['tipo']}<br>";
            echo "<strong>Papel:</strong> {$conta['papel']}<br>";
            echo "<strong>Status:</strong> {$conta['status_membro']}<br>";
            echo "<strong>Data Criação:</strong> {$conta['data_criacao']}<br>";
            echo "</div>";
        }
    } else {
        echo "<p>⚠️ Nenhuma conta encontrada para o usuário</p>";
        
        // Verificar se há contas no banco
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM contas");
        $totalContas = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
        echo "<p>📊 Total de contas no banco: $totalContas</p>";
        
        // Verificar se o usuário tem membros em alguma conta
        $stmt = $pdo->prepare("SELECT * FROM conta_membros WHERE usuario_id = ?");
        $stmt->execute([$userId]);
        $membrosUsuario = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo "<p>📊 Membros do usuário: " . count($membrosUsuario) . "</p>";
        
        if (!empty($membrosUsuario)) {
            echo "<h4>🔍 Membros do usuário:</h4>";
            foreach ($membrosUsuario as $membro) {
                echo "<div style='background: #fff3cd; padding: 10px; margin: 5px; border-radius: 5px;'>";
                echo "<strong>Conta ID:</strong> {$membro['conta_id']}<br>";
                echo "<strong>Papel:</strong> {$membro['papel']}<br>";
                echo "<strong>Status:</strong> {$membro['status']}<br>";
                echo "</div>";
            }
        }
    }
    
    // Buscar membros de cada conta
    foreach ($contasUsuario as $conta) {
        if (in_array($conta['papel'], ['proprietario', 'administrador'])) {
            $stmt = $pdo->prepare("
                SELECT 
                    cm.*,
                    u.nome,
                    u.email,
                    u.data_criacao as data_cadastro
                FROM conta_membros cm
                JOIN usuarios u ON cm.usuario_id = u.id
                WHERE cm.conta_id = ?
                ORDER BY cm.papel, u.nome
            ");
            $stmt->execute([$conta['id']]);
            $membrosContas[$conta['id']] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    }
    
} catch (PDOException $e) {
    echo "<p>❌ Erro na consulta: " . $e->getMessage() . "</p>";
    $contasUsuario = [];
    $membrosContas = [];
}

echo "<hr>";

// Formulário para criar nova conta
echo "<h3>➕ Criar Nova Conta</h3>";
echo "<form method='POST' action='criar_conta_simples.php' style='background: #e9ecef; padding: 20px; border-radius: 10px;'>";
echo "<div style='margin-bottom: 15px;'>";
echo "<label for='nome' style='display: block; margin-bottom: 5px;'><strong>Nome da Conta:</strong></label>";
echo "<input type='text' id='nome' name='nome' required style='width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;'>";
echo "</div>";
echo "<div style='margin-bottom: 15px;'>";
echo "<label for='descricao' style='display: block; margin-bottom: 5px;'><strong>Descrição:</strong></label>";
echo "<textarea id='descricao' name='descricao' rows='3' style='width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;'></textarea>";
echo "</div>";
echo "<div style='margin-bottom: 15px;'>";
echo "<label for='tipo' style='display: block; margin-bottom: 5px;'><strong>Tipo:</strong></label>";
echo "<select id='tipo' name='tipo' required style='width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;'>";
echo "<option value='Pessoal'>Pessoal</option>";
echo "<option value='Empresarial'>Empresarial</option>";
echo "<option value='Familia'>Família</option>";
echo "</select>";
echo "</div>";
echo "<button type='submit' style='background: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer;'>Criar Conta</button>";
echo "</form>";

echo "<hr>";

// Botões de teste
echo "<h3>🧪 Testes Disponíveis</h3>";
echo "<div style='margin: 10px 0;'>";
echo "<a href='diagnostico_contas.php' style='background: #28a745; color: white; padding: 10px 15px; text-decoration: none; border-radius: 4px; margin-right: 10px;'>🔍 Diagnóstico Completo</a>";
echo "<a href='teste_criar_conta.php' style='background: #17a2b8; color: white; padding: 10px 15px; text-decoration: none; border-radius: 4px; margin-right: 10px;'>🧪 Teste Criar Conta</a>";
echo "<a href='gestao_contas_unificada.php' style='background: #6c757d; color: white; padding: 10px 15px; text-decoration: none; border-radius: 4px;'>📱 Página Original</a>";
echo "</div>";

echo "<hr>";
echo "<p><strong>✅ Versão debug carregada!</strong> Use as informações acima para diagnosticar o problema.</p>";
?>

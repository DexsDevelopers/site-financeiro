<?php
// definir_conta_ativa.php - Definir conta ativa do usuário

session_start();
require_once 'includes/db_connect.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Acesso negado']);
    exit();
}

$userId = $_SESSION['user_id'];

// Verificar se é uma requisição POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit();
}

// Obter dados do POST
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['conta_id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'ID da conta não fornecido']);
    exit();
}

$contaId = (int)$input['conta_id'];

try {
    // Verificar se o usuário é membro da conta
    $stmt = $pdo->prepare("
        SELECT cm.id, c.nome 
        FROM conta_membros cm 
        JOIN contas c ON cm.conta_id = c.id
        WHERE cm.conta_id = ? AND cm.usuario_id = ? AND cm.status = 'ativo'
    ");
    $stmt->execute([$contaId, $userId]);
    $membro = $stmt->fetch();
    
    if (!$membro) {
        echo json_encode(['success' => false, 'message' => 'Você não é membro desta conta']);
        exit();
    }
    
    // Definir conta ativa na sessão
    $_SESSION['conta_ativa_id'] = $contaId;
    
    // Registrar log
    $stmt = $pdo->prepare("
        INSERT INTO conta_logs (conta_id, usuario_id, acao, modulo, detalhes) 
        VALUES (?, ?, 'conta_ativada', 'sistema', ?)
    ");
    $stmt->execute([$contaId, $userId, "Conta '{$membro['nome']}' ativada"]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Conta ativada com sucesso!',
        'conta_nome' => $membro['nome']
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao ativar conta: ' . $e->getMessage()
    ]);
}
?>

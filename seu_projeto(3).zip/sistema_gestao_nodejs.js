#!/usr/bin/env node
/**
 * sistema_gestao_nodejs.js
 * Sistema de Gestão de Contas - Node.js
 * Painel Financeiro Helmer - Versão Node.js
 */

const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
const helmet = require('helmet');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const Joi = require('joi');
const winston = require('winston');
const { createProxyMiddleware } = require('http-proxy-middleware');

// Configuração de logging
const logger = winston.createLogger({
    level: 'info',
    format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
    ),
    transports: [
        new winston.transports.File({ filename: 'logs/gestao-nodejs.log' }),
        new winston.transports.Console()
    ]
});

class SistemaGestaoNodeJS {
    constructor() {
        this.app = express();
        this.port = process.env.PORT || 3000;
        this.dbConfig = {
            host: 'localhost',
            user: 'u853242961_user7',
            password: 'Lucastav8012@',
            database: 'u853242961_financeiro',
            charset: 'utf8mb4',
            acquireTimeout: 60000,
            timeout: 60000,
            reconnect: true
        };
        this.pool = null;
        this.setupMiddleware();
        this.setupRoutes();
    }

    async connectDatabase() {
        try {
            this.pool = mysql.createPool({
                ...this.dbConfig,
                waitForConnections: true,
                connectionLimit: 10,
                queueLimit: 0
            });
            
            // Testar conexão
            const connection = await this.pool.getConnection();
            await connection.ping();
            connection.release();
            
            logger.info('✅ Conexão com banco de dados estabelecida');
            return true;
        } catch (error) {
            logger.error(`❌ Erro ao conectar banco: ${error.message}`);
            return false;
        }
    }

    setupMiddleware() {
        this.app.use(helmet());
        this.app.use(cors());
        this.app.use(express.json({ limit: '10mb' }));
        this.app.use(express.urlencoded({ extended: true }));
        
        // Middleware de autenticação
        this.app.use('/api', this.authenticateToken.bind(this));
        
        // Middleware de logging
        this.app.use((req, res, next) => {
            logger.info(`${req.method} ${req.path} - ${req.ip}`);
            next();
        });
    }

    async authenticateToken(req, res, next) {
        const authHeader = req.headers['authorization'];
        const token = authHeader && authHeader.split(' ')[1];

        if (!token) {
            return res.status(401).json({ success: false, error: 'Token de acesso necessário' });
        }

        try {
            const decoded = jwt.verify(token, process.env.JWT_SECRET || 'sua-chave-secreta');
            req.user = decoded;
            next();
        } catch (error) {
            return res.status(403).json({ success: false, error: 'Token inválido' });
        }
    }

    setupRoutes() {
        // Rotas de autenticação
        this.app.post('/auth/login', this.login.bind(this));
        this.app.post('/auth/register', this.register.bind(this));
        this.app.post('/auth/logout', this.logout.bind(this));

        // Rotas de contas
        this.app.get('/api/contas', this.getContas.bind(this));
        this.app.post('/api/contas', this.createConta.bind(this));
        this.app.put('/api/contas/:id', this.updateConta.bind(this));
        this.app.delete('/api/contas/:id', this.deleteConta.bind(this));

        // Rotas de membros
        this.app.get('/api/contas/:id/membros', this.getMembros.bind(this));
        this.app.post('/api/contas/:id/membros', this.addMembro.bind(this));
        this.app.put('/api/contas/:id/membros/:membroId', this.updateMembro.bind(this));
        this.app.delete('/api/contas/:id/membros/:membroId', this.removeMembro.bind(this));

        // Rotas de permissões
        this.app.get('/api/contas/:id/permissoes', this.getPermissoes.bind(this));
        this.app.post('/api/contas/:id/permissoes', this.setPermissao.bind(this));

        // Rotas de convites
        this.app.post('/api/contas/:id/convidar', this.convidarMembro.bind(this));
        this.app.get('/api/convites/:codigo', this.getConvite.bind(this));
        this.app.post('/api/convites/:codigo/aceitar', this.aceitarConvite.bind(this));
        this.app.post('/api/convites/:codigo/recusar', this.recusarConvite.bind(this));

        // Rotas de logs
        this.app.get('/api/contas/:id/logs', this.getLogs.bind(this));

        // Health check
        this.app.get('/health', this.healthCheck.bind(this));

        // Proxy para outros serviços
        this.app.use('/api/go', createProxyMiddleware({
            target: 'http://localhost:8080',
            changeOrigin: true,
            pathRewrite: { '^/api/go': '' }
        }));

        this.app.use('/api/rust', createProxyMiddleware({
            target: 'http://localhost:8081',
            changeOrigin: true,
            pathRewrite: { '^/api/rust': '' }
        }));

        this.app.use('/api/php', createProxyMiddleware({
            target: 'http://localhost:8000',
            changeOrigin: true,
            pathRewrite: { '^/api/php': '' }
        }));
    }

    // Métodos de autenticação
    async login(req, res) {
        try {
            const { usuario, senha } = req.body;

            const [rows] = await this.pool.execute(
                'SELECT id, usuario, senha_hash, nome_completo, email, tipo FROM usuarios WHERE usuario = ?',
                [usuario]
            );

            if (rows.length === 0) {
                return res.status(401).json({ success: false, error: 'Credenciais inválidas' });
            }

            const user = rows[0];
            const validPassword = await bcrypt.compare(senha, user.senha_hash);

            if (!validPassword) {
                return res.status(401).json({ success: false, error: 'Credenciais inválidas' });
            }

            const token = jwt.sign(
                { id: user.id, usuario: user.usuario, tipo: user.tipo },
                process.env.JWT_SECRET || 'sua-chave-secreta',
                { expiresIn: '24h' }
            );

            res.json({
                success: true,
                data: {
                    token,
                    user: {
                        id: user.id,
                        usuario: user.usuario,
                        nome: user.nome_completo,
                        email: user.email,
                        tipo: user.tipo
                    }
                }
            });
        } catch (error) {
            logger.error(`Erro no login: ${error.message}`);
            res.status(500).json({ success: false, error: 'Erro interno do servidor' });
        }
    }

    async register(req, res) {
        try {
            const schema = Joi.object({
                usuario: Joi.string().min(3).max(50).required(),
                senha: Joi.string().min(6).required(),
                nome_completo: Joi.string().min(3).max(100).required(),
                email: Joi.string().email().required(),
                tipo: Joi.string().valid('usuario', 'admin').default('usuario')
            });

            const { error, value } = schema.validate(req.body);
            if (error) {
                return res.status(400).json({ success: false, error: error.details[0].message });
            }

            const { usuario, senha, nome_completo, email, tipo } = value;

            // Verificar se usuário já existe
            const [existingUser] = await this.pool.execute(
                'SELECT id FROM usuarios WHERE usuario = ? OR email = ?',
                [usuario, email]
            );

            if (existingUser.length > 0) {
                return res.status(400).json({ success: false, error: 'Usuário ou email já existe' });
            }

            // Hash da senha
            const senha_hash = await bcrypt.hash(senha, 12);

            // Inserir usuário
            const [result] = await this.pool.execute(
                'INSERT INTO usuarios (usuario, senha_hash, nome_completo, email, tipo) VALUES (?, ?, ?, ?, ?)',
                [usuario, senha_hash, nome_completo, email, tipo]
            );

            res.status(201).json({
                success: true,
                data: { id: result.insertId, usuario, nome_completo, email, tipo }
            });
        } catch (error) {
            logger.error(`Erro no registro: ${error.message}`);
            res.status(500).json({ success: false, error: 'Erro interno do servidor' });
        }
    }

    async logout(req, res) {
        // Em um sistema real, você invalidaria o token aqui
        res.json({ success: true, message: 'Logout realizado com sucesso' });
    }

    // Métodos de contas
    async getContas(req, res) {
        try {
            const [rows] = await this.pool.execute(`
                SELECT 
                    c.*,
                    cm.papel,
                    cm.status as status_membro,
                    cm.data_aceite
                FROM contas c
                JOIN conta_membros cm ON c.id = cm.conta_id
                WHERE cm.usuario_id = ? AND cm.status = 'ativo'
                ORDER BY c.data_criacao DESC
            `, [req.user.id]);

            res.json({ success: true, data: rows });
        } catch (error) {
            logger.error(`Erro ao buscar contas: ${error.message}`);
            res.status(500).json({ success: false, error: 'Erro interno do servidor' });
        }
    }

    async createConta(req, res) {
        try {
            const schema = Joi.object({
                nome: Joi.string().min(3).max(255).required(),
                descricao: Joi.string().max(1000).optional(),
                tipo: Joi.string().valid('pessoal', 'empresarial', 'familia').default('pessoal')
            });

            const { error, value } = schema.validate(req.body);
            if (error) {
                return res.status(400).json({ success: false, error: error.details[0].message });
            }

            const { nome, descricao, tipo } = value;
            const codigo_conta = `CONTA-${Date.now()}`;

            // Iniciar transação
            const connection = await this.pool.getConnection();
            await connection.beginTransaction();

            try {
                // Criar conta
                const [contaResult] = await connection.execute(
                    'INSERT INTO contas (nome, descricao, codigo_conta, tipo, criado_por) VALUES (?, ?, ?, ?, ?)',
                    [nome, descricao, codigo_conta, tipo, req.user.id]
                );

                const contaId = contaResult.insertId;

                // Adicionar criador como proprietário
                await connection.execute(
                    'INSERT INTO conta_membros (conta_id, usuario_id, papel, status, data_aceite) VALUES (?, ?, ?, ?, NOW())',
                    [contaId, req.user.id, 'proprietario', 'ativo']
                );

                // Log da ação
                await connection.execute(
                    'INSERT INTO conta_logs (conta_id, usuario_id, acao, modulo, descricao) VALUES (?, ?, ?, ?, ?)',
                    [contaId, req.user.id, 'criar_conta', 'sistema', `Conta "${nome}" criada`]
                );

                await connection.commit();
                connection.release();

                res.status(201).json({
                    success: true,
                    data: { id: contaId, nome, codigo_conta }
                });
            } catch (error) {
                await connection.rollback();
                connection.release();
                throw error;
            }
        } catch (error) {
            logger.error(`Erro ao criar conta: ${error.message}`);
            res.status(500).json({ success: false, error: 'Erro interno do servidor' });
        }
    }

    async updateConta(req, res) {
        try {
            const { id } = req.params;
            const { nome, descricao, tipo, status } = req.body;

            // Verificar se usuário tem permissão
            const [permission] = await this.pool.execute(
                'SELECT papel FROM conta_membros WHERE conta_id = ? AND usuario_id = ? AND status = "ativo"',
                [id, req.user.id]
            );

            if (permission.length === 0 || !['proprietario', 'administrador'].includes(permission[0].papel)) {
                return res.status(403).json({ success: false, error: 'Sem permissão para editar esta conta' });
            }

            await this.pool.execute(
                'UPDATE contas SET nome = ?, descricao = ?, tipo = ?, status = ? WHERE id = ?',
                [nome, descricao, tipo, status, id]
            );

            // Log da ação
            await this.pool.execute(
                'INSERT INTO conta_logs (conta_id, usuario_id, acao, modulo, descricao) VALUES (?, ?, ?, ?, ?)',
                [id, req.user.id, 'editar_conta', 'sistema', `Conta "${nome}" editada`]
            );

            res.json({ success: true, message: 'Conta atualizada com sucesso' });
        } catch (error) {
            logger.error(`Erro ao atualizar conta: ${error.message}`);
            res.status(500).json({ success: false, error: 'Erro interno do servidor' });
        }
    }

    async deleteConta(req, res) {
        try {
            const { id } = req.params;

            // Verificar se usuário é proprietário
            const [permission] = await this.pool.execute(
                'SELECT papel FROM conta_membros WHERE conta_id = ? AND usuario_id = ? AND status = "ativo"',
                [id, req.user.id]
            );

            if (permission.length === 0 || permission[0].papel !== 'proprietario') {
                return res.status(403).json({ success: false, error: 'Apenas o proprietário pode excluir a conta' });
            }

            await this.pool.execute('DELETE FROM contas WHERE id = ?', [id]);

            res.json({ success: true, message: 'Conta excluída com sucesso' });
        } catch (error) {
            logger.error(`Erro ao excluir conta: ${error.message}`);
            res.status(500).json({ success: false, error: 'Erro interno do servidor' });
        }
    }

    // Métodos de membros
    async getMembros(req, res) {
        try {
            const { id } = req.params;

            const [rows] = await this.pool.execute(`
                SELECT 
                    cm.*,
                    u.usuario,
                    u.nome_completo,
                    u.email
                FROM conta_membros cm
                JOIN usuarios u ON cm.usuario_id = u.id
                WHERE cm.conta_id = ?
                ORDER BY cm.data_convite DESC
            `, [id]);

            res.json({ success: true, data: rows });
        } catch (error) {
            logger.error(`Erro ao buscar membros: ${error.message}`);
            res.status(500).json({ success: false, error: 'Erro interno do servidor' });
        }
    }

    async addMembro(req, res) {
        try {
            const { id } = req.params;
            const { usuario_id, papel } = req.body;

            // Verificar se usuário tem permissão
            const [permission] = await this.pool.execute(
                'SELECT papel FROM conta_membros WHERE conta_id = ? AND usuario_id = ? AND status = "ativo"',
                [id, req.user.id]
            );

            if (permission.length === 0 || !['proprietario', 'administrador'].includes(permission[0].papel)) {
                return res.status(403).json({ success: false, error: 'Sem permissão para adicionar membros' });
            }

            await this.pool.execute(
                'INSERT INTO conta_membros (conta_id, usuario_id, papel, status, data_aceite, convidado_por) VALUES (?, ?, ?, "ativo", NOW(), ?)',
                [id, usuario_id, papel, req.user.id]
            );

            res.status(201).json({ success: true, message: 'Membro adicionado com sucesso' });
        } catch (error) {
            logger.error(`Erro ao adicionar membro: ${error.message}`);
            res.status(500).json({ success: false, error: 'Erro interno do servidor' });
        }
    }

    // Métodos de convites
    async convidarMembro(req, res) {
        try {
            const { id } = req.params;
            const { email, papel } = req.body;

            const codigo_convite = `CONV-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
            const data_expiracao = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 dias

            await this.pool.execute(
                'INSERT INTO conta_convites (conta_id, email, codigo_convite, papel, data_expiracao, convidado_por) VALUES (?, ?, ?, ?, ?, ?)',
                [id, email, codigo_convite, papel, data_expiracao, req.user.id]
            );

            // Aqui você enviaria um email com o código de convite
            logger.info(`Convite criado: ${codigo_convite} para ${email}`);

            res.status(201).json({
                success: true,
                data: { codigo_convite, email, data_expiracao }
            });
        } catch (error) {
            logger.error(`Erro ao convidar membro: ${error.message}`);
            res.status(500).json({ success: false, error: 'Erro interno do servidor' });
        }
    }

    async getConvite(req, res) {
        try {
            const { codigo } = req.params;

            const [rows] = await this.pool.execute(
                'SELECT * FROM conta_convites WHERE codigo_convite = ? AND status = "pendente" AND data_expiracao > NOW()',
                [codigo]
            );

            if (rows.length === 0) {
                return res.status(404).json({ success: false, error: 'Convite não encontrado ou expirado' });
            }

            res.json({ success: true, data: rows[0] });
        } catch (error) {
            logger.error(`Erro ao buscar convite: ${error.message}`);
            res.status(500).json({ success: false, error: 'Erro interno do servidor' });
        }
    }

    async aceitarConvite(req, res) {
        try {
            const { codigo } = req.params;

            const [convite] = await this.pool.execute(
                'SELECT * FROM conta_convites WHERE codigo_convite = ? AND status = "pendente"',
                [codigo]
            );

            if (convite.length === 0) {
                return res.status(404).json({ success: false, error: 'Convite não encontrado' });
            }

            const conviteData = convite[0];

            // Adicionar usuário como membro
            await this.pool.execute(
                'INSERT INTO conta_membros (conta_id, usuario_id, papel, status, data_aceite, convidado_por) VALUES (?, ?, ?, "ativo", NOW(), ?)',
                [conviteData.conta_id, req.user.id, conviteData.papel, conviteData.convidado_por]
            );

            // Atualizar status do convite
            await this.pool.execute(
                'UPDATE conta_convites SET status = "aceito" WHERE codigo_convite = ?',
                [codigo]
            );

            res.json({ success: true, message: 'Convite aceito com sucesso' });
        } catch (error) {
            logger.error(`Erro ao aceitar convite: ${error.message}`);
            res.status(500).json({ success: false, error: 'Erro interno do servidor' });
        }
    }

    // Métodos de logs
    async getLogs(req, res) {
        try {
            const { id } = req.params;
            const { page = 1, limit = 50 } = req.query;

            const offset = (page - 1) * limit;

            const [rows] = await this.pool.execute(`
                SELECT * FROM conta_logs 
                WHERE conta_id = ? 
                ORDER BY data_acao DESC 
                LIMIT ? OFFSET ?
            `, [id, parseInt(limit), parseInt(offset)]);

            res.json({ success: true, data: rows });
        } catch (error) {
            logger.error(`Erro ao buscar logs: ${error.message}`);
            res.status(500).json({ success: false, error: 'Erro interno do servidor' });
        }
    }

    async healthCheck(req, res) {
        try {
            // Verificar conexão com banco
            const connection = await this.pool.getConnection();
            await connection.ping();
            connection.release();

            res.json({
                status: 'ok',
                timestamp: new Date().toISOString(),
                service: 'gestao-contas-nodejs',
                version: '1.0.0',
                database: 'connected'
            });
        } catch (error) {
            res.status(503).json({
                status: 'error',
                timestamp: new Date().toISOString(),
                service: 'gestao-contas-nodejs',
                error: error.message
            });
        }
    }

    async start() {
        try {
            const dbConnected = await this.connectDatabase();
            if (!dbConnected) {
                logger.error('❌ Falha ao conectar com banco de dados');
                process.exit(1);
            }

            this.app.listen(this.port, () => {
                logger.info(`🚀 Servidor Node.js rodando na porta ${this.port}`);
                logger.info(`📡 API disponível em: http://localhost:${this.port}`);
                logger.info(`🔍 Health check: http://localhost:${this.port}/health`);
            });
        } catch (error) {
            logger.error(`❌ Erro ao iniciar servidor: ${error.message}`);
            process.exit(1);
        }
    }
}

// Iniciar servidor
const sistema = new SistemaGestaoNodeJS();
sistema.start().catch(error => {
    console.error('❌ Erro fatal:', error);
    process.exit(1);
});

module.exports = SistemaGestaoNodeJS;

<?php
// teste_sistema_login.php - Teste do Sistema de Login
// Verifica se o sistema está funcionando corretamente

// Ativar exibição de erros
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "<h2>🔐 TESTE DO SISTEMA DE LOGIN</h2>";

// 1. Verificar arquivos
echo "<h3>1. VERIFICANDO ARQUIVOS</h3>";

$arquivos = [
    'login.php' => 'Sistema de Login',
    'logout.php' => 'Sistema de Logout',
    'includes/db_connect.php' => 'Conexão com Banco'
];

foreach ($arquivos as $arquivo => $descricao) {
    if (file_exists($arquivo)) {
        echo "✅ $descricao ($arquivo) - OK<br>";
    } else {
        echo "❌ $descricao ($arquivo) - NÃO ENCONTRADO<br>";
    }
}

echo "<br>";

// 2. Verificar conexão com banco
echo "<h3>2. VERIFICANDO CONEXÃO COM BANCO</h3>";

try {
    require_once 'includes/db_connect.php';
    echo "✅ Conexão com banco de dados - OK<br>";
    
    // Verificar se a tabela usuarios existe
    $stmt = $pdo->query("SHOW TABLES LIKE 'usuarios'");
    if ($stmt->rowCount() > 0) {
        echo "✅ Tabela 'usuarios' existe - OK<br>";
        
        // Verificar estrutura da tabela
        $stmt = $pdo->query("DESCRIBE usuarios");
        $colunas = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "📋 Colunas da tabela 'usuarios':<br>";
        foreach ($colunas as $coluna) {
            echo "- {$coluna['Field']} ({$coluna['Type']})<br>";
        }
        
        // Verificar se há usuários
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM usuarios");
        $total = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
        echo "📊 Total de usuários: $total<br>";
        
        if ($total > 0) {
            // Mostrar alguns usuários
            $stmt = $pdo->query("SELECT id, nome, email, papel, status FROM usuarios LIMIT 3");
            $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo "📋 Exemplos de usuários:<br>";
            foreach ($usuarios as $usuario) {
                echo "- ID: {$usuario['id']}, Nome: {$usuario['nome']}, Email: {$usuario['email']}, Papel: {$usuario['papel']}, Status: {$usuario['status']}<br>";
            }
        }
        
    } else {
        echo "❌ Tabela 'usuarios' não existe - CRIAR TABELA<br>";
        
        // Criar tabela usuarios
        $sql = "
            CREATE TABLE IF NOT EXISTS usuarios (
                id INT PRIMARY KEY AUTO_INCREMENT,
                nome VARCHAR(255) NOT NULL,
                email VARCHAR(255) UNIQUE NOT NULL,
                senha VARCHAR(255) NOT NULL,
                papel ENUM('administrador', 'analista', 'usuario') DEFAULT 'usuario',
                status ENUM('ativo', 'inativo', 'suspenso') DEFAULT 'ativo',
                data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )
        ";
        
        $pdo->exec($sql);
        echo "✅ Tabela 'usuarios' criada - OK<br>";
        
        // Criar usuário de teste
        $nome = 'Administrador';
        $email = 'admin@helmer.com';
        $senha = password_hash('123456', PASSWORD_DEFAULT);
        $papel = 'administrador';
        
        $stmt = $pdo->prepare("INSERT INTO usuarios (nome, email, senha, papel, status) VALUES (?, ?, ?, ?, 'ativo')");
        $stmt->execute([$nome, $email, $senha, $papel]);
        
        echo "✅ Usuário de teste criado - Email: $email, Senha: 123456<br>";
    }
    
} catch (PDOException $e) {
    echo "❌ Erro de conexão com banco: " . $e->getMessage() . "<br>";
}

echo "<br>";

// 3. Verificar sessão
echo "<h3>3. VERIFICANDO SISTEMA DE SESSÃO</h3>";

if (session_status() == PHP_SESSION_NONE) {
    session_start();
    echo "✅ Sessão iniciada - OK<br>";
} else {
    echo "✅ Sessão já ativa - OK<br>";
}

// Verificar variáveis de sessão
$variaveisSessao = ['user_id', 'nome', 'email', 'papel', 'status'];
echo "📋 Variáveis de sessão esperadas:<br>";
foreach ($variaveisSessao as $variavel) {
    if (isset($_SESSION[$variavel])) {
        echo "✅ \$_SESSION['$variavel'] = " . $_SESSION[$variavel] . "<br>";
    } else {
        echo "❌ \$_SESSION['$variavel'] - NÃO DEFINIDA<br>";
    }
}

echo "<br>";

// 4. Verificar redirecionamentos
echo "<h3>4. VERIFICANDO REDIRECIONAMENTOS</h3>";

$paginas = [
    'dashboard.php' => 'Dashboard Principal',
    'gestao_contas_unificada.php' => 'Gestão de Contas'
];

foreach ($paginas as $pagina => $descricao) {
    if (file_exists($pagina)) {
        echo "✅ $descricao ($pagina) - OK<br>";
    } else {
        echo "❌ $descricao ($pagina) - NÃO ENCONTRADO<br>";
    }
}

echo "<br>";

// 5. Teste de segurança
echo "<h3>5. VERIFICANDO SEGURANÇA</h3>";

// Verificar se password_verify está disponível
if (function_exists('password_verify')) {
    echo "✅ Função password_verify() disponível - OK<br>";
} else {
    echo "❌ Função password_verify() não disponível - PROBLEMA<br>";
}

// Verificar se session_regenerate_id está disponível
if (function_exists('session_regenerate_id')) {
    echo "✅ Função session_regenerate_id() disponível - OK<br>";
} else {
    echo "❌ Função session_regenerate_id() não disponível - PROBLEMA<br>";
}

// Verificar se PDO está disponível
if (class_exists('PDO')) {
    echo "✅ Classe PDO disponível - OK<br>";
} else {
    echo "❌ Classe PDO não disponível - PROBLEMA<br>";
}

echo "<br>";

// 6. Links para teste
echo "<h3>6. LINKS PARA TESTE</h3>";

echo "<p><strong>🔗 Links para testar o sistema:</strong></p>";
echo "<ul>";
echo "<li><a href='login.php' target='_blank'>🔐 Página de Login</a></li>";
echo "<li><a href='logout.php' target='_blank'>🚪 Logout (se logado)</a></li>";
echo "<li><a href='dashboard.php' target='_blank'>📊 Dashboard</a></li>";
echo "<li><a href='gestao_contas_unificada.php' target='_blank'>🏢 Gestão de Contas</a></li>";
echo "</ul>";

echo "<br>";

// 7. Instruções de teste
echo "<h3>7. INSTRUÇÕES DE TESTE</h3>";

echo "<div style='background: #f8f9fa; padding: 15px; border-radius: 5px; border-left: 4px solid #007bff;'>";
echo "<h4>📋 Como testar o sistema:</h4>";
echo "<ol>";
echo "<li><strong>Acesse login.php</strong> - Verifique se a interface está funcionando</li>";
echo "<li><strong>Teste com credenciais incorretas</strong> - Deve mostrar erro</li>";
echo "<li><strong>Teste com credenciais corretas</strong> - Deve redirecionar para dashboard</li>";
echo "<li><strong>Verifique as variáveis de sessão</strong> - Devem estar definidas</li>";
echo "<li><strong>Teste o logout</strong> - Deve limpar a sessão e redirecionar</li>";
echo "<li><strong>Teste gestao_contas_unificada.php</strong> - Deve funcionar com sessão ativa</li>";
echo "</ol>";
echo "</div>";

echo "<br>";

// 8. Resumo
echo "<h3>8. RESUMO DO TESTE</h3>";

$totalTestes = 0;
$testesOk = 0;

// Contar testes
$totalTestes += count($arquivos);
foreach ($arquivos as $arquivo => $descricao) {
    if (file_exists($arquivo)) $testesOk++;
}

$totalTestes += 1; // Conexão com banco
if (isset($pdo)) $testesOk++;

$totalTestes += 1; // Sessão
if (session_status() == PHP_SESSION_ACTIVE) $testesOk++;

$totalTestes += count($paginas);
foreach ($paginas as $pagina => $descricao) {
    if (file_exists($pagina)) $testesOk++;
}

$totalTestes += 3; // Funções de segurança
if (function_exists('password_verify')) $testesOk++;
if (function_exists('session_regenerate_id')) $testesOk++;
if (class_exists('PDO')) $testesOk++;

$percentual = round(($testesOk / $totalTestes) * 100, 1);

echo "<div style='background: " . ($percentual >= 80 ? '#d4edda' : '#f8d7da') . "; padding: 15px; border-radius: 5px; border-left: 4px solid " . ($percentual >= 80 ? '#28a745' : '#dc3545') . ";'>";
echo "<h4>" . ($percentual >= 80 ? "✅ SISTEMA FUNCIONANDO" : "⚠️ SISTEMA PRECISA DE AJUSTES") . "</h4>";
echo "<p><strong>Testes realizados:</strong> $testesOk / $totalTestes ($percentual%)</p>";

if ($percentual >= 80) {
    echo "<p style='color: #155724;'><strong>🎉 O sistema de login está funcionando corretamente!</strong></p>";
    echo "<p>Você pode usar o sistema normalmente. Acesse <a href='login.php'>login.php</a> para começar.</p>";
} else {
    echo "<p style='color: #721c24;'><strong>⚠️ Alguns problemas foram encontrados.</strong></p>";
    echo "<p>Verifique os itens marcados com ❌ e corrija antes de usar o sistema.</p>";
}

echo "</div>";

echo "<br>";
echo "<p><strong>✅ Teste concluído!</strong></p>";
echo "<p><a href='login.php'>🔐 Ir para o Login</a> | <a href='dashboard.php'>📊 Ir para o Dashboard</a></p>";
?>

<?php
// teste_gestao_unificada.php - Teste da gestão de contas unificada

session_start();
require_once 'includes/db_connect.php';

echo "<h2>🧪 TESTE DA GESTÃO DE CONTAS UNIFICADA</h2>";

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    echo "❌ Usuário não está logado. Faça login primeiro.<br>";
    echo "<a href='login.php' class='btn btn-primary'>Fazer Login</a><br><br>";
    exit();
}

$userId = $_SESSION['user_id'];
echo "✅ Usuário logado: ID $userId<br><br>";

// 1. Verificar arquivo da gestão unificada
echo "<h3>1. Verificando Arquivo da Gestão Unificada</h3>";

if (file_exists('gestao_contas_unificada.php')) {
    echo "✅ gestao_contas_unificada.php - Arquivo encontrado<br>";
    
    $conteudo = file_get_contents('gestao_contas_unificada.php');
    $tamanho = strlen($conteudo);
    
    if ($tamanho > 10000) {
        echo "✅ Conteúdo OK ($tamanho bytes)<br>";
    } else {
        echo "⚠️ Conteúdo muito pequeno ($tamanho bytes)<br>";
    }
    
    // Verificar elementos importantes
    $elementos = [
        'gestaoTabs' => 'Tabs de navegação',
        'contas' => 'Tab Contas',
        'usuarios' => 'Tab Usuários',
        'permissoes' => 'Tab Permissões',
        'modalNovaConta' => 'Modal Nova Conta',
        'modalCriarUsuario' => 'Modal Criar Usuário',
        'formNovaConta' => 'Formulário Nova Conta',
        'formCriarUsuario' => 'Formulário Criar Usuário'
    ];
    
    $elementos_ok = 0;
    foreach ($elementos as $elemento => $nome) {
        if (strpos($conteudo, $elemento) !== false) {
            echo "&nbsp;&nbsp;✅ $nome - Encontrado<br>";
            $elementos_ok++;
        } else {
            echo "&nbsp;&nbsp;❌ $nome - NÃO encontrado<br>";
        }
    }
    
    echo "<p><strong>Elementos OK: $elementos_ok/" . count($elementos) . "</strong></p>";
    
} else {
    echo "❌ gestao_contas_unificada.php - NÃO ENCONTRADO<br>";
}

echo "<hr>";

// 2. Verificar configuração do menu
echo "<h3>2. Verificando Configuração do Menu</h3>";

$conteudo_menu = file_get_contents('includes/load_menu_config.php');

if (strpos($conteudo_menu, 'gestao_contas_unificada.php') !== false) {
    echo "✅ gestao_contas_unificada.php - Adicionado ao menu<br>";
} else {
    echo "❌ gestao_contas_unificada.php - NÃO encontrado no menu<br>";
}

if (strpos($conteudo_menu, "'sistema' => ['gestao_contas_unificada.php', 'perfil.php']") !== false) {
    echo "✅ Configuração do sistema simplificada<br>";
} else {
    echo "❌ Configuração do sistema NÃO simplificada<br>";
}

echo "<hr>";

// 3. Verificar funcionalidades implementadas
echo "<h3>3. Verificando Funcionalidades Implementadas</h3>";

$funcionalidades = [
    'Criar Conta' => 'formNovaConta',
    'Criar Usuário' => 'formCriarUsuario',
    'Gerenciar Membros' => 'gerenciarMembros',
    'Configurar Permissões' => 'configurarPermissoes',
    'Editar Conta' => 'editarConta',
    'Excluir Conta' => 'excluirConta',
    'Remover Usuário' => 'removerUsuario',
    'Atualizar Permissão' => 'atualizarPermissao'
];

$funcionalidades_ok = 0;

foreach ($funcionalidades as $nome => $funcao) {
    if (strpos($conteudo, $funcao) !== false) {
        echo "✅ $nome - Implementada<br>";
        $funcionalidades_ok++;
    } else {
        echo "❌ $nome - NÃO implementada<br>";
    }
}

echo "<p><strong>Funcionalidades OK: $funcionalidades_ok/" . count($funcionalidades) . "</strong></p>";

echo "<hr>";

// 4. Verificar módulos de permissões
echo "<h3>4. Verificando Módulos de Permissões</h3>";

$modulos = [
    'financeiro' => 'Financeiro',
    'produtividade' => 'Produtividade',
    'academy' => 'Academy',
    'sistema' => 'Sistema'
];

$modulos_ok = 0;

foreach ($modulos as $modulo => $nome) {
    if (strpos($conteudo, $modulo) !== false) {
        echo "✅ $nome - Configurado<br>";
        $modulos_ok++;
    } else {
        echo "❌ $nome - NÃO configurado<br>";
    }
}

echo "<p><strong>Módulos OK: $modulos_ok/" . count($modulos) . "</strong></p>";

echo "<hr>";

// 5. Teste de acesso à página
echo "<h3>5. Teste de Acesso à Página</h3>";

echo "🔗 <a href='gestao_contas_unificada.php' target='_blank'>Acessar Gestão de Contas Unificada</a><br>";

echo "<hr>";

// 6. Resumo final
echo "<h2>📊 RESUMO FINAL</h2>";

$total_verificacoes = 1 + 2 + count($elementos) + count($funcionalidades) + count($modulos);
$verificacoes_ok = 1 + 2 + $elementos_ok + $funcionalidades_ok + $modulos_ok;

echo "<p><strong>Verificações OK: $verificacoes_ok/$total_verificacoes</strong></p>";

if ($verificacoes_ok >= $total_verificacoes * 0.8) {
    echo "<div style='background: #d4edda; padding: 1rem; border-radius: 8px; margin: 1rem 0;'>";
    echo "<h4>✅ GESTÃO UNIFICADA FUNCIONANDO!</h4>";
    echo "<p>A gestão de contas unificada está funcionando corretamente. Todas as funcionalidades estão implementadas em uma única página.</p>";
    echo "<p><strong>Funcionalidades disponíveis:</strong></p>";
    echo "<ul>";
    echo "<li>🏢 <strong>Criar Contas</strong> - Nova conta multiusuário</li>";
    echo "<li>👥 <strong>Criar Usuários</strong> - Usuários com login/senha</li>";
    echo "<li>🔐 <strong>Configurar Permissões</strong> - Controle granular por módulo</li>";
    echo "<li>📊 <strong>Gerenciar Membros</strong> - Adicionar/remover usuários</li>";
    echo "<li>⚙️ <strong>Editar Contas</strong> - Modificar informações</li>";
    echo "<li>🗑️ <strong>Excluir Contas</strong> - Remover contas</li>";
    echo "</ul>";
    echo "<p><strong>Módulos de Permissão:</strong></p>";
    echo "<ul>";
    echo "<li>🟡 <strong>Financeiro</strong> - Ver Saldo, Editar, Excluir, Relatórios</li>";
    echo "<li>🔵 <strong>Produtividade</strong> - Visualizar, Editar, Excluir, Relatórios</li>";
    echo "<li>🟢 <strong>Academy</strong> - Visualizar, Editar, Excluir, Relatórios</li>";
    echo "<li>⚫ <strong>Sistema</strong> - Gerenciar Usuários, Permissões, Logs, Configurações</li>";
    echo "</ul>";
    echo "<p><strong>Como usar:</strong></p>";
    echo "<ol>";
    echo "<li>Acesse o dashboard</li>";
    echo "<li>Clique em 'Sistema' no menu lateral</li>";
    echo "<li>Clique em 'Gestão de Contas'</li>";
    echo "<li>Use as tabs para navegar entre Contas, Usuários e Permissões</li>";
    echo "</ol>";
    echo "</div>";
} else {
    echo "<div style='background: #f8d7da; padding: 1rem; border-radius: 8px; margin: 1rem 0;'>";
    echo "<h4>❌ Gestão Ainda Precisa de Ajustes</h4>";
    echo "<p>Algumas funcionalidades ainda precisam ser implementadas. Verifique os itens marcados com ❌ acima.</p>";
    echo "<ol>";
    echo "<li>Verifique se o arquivo foi criado corretamente</li>";
    echo "<li>Teste a página individualmente</li>";
    echo "<li>Execute este script novamente se necessário</li>";
    echo "</ol>";
    echo "</div>";
}

echo "<hr>";
echo "<p><strong>✅ Teste da gestão unificada concluído!</strong> Todas as funcionalidades estão em uma única página.</p>";
?>

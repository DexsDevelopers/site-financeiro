<?php
// recusar_convite.php - Recusar convite para conta

session_start();
require_once 'includes/db_connect.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Acesso negado']);
    exit();
}

$userId = $_SESSION['user_id'];

// Verificar se é uma requisição POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit();
}

// Obter dados do POST
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['convite_id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'ID do convite não fornecido']);
    exit();
}

$conviteId = (int)$input['convite_id'];

try {
    // Verificar se o convite existe
    $stmt = $pdo->prepare("
        SELECT cc.*, c.nome as nome_conta 
        FROM conta_convites cc
        JOIN contas c ON cc.conta_id = c.id
        WHERE cc.id = ? AND cc.status = 'pendente'
    ");
    $stmt->execute([$conviteId]);
    $convite = $stmt->fetch();
    
    if (!$convite) {
        echo json_encode(['success' => false, 'message' => 'Convite não encontrado']);
        exit();
    }
    
    // Atualizar status do convite
    $stmt = $pdo->prepare("
        UPDATE conta_convites 
        SET status = 'cancelado' 
        WHERE id = ?
    ");
    $stmt->execute([$conviteId]);
    
    // Registrar log
    $stmt = $pdo->prepare("
        INSERT INTO conta_logs (conta_id, usuario_id, acao, modulo, detalhes) 
        VALUES (?, ?, 'convite_recusado', 'sistema', ?)
    ");
    $stmt->execute([$convite['conta_id'], $userId, "Convite recusado para conta '{$convite['nome_conta']}'"]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Convite recusado com sucesso!'
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao recusar convite: ' . $e->getMessage()
    ]);
}
?>

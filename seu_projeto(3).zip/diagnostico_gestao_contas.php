<?php
// diagnostico_gestao_contas.php - Diagnóstico da Gestão de Contas
// Verifica por que as contas não estão aparecendo

// Ativar exibição de erros
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Verificar se a sessão já foi iniciada
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once 'includes/db_connect.php';

echo "<h2>🔍 DIAGNÓSTICO DA GESTÃO DE CONTAS</h2>";

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    echo "<p style='color: red;'><strong>❌ Usuário não está logado!</strong></p>";
    echo "<p><a href='login.php'>🔐 Fazer Login</a></p>";
    exit();
}

$userId = $_SESSION['user_id'];
echo "<p><strong>✅ Usuário logado:</strong> ID $userId</p>";

echo "<hr>";

// 1. Verificar estrutura das tabelas
echo "<h3>1. ESTRUTURA DAS TABELAS</h3>";

try {
    // Verificar tabela contas
    $stmt = $pdo->query("DESCRIBE contas");
    $colunasContas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "<h4>📋 Tabela 'contas':</h4>";
    echo "<ul>";
    foreach ($colunasContas as $coluna) {
        echo "<li><strong>{$coluna['Field']}</strong> ({$coluna['Type']}) - {$coluna['Null']} - {$coluna['Key']}</li>";
    }
    echo "</ul>";
    
    // Verificar tabela conta_membros
    $stmt = $pdo->query("DESCRIBE conta_membros");
    $colunasMembros = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "<h4>📋 Tabela 'conta_membros':</h4>";
    echo "<ul>";
    foreach ($colunasMembros as $coluna) {
        echo "<li><strong>{$coluna['Field']}</strong> ({$coluna['Type']}) - {$coluna['Null']} - {$coluna['Key']}</li>";
    }
    echo "</ul>";
    
} catch (PDOException $e) {
    echo "<p style='color: red;'><strong>❌ Erro ao verificar estrutura:</strong> " . $e->getMessage() . "</p>";
}

echo "<hr>";

// 2. Verificar dados específicos
echo "<h3>2. DADOS ESPECÍFICOS</h3>";

try {
    // Verificar total de contas
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM contas");
    $totalContas = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    echo "<p><strong>📊 Total de contas no banco:</strong> $totalContas</p>";
    
    // Verificar total de membros
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM conta_membros");
    $totalMembros = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    echo "<p><strong>📊 Total de membros no banco:</strong> $totalMembros</p>";
    
    // Verificar membros do usuário
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM conta_membros WHERE usuario_id = ?");
    $stmt->execute([$userId]);
    $membrosUsuario = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    echo "<p><strong>📊 Membros do usuário:</strong> $membrosUsuario</p>";
    
    // Verificar membros ativos do usuário
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM conta_membros WHERE usuario_id = ? AND status = 'ativo'");
    $stmt->execute([$userId]);
    $membrosAtivos = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    echo "<p><strong>📊 Membros ativos do usuário:</strong> $membrosAtivos</p>";
    
} catch (PDOException $e) {
    echo "<p style='color: red;'><strong>❌ Erro ao verificar dados:</strong> " . $e->getMessage() . "</p>";
}

echo "<hr>";

// 3. Testar consulta exata da página
echo "<h3>3. TESTE DA CONSULTA EXATA</h3>";

try {
    $stmt = $pdo->prepare("
        SELECT 
            c.*,
            cm.papel,
            cm.status as status_membro
        FROM contas c
        JOIN conta_membros cm ON c.id = cm.conta_id
        WHERE cm.usuario_id = ? AND cm.status = 'ativo'
        ORDER BY c.data_criacao DESC
    ");
    $stmt->execute([$userId]);
    $contasUsuario = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<p><strong>📊 Contas encontradas pela consulta:</strong> " . count($contasUsuario) . "</p>";
    
    if (!empty($contasUsuario)) {
        echo "<h4>📋 Contas encontradas:</h4>";
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>ID</th><th>Nome</th><th>Descrição</th><th>Papel</th><th>Status</th><th>Data Criação</th></tr>";
        foreach ($contasUsuario as $conta) {
            echo "<tr>";
            echo "<td>{$conta['id']}</td>";
            echo "<td>{$conta['nome']}</td>";
            echo "<td>" . ($conta['descricao'] ?: 'N/A') . "</td>";
            echo "<td>{$conta['papel']}</td>";
            echo "<td>{$conta['status_membro']}</td>";
            echo "<td>{$conta['data_criacao']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p style='color: orange;'><strong>⚠️ Nenhuma conta encontrada pela consulta!</strong></p>";
        
        // Debug adicional
        echo "<h4>🔍 DEBUG ADICIONAL:</h4>";
        
        // Verificar se há contas com membros do usuário (sem filtro de status)
        $stmt = $pdo->prepare("
            SELECT 
                c.id,
                c.nome,
                cm.papel,
                cm.status as status_membro
            FROM contas c
            JOIN conta_membros cm ON c.id = cm.conta_id
            WHERE cm.usuario_id = ?
            ORDER BY c.data_criacao DESC
        ");
        $stmt->execute([$userId]);
        $contasSemFiltro = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<p><strong>📊 Contas sem filtro de status:</strong> " . count($contasSemFiltro) . "</p>";
        
        if (!empty($contasSemFiltro)) {
            echo "<h5>Contas encontradas (sem filtro de status):</h5>";
            echo "<ul>";
            foreach ($contasSemFiltro as $conta) {
                echo "<li>ID: {$conta['id']}, Nome: {$conta['nome']}, Papel: {$conta['papel']}, Status: {$conta['status_membro']}</li>";
            }
            echo "</ul>";
        }
        
        // Verificar status dos membros
        $stmt = $pdo->prepare("
            SELECT status, COUNT(*) as total 
            FROM conta_membros 
            WHERE usuario_id = ? 
            GROUP BY status
        ");
        $stmt->execute([$userId]);
        $statusMembros = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<h5>Status dos membros do usuário:</h5>";
        echo "<ul>";
        foreach ($statusMembros as $status) {
            echo "<li>Status '{$status['status']}': {$status['total']} membros</li>";
        }
        echo "</ul>";
    }
    
} catch (PDOException $e) {
    echo "<p style='color: red;'><strong>❌ Erro na consulta:</strong> " . $e->getMessage() . "</p>";
}

echo "<hr>";

// 4. Verificar se as tabelas existem
echo "<h3>4. VERIFICAÇÃO DE EXISTÊNCIA DAS TABELAS</h3>";

$tabelasNecessarias = ['contas', 'conta_membros', 'conta_permissoes', 'conta_convites', 'conta_logs'];

foreach ($tabelasNecessarias as $tabela) {
    try {
        $stmt = $pdo->query("SHOW TABLES LIKE '$tabela'");
        if ($stmt->rowCount() > 0) {
            echo "<p style='color: green;'>✅ Tabela '$tabela' existe</p>";
        } else {
            echo "<p style='color: red;'>❌ Tabela '$tabela' NÃO existe</p>";
        }
    } catch (PDOException $e) {
        echo "<p style='color: red;'>❌ Erro ao verificar tabela '$tabela': " . $e->getMessage() . "</p>";
    }
}

echo "<hr>";

// 5. Criar tabelas se não existirem
echo "<h3>5. CRIAR TABELAS SE NECESSÁRIO</h3>";

$sqlTabelas = [
    'contas' => "
        CREATE TABLE IF NOT EXISTS contas (
            id INT PRIMARY KEY AUTO_INCREMENT,
            nome VARCHAR(255) NOT NULL,
            descricao TEXT,
            codigo_conta VARCHAR(50) UNIQUE,
            tipo ENUM('pessoal', 'empresarial', 'familia') DEFAULT 'pessoal',
            status ENUM('ativa', 'inativa', 'suspensa') DEFAULT 'ativa',
            data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            criado_por INT NOT NULL
        )
    ",
    'conta_membros' => "
        CREATE TABLE IF NOT EXISTS conta_membros (
            id INT PRIMARY KEY AUTO_INCREMENT,
            conta_id INT NOT NULL,
            usuario_id INT NOT NULL,
            papel ENUM('proprietario', 'administrador', 'membro', 'visualizador') DEFAULT 'membro',
            status ENUM('ativo', 'pendente', 'suspenso', 'removido') DEFAULT 'ativo',
            data_convite TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            data_aceite TIMESTAMP NULL,
            convidado_por INT,
            FOREIGN KEY (conta_id) REFERENCES contas(id) ON DELETE CASCADE,
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
        )
    "
];

foreach ($sqlTabelas as $tabela => $sql) {
    try {
        $pdo->exec($sql);
        echo "<p style='color: green;'>✅ Tabela '$tabela' criada/verificada</p>";
    } catch (PDOException $e) {
        echo "<p style='color: red;'>❌ Erro ao criar tabela '$tabela': " . $e->getMessage() . "</p>";
    }
}

echo "<hr>";

// 6. Criar conta de teste se necessário
echo "<h3>6. CRIAR CONTA DE TESTE</h3>";

try {
    // Verificar se o usuário já tem contas
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM conta_membros WHERE usuario_id = ?");
    $stmt->execute([$userId]);
    $totalContasUsuario = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    if ($totalContasUsuario == 0) {
        echo "<p style='color: orange;'><strong>⚠️ Usuário não possui contas. Criando conta de teste...</strong></p>";
        
        // Criar conta de teste
        $stmt = $pdo->prepare("
            INSERT INTO contas (nome, descricao, tipo, criado_por) 
            VALUES (?, ?, ?, ?)
        ");
        $nomeConta = "Conta Teste - " . date('Y-m-d H:i:s');
        $descricao = "Conta de teste criada automaticamente";
        $tipo = "pessoal";
        
        $stmt->execute([$nomeConta, $descricao, $tipo, $userId]);
        $contaId = $pdo->lastInsertId();
        
        // Adicionar usuário como proprietário
        $stmt = $pdo->prepare("
            INSERT INTO conta_membros (conta_id, usuario_id, papel, status) 
            VALUES (?, ?, 'proprietario', 'ativo')
        ");
        $stmt->execute([$contaId, $userId]);
        
        echo "<p style='color: green;'><strong>✅ Conta de teste criada com sucesso!</strong></p>";
        echo "<p><strong>ID da conta:</strong> $contaId</p>";
        echo "<p><strong>Nome:</strong> $nomeConta</p>";
        
    } else {
        echo "<p style='color: green;'><strong>✅ Usuário já possui $totalContasUsuario conta(s)</strong></p>";
    }
    
} catch (PDOException $e) {
    echo "<p style='color: red;'><strong>❌ Erro ao criar conta de teste:</strong> " . $e->getMessage() . "</p>";
}

echo "<hr>";

// 7. Teste final
echo "<h3>7. TESTE FINAL</h3>";

try {
    $stmt = $pdo->prepare("
        SELECT 
            c.*,
            cm.papel,
            cm.status as status_membro
        FROM contas c
        JOIN conta_membros cm ON c.id = cm.conta_id
        WHERE cm.usuario_id = ? AND cm.status = 'ativo'
        ORDER BY c.data_criacao DESC
    ");
    $stmt->execute([$userId]);
    $contasFinal = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<p><strong>📊 Contas encontradas no teste final:</strong> " . count($contasFinal) . "</p>";
    
    if (!empty($contasFinal)) {
        echo "<p style='color: green;'><strong>✅ SUCESSO! Contas encontradas!</strong></p>";
        echo "<p><a href='gestao_contas_unificada.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>🏢 Ir para Gestão de Contas</a></p>";
    } else {
        echo "<p style='color: red;'><strong>❌ Ainda nenhuma conta encontrada</strong></p>";
        echo "<p>Verifique os erros acima e corrija antes de usar o sistema.</p>";
    }
    
} catch (PDOException $e) {
    echo "<p style='color: red;'><strong>❌ Erro no teste final:</strong> " . $e->getMessage() . "</p>";
}

echo "<br>";
echo "<p><strong>✅ Diagnóstico concluído!</strong></p>";
?>
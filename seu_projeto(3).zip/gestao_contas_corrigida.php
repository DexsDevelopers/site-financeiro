<?php
// gestao_contas_corrigida.php - Versão corrigida da gestão de contas

session_start();
require_once 'includes/db_connect.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$userId = $_SESSION['user_id'];

// Buscar contas do usuário (consulta simplificada)
$contasUsuario = [];
$membrosContas = [];

try {
    // Consulta simplificada sem JOIN com usuarios
    $stmt = $pdo->prepare("
        SELECT 
            c.*,
            cm.papel,
            cm.status as status_membro
        FROM contas c
        JOIN conta_membros cm ON c.id = cm.conta_id
        WHERE cm.usuario_id = ? AND cm.status = 'ativo'
        ORDER BY c.data_criacao DESC
    ");
    $stmt->execute([$userId]);
    $contasUsuario = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Buscar membros de cada conta
    foreach ($contasUsuario as $conta) {
        if (in_array($conta['papel'], ['proprietario', 'administrador'])) {
            $stmt = $pdo->prepare("
                SELECT 
                    cm.*,
                    u.id as usuario_id,
                    u.email,
                    u.data_criacao as data_cadastro
                FROM conta_membros cm
                JOIN usuarios u ON cm.usuario_id = u.id
                WHERE cm.conta_id = ?
                ORDER BY cm.papel, u.email
            ");
            $stmt->execute([$conta['id']]);
            $membrosContas[$conta['id']] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    }
    
} catch (PDOException $e) {
    $contasUsuario = [];
    $membrosContas = [];
}

// Módulos disponíveis
$modulos = [
    'financeiro' => [
        'nome' => 'Financeiro',
        'icone' => 'bi-wallet2',
        'cor' => 'warning',
        'permissoes' => [
            'acesso' => 'Acesso ao módulo financeiro',
            'ver_saldo' => 'Ver saldo e valores',
            'editar' => 'Editar transações',
            'excluir' => 'Excluir transações'
        ]
    ],
    'produtividade' => [
        'nome' => 'Produtividade',
        'icone' => 'bi-speedometer2',
        'cor' => 'info',
        'permissoes' => [
            'acesso' => 'Acesso ao módulo de produtividade'
        ]
    ],
    'academy' => [
        'nome' => 'Academy',
        'icone' => 'bi-mortarboard',
        'cor' => 'success',
        'permissoes' => [
            'acesso' => 'Acesso ao módulo Academy'
        ]
    ]
];

require_once 'templates/header.php';
?>

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="mb-0">
                    <i class="bi bi-building me-2"></i>Gestão de Contas
                </h2>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalNovaConta">
                    <i class="bi bi-plus-circle me-2"></i>Nova Conta
                </button>
            </div>
        </div>
    </div>

    <!-- Debug Info -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="alert alert-info">
                <h5>🔍 Informações de Debug</h5>
                <p><strong>Usuário ID:</strong> <?php echo $userId; ?></p>
                <p><strong>Contas encontradas:</strong> <?php echo count($contasUsuario); ?></p>
                <p><strong>Status da consulta:</strong> <?php echo !empty($contasUsuario) ? 'Sucesso' : 'Nenhuma conta encontrada'; ?></p>
            </div>
        </div>
    </div>

    <!-- Contas do Usuário -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="bi bi-list-ul me-2"></i>Suas Contas
                    </h5>
                </div>
                <div class="card-body">
                    <?php if (!empty($contasUsuario)): ?>
                        <div class="row">
                            <?php foreach ($contasUsuario as $conta): ?>
                                <div class="col-md-6 col-lg-4 mb-4">
                                    <div class="card h-100">
                                        <div class="card-header d-flex justify-content-between align-items-center">
                                            <h6 class="mb-0"><?php echo htmlspecialchars($conta['nome']); ?></h6>
                                            <span class="badge bg-<?php echo $conta['papel'] === 'proprietario' ? 'primary' : 'secondary'; ?>">
                                                <?php echo ucfirst($conta['papel']); ?>
                                            </span>
                                        </div>
                                        <div class="card-body">
                                            <p class="text-muted small mb-2">
                                                <i class="bi bi-info-circle me-1"></i>
                                                <?php echo htmlspecialchars($conta['descricao'] ?: 'Sem descrição'); ?>
                                            </p>
                                            <p class="text-muted small mb-2">
                                                <i class="bi bi-tag me-1"></i>
                                                <?php echo ucfirst($conta['tipo']); ?>
                                            </p>
                                            <p class="text-muted small mb-3">
                                                <i class="bi bi-calendar me-1"></i>
                                                <?php echo date('d/m/Y H:i', strtotime($conta['data_criacao'])); ?>
                                            </p>
                                            
                                            <?php if (isset($membrosContas[$conta['id']])): ?>
                                                <div class="mb-3">
                                                    <h6 class="small mb-2">Membros (<?php echo count($membrosContas[$conta['id']]); ?>)</h6>
                                                    <div class="d-flex flex-wrap gap-1">
                                                        <?php foreach ($membrosContas[$conta['id']] as $membro): ?>
                                                            <span class="badge bg-light text-dark small">
                                                                <?php echo htmlspecialchars($membro['email']); ?>
                                                                (<?php echo ucfirst($membro['papel']); ?>)
                                                            </span>
                                                        <?php endforeach; ?>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="card-footer">
                                            <div class="btn-group w-100" role="group">
                                                <button class="btn btn-outline-primary btn-sm" onclick="editarConta(<?php echo $conta['id']; ?>)">
                                                    <i class="bi bi-pencil"></i>
                                                </button>
                                                <button class="btn btn-outline-info btn-sm" onclick="gerenciarMembros(<?php echo $conta['id']; ?>)">
                                                    <i class="bi bi-people"></i>
                                                </button>
                                                <button class="btn btn-outline-danger btn-sm" onclick="excluirConta(<?php echo $conta['id']; ?>)">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="bi bi-inbox display-1 text-muted"></i>
                            <h4 class="text-muted mt-3">Nenhuma conta encontrada</h4>
                            <p class="text-muted">Você ainda não possui contas ou não tem acesso a nenhuma.</p>
                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalNovaConta">
                                <i class="bi bi-plus-circle me-2"></i>Criar Primeira Conta
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Nova Conta -->
<div class="modal fade" id="modalNovaConta" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="bi bi-plus-circle me-2"></i>Nova Conta
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="formNovaConta">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="nome" class="form-label">Nome da Conta</label>
                        <input type="text" class="form-control" id="nome" name="nome" required>
                    </div>
                    <div class="mb-3">
                        <label for="descricao" class="form-label">Descrição</label>
                        <textarea class="form-control" id="descricao" name="descricao" rows="3"></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="tipo" class="form-label">Tipo</label>
                        <select class="form-select" id="tipo" name="tipo" required>
                            <option value="pessoal">Pessoal</option>
                            <option value="empresarial">Empresarial</option>
                            <option value="familia">Família</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-check-circle me-2"></i>Criar Conta
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Criar nova conta
document.getElementById('formNovaConta').addEventListener('submit', function(e) {
    e.preventDefault();
    
    console.log('Formulário de nova conta submetido');
    
    const formData = new FormData(this);
    
    // Verificar se os dados estão sendo capturados
    console.log('Dados do formulário:');
    for (let [key, value] of formData.entries()) {
        console.log(key + ': ' + value);
    }
    
    fetch('criar_conta_simples.php', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        console.log('Resposta recebida:', response);
        return response.json();
    })
    .then(data => {
        console.log('Dados recebidos:', data);
        if (data.success) {
            alert('Conta criada com sucesso!');
            location.reload();
        } else {
            alert('Erro: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Erro:', error);
        alert('Erro de conexão: ' + error.message);
    });
});

// Funções para ações das contas
function editarConta(id) {
    console.log('Editar conta:', id);
    alert('Funcionalidade de edição em desenvolvimento');
}

function gerenciarMembros(id) {
    console.log('Gerenciar membros da conta:', id);
    alert('Funcionalidade de gerenciamento de membros em desenvolvimento');
}

function excluirConta(id) {
    console.log('Excluir conta:', id);
    if (confirm('Tem certeza que deseja excluir esta conta?')) {
        alert('Funcionalidade de exclusão em desenvolvimento');
    }
}
</script>

<?php require_once 'templates/footer.php'; ?>

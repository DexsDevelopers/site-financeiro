<?php
// gestao_contas.php - Interface principal de gestão de contas

require_once 'templates/header.php';
require_once 'includes/db_connect.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$userId = $_SESSION['user_id'];

// Buscar contas do usuário
$contasUsuario = [];
$membrosContas = [];
$convitesPendentes = [];

try {
    // Buscar contas onde o usuário é membro
    $stmt = $pdo->prepare("
        SELECT 
            c.*,
            cm.papel,
            cm.status as status_membro,
            u.nome as nome_proprietario
        FROM contas c
        JOIN conta_membros cm ON c.id = cm.conta_id
        LEFT JOIN usuarios u ON c.criado_por = u.id
        WHERE cm.usuario_id = ? AND cm.status = 'ativo'
        ORDER BY c.data_criacao DESC
    ");
    $stmt->execute([$userId]);
    $contasUsuario = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Buscar membros de cada conta (apenas para contas onde o usuário é proprietário ou administrador)
    foreach ($contasUsuario as $conta) {
        if (in_array($conta['papel'], ['proprietario', 'administrador'])) {
            $stmt = $pdo->prepare("
                SELECT 
                    cm.*,
                    u.nome,
                    u.email
                FROM conta_membros cm
                JOIN usuarios u ON cm.usuario_id = u.id
                WHERE cm.conta_id = ?
                ORDER BY cm.papel, u.nome
            ");
            $stmt->execute([$conta['id']]);
            $membrosContas[$conta['id']] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    }
    
    // Buscar convites pendentes
    $stmt = $pdo->prepare("
        SELECT 
            cc.*,
            c.nome as nome_conta,
            u.nome as nome_convidado_por
        FROM conta_convites cc
        JOIN contas c ON cc.conta_id = c.id
        JOIN usuarios u ON cc.convidado_por = u.id
        WHERE cc.email = (SELECT email FROM usuarios WHERE id = ?)
        AND cc.status = 'pendente'
        AND cc.data_expiracao > NOW()
        ORDER BY cc.data_convite DESC
    ");
    $stmt->execute([$userId]);
    $convitesPendentes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $contasUsuario = [];
    $membrosContas = [];
    $convitesPendentes = [];
}

?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h2 mb-0">
        <i class="bi bi-building me-2"></i>Gestão de Contas
    </h1>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalNovaConta">
        <i class="bi bi-plus-lg me-2"></i>Nova Conta
    </button>
</div>

<main class="container-fluid p-0">
    <div class="row g-4">
        
        <!-- Convites Pendentes -->
        <?php if (!empty($convitesPendentes)): ?>
        <div class="col-12">
            <div class="card card-glass">
                <div class="card-header">
                    <h4 class="card-title mb-0">
                        <i class="bi bi-envelope me-2"></i>Convites Pendentes
                    </h4>
                </div>
                <div class="card-body">
                    <?php foreach ($convitesPendentes as $convite): ?>
                    <div class="d-flex justify-content-between align-items-center p-3 mb-3 rounded" style="background: rgba(255, 255, 255, 0.05);">
                        <div>
                            <h6 class="mb-1">Convite para: <?php echo htmlspecialchars($convite['nome_conta']); ?></h6>
                            <small class="text-muted">
                                Convidado por: <?php echo htmlspecialchars($convite['nome_convidado_por']); ?> • 
                                Papel: <?php echo ucfirst($convite['papel']); ?> • 
                                Expira em: <?php echo date('d/m/Y H:i', strtotime($convite['data_expiracao'])); ?>
                            </small>
                        </div>
                        <div class="d-flex gap-2">
                            <button class="btn btn-success btn-sm" onclick="aceitarConvite(<?php echo $convite['id']; ?>)">
                                <i class="bi bi-check-lg me-1"></i>Aceitar
                            </button>
                            <button class="btn btn-danger btn-sm" onclick="recusarConvite(<?php echo $convite['id']; ?>)">
                                <i class="bi bi-x-lg me-1"></i>Recusar
                            </button>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Lista de Contas -->
        <div class="col-12">
            <div class="card card-glass">
                <div class="card-header">
                    <h4 class="card-title mb-0">
                        <i class="bi bi-building me-2"></i>Minhas Contas
                    </h4>
                </div>
                <div class="card-body">
                    <?php if (empty($contasUsuario)): ?>
                        <div class="text-center py-5">
                            <i class="bi bi-building" style="font-size: 3rem; color: #6c757d; opacity: 0.7;"></i>
                            <p class="text-muted mt-3">Você ainda não possui contas</p>
                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalNovaConta">
                                <i class="bi bi-plus-lg me-2"></i>Criar Primeira Conta
                            </button>
                        </div>
                    <?php else: ?>
                        <div class="row">
                            <?php foreach ($contasUsuario as $conta): ?>
                            <div class="col-lg-6 mb-4">
                                <div class="card h-100" style="background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1);">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-start mb-3">
                                            <div>
                                                <h5 class="card-title mb-1"><?php echo htmlspecialchars($conta['nome']); ?></h5>
                                                <p class="text-muted mb-0"><?php echo htmlspecialchars($conta['descricao']); ?></p>
                                            </div>
                                            <div class="d-flex gap-1">
                                                <span class="badge bg-<?php echo $conta['status'] === 'ativa' ? 'success' : 'secondary'; ?>">
                                                    <?php echo ucfirst($conta['status']); ?>
                                                </span>
                                                <span class="badge bg-info">
                                                    <?php echo ucfirst($conta['papel']); ?>
                                                </span>
                                            </div>
                                        </div>
                                        
                                        <div class="row text-center mb-3">
                                            <div class="col-4">
                                                <div class="text-primary fw-bold"><?php echo count($membrosContas[$conta['id']] ?? []); ?></div>
                                                <small class="text-muted">Membros</small>
                                            </div>
                                            <div class="col-4">
                                                <div class="text-success fw-bold"><?php echo ucfirst($conta['tipo']); ?></div>
                                                <small class="text-muted">Tipo</small>
                                            </div>
                                            <div class="col-4">
                                                <div class="text-info fw-bold"><?php echo date('d/m/Y', strtotime($conta['data_criacao'])); ?></div>
                                                <small class="text-muted">Criada</small>
                                            </div>
                                        </div>
                                        
                <div class="d-flex gap-2">
                    <button class="btn btn-outline-primary btn-sm" onclick="acessarConta(<?php echo $conta['id']; ?>)">
                        <i class="bi bi-box-arrow-in-right me-1"></i>Acessar
                    </button>
                    
                    <?php if (in_array($conta['papel'], ['proprietario', 'administrador'])): ?>
                    <button class="btn btn-outline-success btn-sm" onclick="criarUsuario(<?php echo $conta['id']; ?>)">
                        <i class="bi bi-person-plus me-1"></i>Criar Usuário
                    </button>
                    <button class="btn btn-outline-warning btn-sm" onclick="gerenciarMembros(<?php echo $conta['id']; ?>)">
                        <i class="bi bi-people me-1"></i>Membros
                    </button>
                    <button class="btn btn-outline-info btn-sm" onclick="configurarPermissoes(<?php echo $conta['id']; ?>)">
                        <i class="bi bi-shield-lock me-1"></i>Permissões
                    </button>
                    <?php endif; ?>
                    
                    <?php if ($conta['papel'] === 'proprietario'): ?>
                    <button class="btn btn-outline-danger btn-sm" onclick="excluirConta(<?php echo $conta['id']; ?>)">
                        <i class="bi bi-trash me-1"></i>Excluir
                    </button>
                    <?php endif; ?>
                </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- Modal Nova Conta -->
<div class="modal fade" id="modalNovaConta" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="background: var(--card-bg); border: 1px solid var(--border-color);">
            <div class="modal-header" style="border-bottom: 1px solid var(--border-color);">
                <h5 class="modal-title" style="color: var(--text-primary);">
                    <i class="bi bi-building me-2"></i>Nova Conta
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="formNovaConta">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="nomeConta" class="form-label">Nome da Conta</label>
                        <input type="text" class="form-control" id="nomeConta" name="nome" required>
                    </div>
                    <div class="mb-3">
                        <label for="descricaoConta" class="form-label">Descrição</label>
                        <textarea class="form-control" id="descricaoConta" name="descricao" rows="3"></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="tipoConta" class="form-label">Tipo da Conta</label>
                        <select class="form-select" id="tipoConta" name="tipo" required>
                            <option value="pessoal">Pessoal</option>
                            <option value="empresarial">Empresarial</option>
                            <option value="familia">Família</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer" style="border-top: 1px solid var(--border-color);">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-check-lg me-2"></i>Criar Conta
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Gerenciar Membros -->
<div class="modal fade" id="modalGerenciarMembros" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content" style="background: var(--card-bg); border: 1px solid var(--border-color);">
            <div class="modal-header" style="border-bottom: 1px solid var(--border-color);">
                <h5 class="modal-title" style="color: var(--text-primary);">
                    <i class="bi bi-people me-2"></i>Gerenciar Membros
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="listaMembros">
                    <!-- Lista de membros será carregada via JavaScript -->
                </div>
                
                <hr>
                
                <h6>Convidar Novo Membro</h6>
                <form id="formConvidarMembro">
                    <input type="hidden" id="contaIdConvite" name="conta_id">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="emailConvite" class="form-label">E-mail</label>
                            <input type="email" class="form-control" id="emailConvite" name="email" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="papelConvite" class="form-label">Papel</label>
                            <select class="form-select" id="papelConvite" name="papel" required>
                                <option value="membro">Membro</option>
                                <option value="administrador">Administrador</option>
                                <option value="visualizador">Visualizador</option>
                            </select>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-send me-2"></i>Enviar Convite
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal Criar Usuário -->
<div class="modal fade" id="modalCriarUsuario" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content" style="background: var(--card-bg); border: 1px solid var(--border-color);">
            <div class="modal-header" style="border-bottom: 1px solid var(--border-color);">
                <h5 class="modal-title" style="color: var(--text-primary);">
                    <i class="bi bi-person-plus me-2"></i>Criar Usuário para Conta
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="formCriarUsuario">
                <div class="modal-body">
                    <input type="hidden" id="contaIdUsuario" name="conta_id">
                    
                    <!-- Dados Básicos -->
                    <h6 class="text-primary mb-3">Dados Básicos</h6>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="nomeUsuario" class="form-label">Nome Completo</label>
                            <input type="text" class="form-control" id="nomeUsuario" name="nome" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="emailUsuario" class="form-label">E-mail</label>
                            <input type="email" class="form-control" id="emailUsuario" name="email" required>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="senhaUsuario" class="form-label">Senha</label>
                            <input type="password" class="form-control" id="senhaUsuario" name="senha" required minlength="6">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="confirmarSenhaUsuario" class="form-label">Confirmar Senha</label>
                            <input type="password" class="form-control" id="confirmarSenhaUsuario" name="confirmar_senha" required minlength="6">
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="papelUsuario" class="form-label">Papel na Conta</label>
                        <select class="form-select" id="papelUsuario" name="papel" required>
                            <option value="membro">Membro</option>
                            <option value="administrador">Administrador</option>
                            <option value="visualizador">Visualizador</option>
                        </select>
                    </div>
                    
                    <hr>
                    
                    <!-- Permissões Granulares -->
                    <h6 class="text-primary mb-3">Permissões Granulares</h6>
                    
                    <!-- Módulos -->
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <div class="card" style="background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1);">
                                <div class="card-body">
                                    <h6 class="card-title text-warning">
                                        <i class="bi bi-wallet2 me-2"></i>Financeiro
                                    </h6>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="perm_financeiro" name="perm_financeiro">
                                        <label class="form-check-label" for="perm_financeiro">
                                            Acesso ao módulo financeiro
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="perm_ver_saldo" name="perm_ver_saldo">
                                        <label class="form-check-label" for="perm_ver_saldo">
                                            Ver saldo e valores
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="perm_editar_financeiro" name="perm_editar_financeiro">
                                        <label class="form-check-label" for="perm_editar_financeiro">
                                            Editar transações
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="perm_excluir_financeiro" name="perm_excluir_financeiro">
                                        <label class="form-check-label" for="perm_excluir_financeiro">
                                            Excluir transações
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <div class="card" style="background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1);">
                                <div class="card-body">
                                    <h6 class="card-title text-info">
                                        <i class="bi bi-speedometer2 me-2"></i>Produtividade
                                    </h6>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="perm_produtividade" name="perm_produtividade">
                                        <label class="form-check-label" for="perm_produtividade">
                                            Acesso ao módulo de produtividade
                                        </label>
                                    </div>
                                    <small class="text-muted">Inclui tarefas, calendário, pomodoro, etc.</small>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <div class="card" style="background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1);">
                                <div class="card-body">
                                    <h6 class="card-title text-success">
                                        <i class="bi bi-mortarboard me-2"></i>Academy
                                    </h6>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="perm_academy" name="perm_academy">
                                        <label class="form-check-label" for="perm_academy">
                                            Acesso ao módulo Academy
                                        </label>
                                    </div>
                                    <small class="text-muted">Inclui cursos, treinos, alimentação, etc.</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle me-2"></i>
                        <strong>Dica:</strong> Você pode criar usuários com acesso restrito a módulos específicos. 
                        Por exemplo, um usuário pode ter acesso apenas à produtividade, sem ver dados financeiros.
                    </div>
                </div>
                <div class="modal-footer" style="border-top: 1px solid var(--border-color);">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-success">
                        <i class="bi bi-person-plus me-2"></i>Criar Usuário
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Configurar Permissões -->
<div class="modal fade" id="modalConfigurarPermissoes" tabindex="-1">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content" style="background: var(--card-bg); border: 1px solid var(--border-color);">
            <div class="modal-header" style="border-bottom: 1px solid var(--border-color);">
                <h5 class="modal-title" style="color: var(--text-primary);">
                    <i class="bi bi-shield-lock me-2"></i>Configurar Permissões
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="configuracaoPermissoes">
                    <!-- Configuração de permissões será carregada via JavaScript -->
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// ===== FUNÇÕES DE GESTÃO DE CONTAS =====

// Criar nova conta
document.getElementById('formNovaConta').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    
    fetch('criar_conta.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showToast('Sucesso!', data.message);
            setTimeout(() => location.reload(), 1000);
        } else {
            showToast('Erro!', data.message, true);
        }
    })
    .catch(error => {
        console.error('Erro:', error);
        showToast('Erro!', 'Erro de conexão', true);
    });
});

// Aceitar convite
function aceitarConvite(conviteId) {
    fetch('aceitar_convite.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ convite_id: conviteId })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showToast('Sucesso!', data.message);
            setTimeout(() => location.reload(), 1000);
        } else {
            showToast('Erro!', data.message, true);
        }
    })
    .catch(error => {
        console.error('Erro:', error);
        showToast('Erro!', 'Erro de conexão', true);
    });
}

// Recusar convite
function recusarConvite(conviteId) {
    if (confirm('Tem certeza que deseja recusar este convite?')) {
        fetch('recusar_convite.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ convite_id: conviteId })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast('Sucesso!', data.message);
                setTimeout(() => location.reload(), 1000);
            } else {
                showToast('Erro!', data.message, true);
            }
        })
        .catch(error => {
            console.error('Erro:', error);
            showToast('Erro!', 'Erro de conexão', true);
        });
    }
}

// Acessar conta
function acessarConta(contaId) {
    // Salvar conta ativa na sessão
    fetch('definir_conta_ativa.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ conta_id: contaId })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showToast('Sucesso!', 'Conta ativada com sucesso');
            setTimeout(() => window.location.href = 'dashboard.php', 1000);
        } else {
            showToast('Erro!', data.message, true);
        }
    })
    .catch(error => {
        console.error('Erro:', error);
        showToast('Erro!', 'Erro de conexão', true);
    });
}

// Gerenciar membros
function gerenciarMembros(contaId) {
    document.getElementById('contaIdConvite').value = contaId;
    
    // Carregar lista de membros
    fetch(`buscar_membros_conta.php?conta_id=${contaId}`)
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const listaMembros = document.getElementById('listaMembros');
            listaMembros.innerHTML = data.html;
        }
    })
    .catch(error => {
        console.error('Erro:', error);
    });
    
    const modal = new bootstrap.Modal(document.getElementById('modalGerenciarMembros'));
    modal.show();
}

// Configurar permissões
function configurarPermissoes(contaId) {
    // Carregar configuração de permissões
    fetch(`buscar_permissoes_conta.php?conta_id=${contaId}`)
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const configPermissoes = document.getElementById('configuracaoPermissoes');
            configPermissoes.innerHTML = data.html;
        }
    })
    .catch(error => {
        console.error('Erro:', error);
    });
    
    const modal = new bootstrap.Modal(document.getElementById('modalConfigurarPermissoes'));
    modal.show();
}

// Excluir conta
function excluirConta(contaId) {
    if (confirm('Tem certeza que deseja excluir esta conta? Esta ação não pode ser desfeita.')) {
        fetch('excluir_conta.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ conta_id: contaId })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast('Sucesso!', data.message);
                setTimeout(() => location.reload(), 1000);
            } else {
                showToast('Erro!', data.message, true);
            }
        })
        .catch(error => {
            console.error('Erro:', error);
            showToast('Erro!', 'Erro de conexão', true);
        });
    }
}

// Convidar membro
document.getElementById('formConvidarMembro').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    
    fetch('convidar_membro.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showToast('Sucesso!', data.message);
            setTimeout(() => location.reload(), 1000);
        } else {
            showToast('Erro!', data.message, true);
        }
    })
    .catch(error => {
        console.error('Erro:', error);
        showToast('Erro!', 'Erro de conexão', true);
    });
});

// Criar usuário
function criarUsuario(contaId) {
    document.getElementById('contaIdUsuario').value = contaId;
    
    const modal = new bootstrap.Modal(document.getElementById('modalCriarUsuario'));
    modal.show();
}

// Formulário de criar usuário
document.getElementById('formCriarUsuario').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    
    fetch('criar_usuario_conta.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showToast('Sucesso!', data.message);
            
            // Mostrar dados de login criado
            const loginInfo = `
                <div class="alert alert-success mt-3">
                    <h6><i class="bi bi-person-check me-2"></i>Usuário Criado com Sucesso!</h6>
                    <p><strong>Login:</strong> ${data.login}</p>
                    <p><strong>Senha:</strong> ${data.senha}</p>
                    <small class="text-muted">Anote estes dados para fornecer ao usuário.</small>
                </div>
            `;
            
            // Adicionar informações de login ao modal
            const modalBody = document.querySelector('#modalCriarUsuario .modal-body');
            modalBody.insertAdjacentHTML('beforeend', loginInfo);
            
            // Limpar formulário
            this.reset();
            
            setTimeout(() => {
                const modal = bootstrap.Modal.getInstance(document.getElementById('modalCriarUsuario'));
                modal.hide();
                location.reload();
            }, 3000);
        } else {
            showToast('Erro!', data.message, true);
        }
    })
    .catch(error => {
        console.error('Erro:', error);
        showToast('Erro!', 'Erro de conexão', true);
    });
});

// Atualizar permissão
function atualizarPermissao(usuarioId, modulo, permissao, permitido) {
    fetch('atualizar_permissao.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
            usuario_id: usuarioId, 
            modulo: modulo, 
            permissao: permissao, 
            permitido: permitido 
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showToast('Sucesso!', data.message);
        } else {
            showToast('Erro!', data.message, true);
        }
    })
    .catch(error => {
        console.error('Erro:', error);
        showToast('Erro!', 'Erro de conexão', true);
    });
}

// Editar permissões de um usuário
function editarPermissoes(usuarioId, nomeUsuario) {
    // Implementar modal de edição de permissões específicas
    showToast('Info', 'Funcionalidade de edição individual será implementada em breve');
}

// Remover membro
function removerMembro(usuarioId, nomeUsuario) {
    if (confirm(`Tem certeza que deseja remover ${nomeUsuario} da conta?`)) {
        fetch('remover_membro.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ usuario_id: usuarioId })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast('Sucesso!', data.message);
                setTimeout(() => location.reload(), 1000);
            } else {
                showToast('Erro!', data.message, true);
            }
        })
        .catch(error => {
            console.error('Erro:', error);
            showToast('Erro!', 'Erro de conexão', true);
        });
    }
}
</script>

<style>
.card-glass {
    background: rgba(30, 30, 30, 0.8);
    backdrop-filter: blur(20px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 12px;
}

.card-header {
    background: transparent;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.form-control, .form-select {
    background-color: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.1);
    color: var(--text-light);
}

.form-control:focus, .form-select:focus {
    background-color: rgba(255, 255, 255, 0.1);
    border-color: #007bff;
    box-shadow: 0 0 0 0.25rem rgba(0, 123, 255, 0.25);
}

.btn {
    transition: all 0.3s ease;
}

.btn:hover {
    transform: translateY(-2px);
}
</style>

<?php require_once 'templates/footer.php'; ?>

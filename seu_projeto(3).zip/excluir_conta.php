<?php
// excluir_conta.php - Excluir conta

session_start();
require_once 'includes/db_connect.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Acesso negado']);
    exit();
}

$userId = $_SESSION['user_id'];

// Verificar se é uma requisição POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit();
}

// Obter dados do POST
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['conta_id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'ID da conta não fornecido']);
    exit();
}

$contaId = (int)$input['conta_id'];

try {
    // Verificar se o usuário é proprietário da conta
    $stmt = $pdo->prepare("
        SELECT c.nome 
        FROM contas c
        JOIN conta_membros cm ON c.id = cm.conta_id
        WHERE c.id = ? AND cm.usuario_id = ? AND cm.papel = 'proprietario' AND cm.status = 'ativo'
    ");
    $stmt->execute([$contaId, $userId]);
    $conta = $stmt->fetch();
    
    if (!$conta) {
        echo json_encode(['success' => false, 'message' => 'Você não é proprietário desta conta']);
        exit();
    }
    
    // Excluir conta (cascade irá excluir membros, permissões, convites e logs)
    $stmt = $pdo->prepare("DELETE FROM contas WHERE id = ?");
    $stmt->execute([$contaId]);
    
    // Limpar conta ativa se for a mesma
    if (isset($_SESSION['conta_ativa_id']) && $_SESSION['conta_ativa_id'] == $contaId) {
        unset($_SESSION['conta_ativa_id']);
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'Conta excluída com sucesso!'
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao excluir conta: ' . $e->getMessage()
    ]);
}
?>

<?php
// buscar_permissoes_conta.php - Buscar permissões de uma conta

session_start();
require_once 'includes/db_connect.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Acesso negado']);
    exit();
}

$userId = $_SESSION['user_id'];
$contaId = (int)($_GET['conta_id'] ?? 0);

if ($contaId <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'ID da conta inválido']);
    exit();
}

try {
    // Verificar se o usuário tem permissão para configurar permissões
    $stmt = $pdo->prepare("
        SELECT cm.papel 
        FROM conta_membros cm 
        WHERE cm.conta_id = ? AND cm.usuario_id = ? AND cm.status = 'ativo'
    ");
    $stmt->execute([$contaId, $userId]);
    $membro = $stmt->fetch();
    
    if (!$membro || !in_array($membro['papel'], ['proprietario', 'administrador'])) {
        echo json_encode(['success' => false, 'message' => 'Você não tem permissão para configurar permissões desta conta']);
        exit();
    }
    
    // Buscar membros da conta
    $stmt = $pdo->prepare("
        SELECT 
            cm.usuario_id,
            u.nome,
            u.email,
            cm.papel,
            cm.status
        FROM conta_membros cm
        JOIN usuarios u ON cm.usuario_id = u.id
        WHERE cm.conta_id = ?
        ORDER BY u.nome
    ");
    $stmt->execute([$contaId]);
    $membros = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Gerar HTML das permissões
    $html = '<div class="row">';
    
    foreach ($membros as $membro) {
        // Buscar permissões do membro
        $stmt = $pdo->prepare("
            SELECT modulo, permissao, permitido 
            FROM conta_permissoes 
            WHERE conta_id = ? AND usuario_id = ?
            ORDER BY modulo, permissao
        ");
        $stmt->execute([$contaId, $membro['usuario_id']]);
        $permissoes = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Organizar permissões por módulo
        $permissoesPorModulo = [];
        foreach ($permissoes as $permissao) {
            $permissoesPorModulo[$permissao['modulo']][] = $permissao;
        }
        
        $html .= '<div class="col-12 mb-4">';
        $html .= '<div class="card" style="background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1);">';
        $html .= '<div class="card-header">';
        $html .= '<h6 class="mb-0">';
        $html .= '<i class="bi bi-person me-2"></i>' . htmlspecialchars($membro['nome']);
        $html .= '<span class="badge bg-' . ($membro['papel'] === 'proprietario' ? 'danger' : ($membro['papel'] === 'administrador' ? 'warning' : 'primary')) . ' ms-2">' . ucfirst($membro['papel']) . '</span>';
        $html .= '</h6>';
        $html .= '</div>';
        $html .= '<div class="card-body">';
        
        // Módulos
        $modulos = [
            'financeiro' => ['nome' => 'Financeiro', 'icone' => 'bi-wallet2', 'cor' => 'warning'],
            'produtividade' => ['nome' => 'Produtividade', 'icone' => 'bi-speedometer2', 'cor' => 'info'],
            'academy' => ['nome' => 'Academy', 'icone' => 'bi-mortarboard', 'cor' => 'success']
        ];
        
        $html .= '<div class="row">';
        
        foreach ($modulos as $modulo => $info) {
            $html .= '<div class="col-md-4 mb-3">';
            $html .= '<div class="card" style="background: rgba(255, 255, 255, 0.03); border: 1px solid rgba(255, 255, 255, 0.1);">';
            $html .= '<div class="card-header">';
            $html .= '<h6 class="mb-0 text-' . $info['cor'] . '">';
            $html .= '<i class="bi ' . $info['icone'] . ' me-2"></i>' . $info['nome'];
            $html .= '</h6>';
            $html .= '</div>';
            $html .= '<div class="card-body">';
            
            if (isset($permissoesPorModulo[$modulo])) {
                foreach ($permissoesPorModulo[$modulo] as $permissao) {
                    $checked = $permissao['permitido'] ? 'checked' : '';
                    $permissaoId = 'perm_' . $membro['usuario_id'] . '_' . $modulo . '_' . $permissao['permissao'];
                    
                    $html .= '<div class="form-check">';
                    $html .= '<input class="form-check-input" type="checkbox" id="' . $permissaoId . '" ' . $checked . ' onchange="atualizarPermissao(' . $membro['usuario_id'] . ', \'' . $modulo . '\', \'' . $permissao['permissao'] . '\', this.checked)">';
                    $html .= '<label class="form-check-label" for="' . $permissaoId . '">';
                    $html .= ucfirst(str_replace('_', ' ', $permissao['permissao']));
                    $html .= '</label>';
                    $html .= '</div>';
                }
            } else {
                $html .= '<small class="text-muted">Nenhuma permissão específica</small>';
            }
            
            $html .= '</div>';
            $html .= '</div>';
            $html .= '</div>';
        }
        
        $html .= '</div>';
        $html .= '</div>';
        $html .= '</div>';
        $html .= '</div>';
    }
    
    $html .= '</div>';
    
    echo json_encode([
        'success' => true,
        'html' => $html,
        'total' => count($membros)
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao buscar permissões: ' . $e->getMessage()
    ]);
}
?>

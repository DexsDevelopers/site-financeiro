<?php
// configurar_permissoes.php - Configurar permissões de usuários

session_start();
require_once 'includes/db_connect.php';
require_once 'includes/verificar_permissoes.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$userId = $_SESSION['user_id'];

// Verificar se o usuário tem permissão para configurar permissões
// Por enquanto, permitir acesso a todos os usuários logados
// TODO: Implementar verificação de permissões quando o sistema estiver completo

// Buscar contas do usuário
try {
    $stmt = $pdo->prepare("
        SELECT 
            c.*,
            cm.papel,
            cm.status as status_membro
        FROM contas c
        JOIN conta_membros cm ON c.id = cm.conta_id
        WHERE cm.usuario_id = ? AND cm.status = 'ativo'
        ORDER BY c.data_criacao DESC
    ");
    $stmt->execute([$userId]);
    $contas = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $contas = [];
}

// Buscar membros da conta ativa
$membros = [];
$contaAtiva = null;

if (isset($_GET['conta_id'])) {
    $contaId = (int)$_GET['conta_id'];
    
    try {
        // Verificar se o usuário tem acesso à conta
        $stmt = $pdo->prepare("
            SELECT cm.papel 
            FROM conta_membros cm 
            WHERE cm.conta_id = ? AND cm.usuario_id = ? AND cm.status = 'ativo'
        ");
        $stmt->execute([$contaId, $userId]);
        $membro = $stmt->fetch();
        
        if ($membro && in_array($membro['papel'], ['proprietario', 'administrador'])) {
            // Buscar membros da conta
            $stmt = $pdo->prepare("
                SELECT 
                    cm.*,
                    u.nome,
                    u.email,
                    u.data_criacao as data_cadastro
                FROM conta_membros cm
                JOIN usuarios u ON cm.usuario_id = u.id
                WHERE cm.conta_id = ?
                ORDER BY cm.papel, u.nome
            ");
            $stmt->execute([$contaId]);
            $membros = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Buscar informações da conta
            $stmt = $pdo->prepare("SELECT * FROM contas WHERE id = ?");
            $stmt->execute([$contaId]);
            $contaAtiva = $stmt->fetch(PDO::FETCH_ASSOC);
        }
    } catch (PDOException $e) {
        $membros = [];
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configurar Permissões - Painel Financeiro</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    
    <style>
        :root {
            --primary-color: #e50914;
            --secondary-color: #221f1f;
            --accent-color: #00b894;
            --text-primary: #ffffff;
            --text-secondary: #adb5bd;
            --border-color: rgba(255, 255, 255, 0.1);
            --card-bg: rgba(30, 30, 30, 0.8);
        }
        
        body {
            background: linear-gradient(135deg, #0c0c0c 0%, #1a1a1a 100%);
            color: var(--text-primary);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .card-glass {
            background: rgba(30, 30, 30, 0.8);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 15px;
        }
        
        .btn-primary {
            background: linear-gradient(45deg, var(--primary-color), #ff6b6b);
            border: none;
            border-radius: 8px;
            padding: 0.75rem 1.5rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(229, 9, 20, 0.3);
        }
        
        .permission-card {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            padding: 1rem;
            margin-bottom: 1rem;
            transition: all 0.3s ease;
        }
        
        .permission-card:hover {
            background: rgba(255, 255, 255, 0.08);
            transform: translateY(-2px);
        }
        
        .form-check-input:checked {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .member-card {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            padding: 1rem;
            margin-bottom: 1rem;
        }
        
        .badge-role {
            font-size: 0.8rem;
            padding: 0.5rem 1rem;
            border-radius: 20px;
        }
        
        .badge-proprietario { background: linear-gradient(45deg, #dc3545, #c82333); }
        .badge-administrador { background: linear-gradient(45deg, #fd7e14, #e8590c); }
        .badge-membro { background: linear-gradient(45deg, #0d6efd, #0b5ed7); }
        .badge-visualizador { background: linear-gradient(45deg, #6c757d, #5a6268); }
    </style>
</head>
<body>
    <?php include 'templates/header.php'; ?>
    
    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12">
                <!-- Header -->
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h2 class="text-white mb-0">
                            <i class="bi bi-shield-lock me-2"></i>Configurar Permissões
                        </h2>
                        <p class="text-muted mb-0">Gerencie as permissões dos usuários em suas contas</p>
                    </div>
                    <a href="gestao_contas.php" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-left me-2"></i>Voltar
                    </a>
                </div>
                
                <!-- Seleção de Conta -->
                <?php if (!empty($contas)): ?>
                <div class="card card-glass mb-4">
                    <div class="card-body">
                        <h5 class="card-title text-white">
                            <i class="bi bi-building me-2"></i>Selecionar Conta
                        </h5>
                        <div class="row">
                            <?php foreach ($contas as $conta): ?>
                            <div class="col-md-6 mb-3">
                                <div class="card member-card">
                                    <div class="card-body">
                                        <h6 class="card-title text-white"><?php echo htmlspecialchars($conta['nome']); ?></h6>
                                        <p class="card-text text-muted"><?php echo htmlspecialchars($conta['descricao'] ?? ''); ?></p>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <span class="badge badge-<?php echo $conta['papel']; ?> badge-role">
                                                <?php echo ucfirst($conta['papel']); ?>
                                            </span>
                                            <a href="?conta_id=<?php echo $conta['id']; ?>" 
                                               class="btn btn-sm btn-primary">
                                                <i class="bi bi-gear me-1"></i>Configurar
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- Configuração de Permissões -->
                <?php if ($contaAtiva && !empty($membros)): ?>
                <div class="card card-glass">
                    <div class="card-header">
                        <h5 class="card-title text-white mb-0">
                            <i class="bi bi-people me-2"></i>Permissões - <?php echo htmlspecialchars($contaAtiva['nome']); ?>
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php foreach ($membros as $membro): ?>
                        <div class="member-card">
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <div>
                                    <h6 class="text-white mb-1"><?php echo htmlspecialchars($membro['nome']); ?></h6>
                                    <small class="text-muted"><?php echo htmlspecialchars($membro['email']); ?></small>
                                </div>
                                <span class="badge badge-<?php echo $membro['papel']; ?> badge-role">
                                    <?php echo ucfirst($membro['papel']); ?>
                                </span>
                            </div>
                            
                            <!-- Permissões por Módulo -->
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="permission-card">
                                        <h6 class="text-warning mb-3">
                                            <i class="bi bi-wallet2 me-2"></i>Financeiro
                                        </h6>
                                        <div class="form-check mb-2">
                                            <input class="form-check-input" type="checkbox" 
                                                   id="perm_<?php echo $membro['usuario_id']; ?>_financeiro_visualizar_saldo"
                                                   onchange="atualizarPermissao(<?php echo $membro['usuario_id']; ?>, 'financeiro', 'visualizar_saldo', this.checked)">
                                            <label class="form-check-label" for="perm_<?php echo $membro['usuario_id']; ?>_financeiro_visualizar_saldo">
                                                Ver Saldo
                                            </label>
                                        </div>
                                        <div class="form-check mb-2">
                                            <input class="form-check-input" type="checkbox" 
                                                   id="perm_<?php echo $membro['usuario_id']; ?>_financeiro_editar_transacoes"
                                                   onchange="atualizarPermissao(<?php echo $membro['usuario_id']; ?>, 'financeiro', 'editar_transacoes', this.checked)">
                                            <label class="form-check-label" for="perm_<?php echo $membro['usuario_id']; ?>_financeiro_editar_transacoes">
                                                Editar Transações
                                            </label>
                                        </div>
                                        <div class="form-check mb-2">
                                            <input class="form-check-input" type="checkbox" 
                                                   id="perm_<?php echo $membro['usuario_id']; ?>_financeiro_excluir_transacoes"
                                                   onchange="atualizarPermissao(<?php echo $membro['usuario_id']; ?>, 'financeiro', 'excluir_transacoes', this.checked)">
                                            <label class="form-check-label" for="perm_<?php echo $membro['usuario_id']; ?>_financeiro_excluir_transacoes">
                                                Excluir Transações
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" 
                                                   id="perm_<?php echo $membro['usuario_id']; ?>_financeiro_gerar_relatorios"
                                                   onchange="atualizarPermissao(<?php echo $membro['usuario_id']; ?>, 'financeiro', 'gerar_relatorios', this.checked)">
                                            <label class="form-check-label" for="perm_<?php echo $membro['usuario_id']; ?>_financeiro_gerar_relatorios">
                                                Gerar Relatórios
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="permission-card">
                                        <h6 class="text-info mb-3">
                                            <i class="bi bi-speedometer2 me-2"></i>Produtividade
                                        </h6>
                                        <div class="form-check mb-2">
                                            <input class="form-check-input" type="checkbox" 
                                                   id="perm_<?php echo $membro['usuario_id']; ?>_produtividade_visualizar_tarefas"
                                                   onchange="atualizarPermissao(<?php echo $membro['usuario_id']; ?>, 'produtividade', 'visualizar_tarefas', this.checked)">
                                            <label class="form-check-label" for="perm_<?php echo $membro['usuario_id']; ?>_produtividade_visualizar_tarefas">
                                                Visualizar Tarefas
                                            </label>
                                        </div>
                                        <div class="form-check mb-2">
                                            <input class="form-check-input" type="checkbox" 
                                                   id="perm_<?php echo $membro['usuario_id']; ?>_produtividade_editar_tarefas"
                                                   onchange="atualizarPermissao(<?php echo $membro['usuario_id']; ?>, 'produtividade', 'editar_tarefas', this.checked)">
                                            <label class="form-check-label" for="perm_<?php echo $membro['usuario_id']; ?>_produtividade_editar_tarefas">
                                                Editar Tarefas
                                            </label>
                                        </div>
                                        <div class="form-check mb-2">
                                            <input class="form-check-input" type="checkbox" 
                                                   id="perm_<?php echo $membro['usuario_id']; ?>_produtividade_excluir_tarefas"
                                                   onchange="atualizarPermissao(<?php echo $membro['usuario_id']; ?>, 'produtividade', 'excluir_tarefas', this.checked)">
                                            <label class="form-check-label" for="perm_<?php echo $membro['usuario_id']; ?>_produtividade_excluir_tarefas">
                                                Excluir Tarefas
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" 
                                                   id="perm_<?php echo $membro['usuario_id']; ?>_produtividade_gerar_relatorios"
                                                   onchange="atualizarPermissao(<?php echo $membro['usuario_id']; ?>, 'produtividade', 'gerar_relatorios', this.checked)">
                                            <label class="form-check-label" for="perm_<?php echo $membro['usuario_id']; ?>_produtividade_gerar_relatorios">
                                                Gerar Relatórios
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="permission-card">
                                        <h6 class="text-success mb-3">
                                            <i class="bi bi-mortarboard me-2"></i>Academy
                                        </h6>
                                        <div class="form-check mb-2">
                                            <input class="form-check-input" type="checkbox" 
                                                   id="perm_<?php echo $membro['usuario_id']; ?>_academy_visualizar_cursos"
                                                   onchange="atualizarPermissao(<?php echo $membro['usuario_id']; ?>, 'academy', 'visualizar_cursos', this.checked)">
                                            <label class="form-check-label" for="perm_<?php echo $membro['usuario_id']; ?>_academy_visualizar_cursos">
                                                Visualizar Cursos
                                            </label>
                                        </div>
                                        <div class="form-check mb-2">
                                            <input class="form-check-input" type="checkbox" 
                                                   id="perm_<?php echo $membro['usuario_id']; ?>_academy_editar_cursos"
                                                   onchange="atualizarPermissao(<?php echo $membro['usuario_id']; ?>, 'academy', 'editar_cursos', this.checked)">
                                            <label class="form-check-label" for="perm_<?php echo $membro['usuario_id']; ?>_academy_editar_cursos">
                                                Editar Cursos
                                            </label>
                                        </div>
                                        <div class="form-check mb-2">
                                            <input class="form-check-input" type="checkbox" 
                                                   id="perm_<?php echo $membro['usuario_id']; ?>_academy_excluir_cursos"
                                                   onchange="atualizarPermissao(<?php echo $membro['usuario_id']; ?>, 'academy', 'excluir_cursos', this.checked)">
                                            <label class="form-check-label" for="perm_<?php echo $membro['usuario_id']; ?>_academy_excluir_cursos">
                                                Excluir Cursos
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" 
                                                   id="perm_<?php echo $membro['usuario_id']; ?>_academy_gerar_relatorios"
                                                   onchange="atualizarPermissao(<?php echo $membro['usuario_id']; ?>, 'academy', 'gerar_relatorios', this.checked)">
                                            <label class="form-check-label" for="perm_<?php echo $membro['usuario_id']; ?>_academy_gerar_relatorios">
                                                Gerar Relatórios
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php elseif ($contaAtiva && empty($membros)): ?>
                <div class="card card-glass">
                    <div class="card-body text-center">
                        <i class="bi bi-people text-muted" style="font-size: 3rem;"></i>
                        <h5 class="text-white mt-3">Nenhum Membro Encontrado</h5>
                        <p class="text-muted">Esta conta não possui membros ou você não tem permissão para visualizá-los.</p>
                        <a href="gestao_contas.php" class="btn btn-primary">
                            <i class="bi bi-plus me-2"></i>Adicionar Membros
                        </a>
                    </div>
                </div>
                <?php else: ?>
                <div class="card card-glass">
                    <div class="card-body text-center">
                        <i class="bi bi-building text-muted" style="font-size: 3rem;"></i>
                        <h5 class="text-white mt-3">Selecione uma Conta</h5>
                        <p class="text-muted">Escolha uma conta para configurar as permissões dos membros.</p>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Atualizar permissão
        function atualizarPermissao(usuarioId, modulo, permissao, permitido) {
            fetch('atualizar_permissao.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    usuario_id: usuarioId, 
                    modulo: modulo, 
                    permissao: permissao, 
                    permitido: permitido 
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showToast('Sucesso!', data.message);
                } else {
                    showToast('Erro!', data.message, true);
                }
            })
            .catch(error => {
                console.error('Erro:', error);
                showToast('Erro!', 'Erro de conexão', true);
            });
        }
        
        // Função para mostrar toast
        function showToast(title, message, isError = false) {
            const toast = document.createElement('div');
            toast.className = `toast align-items-center text-white ${isError ? 'bg-danger' : 'bg-success'} border-0`;
            toast.setAttribute('role', 'alert');
            toast.innerHTML = `
                <div class="d-flex">
                    <div class="toast-body">
                        <strong>${title}</strong><br>
                        ${message}
                    </div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                </div>
            `;
            
            document.body.appendChild(toast);
            const bsToast = new bootstrap.Toast(toast);
            bsToast.show();
            
            setTimeout(() => {
                document.body.removeChild(toast);
            }, 5000);
        }
    </script>
</body>
</html>

<?php
// teste_menu_sistema.php - Teste do menu do sistema

session_start();
require_once 'includes/db_connect.php';
require_once 'includes/load_menu_config.php';

echo "<h2>🧪 TESTE DO MENU DO SISTEMA</h2>";

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    echo "❌ Usuário não está logado. Faça login primeiro.<br>";
    echo "<a href='login.php' class='btn btn-primary'>Fazer Login</a><br><br>";
    exit();
}

$userId = $_SESSION['user_id'];
echo "✅ Usuário logado: ID $userId<br><br>";

// 1. Verificar configuração do menu
echo "<h3>1. Verificando Configuração do Menu</h3>";

if (isset($menu_config)) {
    echo "✅ Configuração do menu carregada<br>";
    
    // Verificar seções visíveis
    if (isset($menu_config['secoes_visiveis'])) {
        echo "📋 Seções visíveis:<br>";
        foreach ($menu_config['secoes_visiveis'] as $secao => $visivel) {
            $status = $visivel ? '✅' : '❌';
            echo "$status $secao: " . ($visivel ? 'VISÍVEL' : 'OCULTA') . "<br>";
        }
    }
    
    // Verificar páginas do sistema
    if (isset($menu_config['paginas_visiveis']['sistema'])) {
        echo "<br>📄 Páginas do sistema:<br>";
        foreach ($menu_config['paginas_visiveis']['sistema'] as $pagina) {
            echo "&nbsp;&nbsp;- $pagina<br>";
        }
    }
} else {
    echo "❌ Configuração do menu não carregada<br>";
}

echo "<hr>";

// 2. Verificar seções e páginas
echo "<h3>2. Verificando Seções e Páginas</h3>";

if (isset($secoesPaginas)) {
    echo "✅ Seções e páginas carregadas<br>";
    
    foreach ($secoesPaginas as $secao => $paginas) {
        echo "<br><strong>$secao:</strong><br>";
        foreach ($paginas as $pagina) {
            echo "&nbsp;&nbsp;- $pagina<br>";
        }
    }
} else {
    echo "❌ Seções e páginas não carregadas<br>";
}

echo "<hr>";

// 3. Verificar informações das seções
echo "<h3>3. Verificando Informações das Seções</h3>";

if (isset($secoesInfo)) {
    echo "✅ Informações das seções carregadas<br>";
    
    foreach ($secoesInfo as $secao => $info) {
        echo "<br><strong>$secao:</strong><br>";
        echo "&nbsp;&nbsp;- Nome: {$info['nome']}<br>";
        echo "&nbsp;&nbsp;- Ícone: {$info['icone']}<br>";
        echo "&nbsp;&nbsp;- Cor: {$info['cor']}<br>";
    }
} else {
    echo "❌ Informações das seções não carregadas<br>";
}

echo "<hr>";

// 4. Verificar informações das páginas
echo "<h3>4. Verificando Informações das Páginas</h3>";

if (isset($paginasInfo)) {
    echo "✅ Informações das páginas carregadas<br>";
    
    $paginasSistema = array_filter($paginasInfo, function($key) {
        return in_array($key, ['gestao_contas.php', 'configurar_permissoes.php', 'logs_atividades.php']);
    }, ARRAY_FILTER_USE_KEY);
    
    if (!empty($paginasSistema)) {
        echo "<br>📄 Páginas do sistema encontradas:<br>";
        foreach ($paginasSistema as $pagina => $info) {
            echo "&nbsp;&nbsp;- $pagina: {$info['nome']} ({$info['icone']})<br>";
        }
    } else {
        echo "❌ Páginas do sistema não encontradas<br>";
    }
} else {
    echo "❌ Informações das páginas não carregadas<br>";
}

echo "<hr>";

// 5. Verificar seção ativa
echo "<h3>5. Verificando Seção Ativa</h3>";

if (isset($secaoAtiva)) {
    echo "✅ Seção ativa: $secaoAtiva<br>";
} else {
    echo "❌ Seção ativa não definida<br>";
}

echo "<hr>";

// 6. Verificar arquivos do sistema
echo "<h3>6. Verificando Arquivos do Sistema</h3>";

$arquivosSistema = [
    'gestao_contas.php' => 'Interface de gestão de contas',
    'configurar_permissoes.php' => 'Configuração de permissões',
    'logs_atividades.php' => 'Logs de atividades',
    'criar_usuario_conta.php' => 'API para criar usuários',
    'definir_conta_ativa.php' => 'API para definir conta ativa'
];

$arquivosOk = 0;

foreach ($arquivosSistema as $arquivo => $descricao) {
    if (file_exists($arquivo)) {
        echo "✅ $arquivo - $descricao<br>";
        $arquivosOk++;
    } else {
        echo "❌ $arquivo - $descricao (NÃO ENCONTRADO)<br>";
    }
}

echo "<p><strong>Arquivos OK: $arquivosOk/" . count($arquivosSistema) . "</strong></p>";

echo "<hr>";

// 7. Teste de renderização do menu
echo "<h3>7. Teste de Renderização do Menu</h3>";

echo "<div style='background: #f8f9fa; padding: 1rem; border-radius: 8px; margin: 1rem 0;'>";
echo "<h6>Estrutura do Menu que seria renderizada:</h6>";

if (isset($secoesPaginas) && isset($secoesInfo)) {
    foreach ($secoesPaginas as $secao => $paginas) {
        if (!empty($paginas) && isset($secoesInfo[$secao])) {
            $info = $secoesInfo[$secao];
            echo "<div style='margin: 0.5rem 0; padding: 0.5rem; background: white; border-radius: 4px;'>";
            echo "<strong><i class='bi {$info['icone']}' style='color: {$info['cor']};'></i> {$info['nome']}</strong><br>";
            
            foreach ($paginas as $pagina) {
                if (isset($paginasInfo[$pagina])) {
                    $paginaInfo = $paginasInfo[$pagina];
                    echo "&nbsp;&nbsp;• <i class='bi {$paginaInfo['icone']}'></i> {$paginaInfo['nome']} ($pagina)<br>";
                }
            }
            echo "</div>";
        }
    }
} else {
    echo "❌ Dados necessários não carregados<br>";
}

echo "</div>";

echo "<hr>";

// 8. Resumo final
echo "<h2>📊 RESUMO FINAL</h2>";

$total_verificacoes = 8;
$verificacoes_ok = 0;

// Contar verificações OK
if (isset($menu_config)) $verificacoes_ok++;
if (isset($secoesPaginas)) $verificacoes_ok++;
if (isset($secoesInfo)) $verificacoes_ok++;
if (isset($paginasInfo)) $verificacoes_ok++;
if (isset($secaoAtiva)) $verificacoes_ok++;
if ($arquivosOk >= count($arquivosSistema) * 0.8) $verificacoes_ok++;
if (isset($secoesPaginas) && isset($secoesInfo)) $verificacoes_ok++;
if (isset($secoesPaginas) && isset($secoesInfo)) $verificacoes_ok++;

echo "<p><strong>Verificações OK: $verificacoes_ok/$total_verificacoes</strong></p>";

if ($verificacoes_ok >= $total_verificacoes * 0.8) {
    echo "<div style='background: #d4edda; padding: 1rem; border-radius: 8px; margin: 1rem 0;'>";
    echo "<h4>✅ Menu do Sistema Funcionando!</h4>";
    echo "<p>O menu está configurado corretamente. Você pode:</p>";
    echo "<ul>";
    echo "<li>🏢 <a href='gestao_contas.php'>Gerenciar contas</a></li>";
    echo "<li>👥 Criar usuários com permissões granulares</li>";
    echo "<li>🔐 Controlar acesso a módulos específicos</li>";
    echo "<li>📊 Visualizar logs de atividades</li>";
    echo "</ul>";
    echo "</div>";
} else {
    echo "<div style='background: #f8d7da; padding: 1rem; border-radius: 8px; margin: 1rem 0;'>";
    echo "<h4>❌ Menu Precisa de Ajustes</h4>";
    echo "<p>Algumas configurações ainda precisam ser implementadas. Verifique os itens marcados com ❌ acima.</p>";
    echo "<ol>";
    echo "<li>Verifique se o arquivo includes/load_menu_config.php está correto</li>";
    echo "<li>Certifique-se de que todos os arquivos do sistema existem</li>";
    echo "<li>Teste o menu em uma página real</li>";
    echo "</ol>";
    echo "</div>";
}

echo "<hr>";
echo "<p><strong>✅ Teste concluído!</strong> Use as recomendações acima para resolver os problemas.</p>";
?>

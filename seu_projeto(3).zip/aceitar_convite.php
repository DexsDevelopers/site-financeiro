<?php
// aceitar_convite.php - Aceitar convite para conta

session_start();
require_once 'includes/db_connect.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Acesso negado']);
    exit();
}

$userId = $_SESSION['user_id'];

// Verificar se é uma requisição POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit();
}

// Obter dados do POST
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['convite_id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'ID do convite não fornecido']);
    exit();
}

$conviteId = (int)$input['convite_id'];

try {
    // Verificar se o convite existe e é válido
    $stmt = $pdo->prepare("
        SELECT cc.*, c.nome as nome_conta 
        FROM conta_convites cc
        JOIN contas c ON cc.conta_id = c.id
        WHERE cc.id = ? AND cc.status = 'pendente' AND cc.data_expiracao > NOW()
    ");
    $stmt->execute([$conviteId]);
    $convite = $stmt->fetch();
    
    if (!$convite) {
        echo json_encode(['success' => false, 'message' => 'Convite não encontrado ou expirado']);
        exit();
    }
    
    // Verificar se o usuário já é membro da conta
    $stmt = $pdo->prepare("
        SELECT id FROM conta_membros 
        WHERE conta_id = ? AND usuario_id = ?
    ");
    $stmt->execute([$convite['conta_id'], $userId]);
    
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Você já é membro desta conta']);
        exit();
    }
    
    // Adicionar usuário como membro da conta
    $stmt = $pdo->prepare("
        INSERT INTO conta_membros (conta_id, usuario_id, papel, status, data_aceite, convidado_por) 
        VALUES (?, ?, ?, 'ativo', NOW(), ?)
    ");
    $stmt->execute([$convite['conta_id'], $userId, $convite['papel'], $convite['convidado_por']]);
    
    // Atualizar status do convite
    $stmt = $pdo->prepare("
        UPDATE conta_convites 
        SET status = 'aceito', data_aceite = NOW() 
        WHERE id = ?
    ");
    $stmt->execute([$conviteId]);
    
    // Criar permissões padrão baseadas no papel
    $permissoesPadrao = [];
    
    switch ($convite['papel']) {
        case 'administrador':
            $permissoesPadrao = [
                ['financeiro', 'visualizar_saldo', true],
                ['financeiro', 'editar_transacoes', true],
                ['financeiro', 'excluir_transacoes', true],
                ['financeiro', 'gerar_relatorios', true],
                ['produtividade', 'visualizar_tarefas', true],
                ['produtividade', 'editar_tarefas', true],
                ['produtividade', 'excluir_tarefas', true],
                ['produtividade', 'gerar_relatorios', true],
                ['academy', 'visualizar_cursos', true],
                ['academy', 'editar_cursos', true],
                ['academy', 'excluir_cursos', true],
                ['academy', 'gerar_relatorios', true],
                ['sistema', 'gerenciar_usuarios', true],
                ['sistema', 'visualizar_logs', true]
            ];
            break;
            
        case 'membro':
            $permissoesPadrao = [
                ['financeiro', 'visualizar_saldo', true],
                ['financeiro', 'editar_transacoes', true],
                ['financeiro', 'gerar_relatorios', true],
                ['produtividade', 'visualizar_tarefas', true],
                ['produtividade', 'editar_tarefas', true],
                ['produtividade', 'gerar_relatorios', true],
                ['academy', 'visualizar_cursos', true],
                ['academy', 'editar_cursos', true],
                ['academy', 'gerar_relatorios', true]
            ];
            break;
            
        case 'visualizador':
            $permissoesPadrao = [
                ['financeiro', 'visualizar_saldo', true],
                ['financeiro', 'gerar_relatorios', true],
                ['produtividade', 'visualizar_tarefas', true],
                ['produtividade', 'gerar_relatorios', true],
                ['academy', 'visualizar_cursos', true],
                ['academy', 'gerar_relatorios', true]
            ];
            break;
    }
    
    foreach ($permissoesPadrao as $permissao) {
        $stmt = $pdo->prepare("
            INSERT INTO conta_permissoes (conta_id, usuario_id, modulo, permissao, permitido) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([$convite['conta_id'], $userId, $permissao[0], $permissao[1], $permissao[2]]);
    }
    
    // Registrar log
    $stmt = $pdo->prepare("
        INSERT INTO conta_logs (conta_id, usuario_id, acao, modulo, detalhes) 
        VALUES (?, ?, 'convite_aceito', 'sistema', ?)
    ");
    $stmt->execute([$convite['conta_id'], $userId, "Convite aceito para conta '{$convite['nome_conta']}'"]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Convite aceito com sucesso!',
        'conta_nome' => $convite['nome_conta']
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao aceitar convite: ' . $e->getMessage()
    ]);
}
?>

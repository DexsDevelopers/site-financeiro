<?php
// teste_criacao_conta.php - Teste isolado da criação de contas

session_start();
require_once 'includes/db_connect.php';

// Ativar debug
ini_set('display_errors', 1);
error_reporting(E_ALL);

echo "<h2>🧪 TESTE DE CRIAÇÃO DE CONTA</h2>";

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    echo "❌ Usuário não está logado. Faça login primeiro.<br>";
    echo "<a href='login.php' class='btn btn-primary'>Fazer Login</a><br><br>";
    exit();
}

$userId = $_SESSION['user_id'];
echo "✅ Usuário logado: ID $userId<br><br>";

// 1. Verificar estrutura das tabelas
echo "<h3>1. Verificando Estrutura das Tabelas</h3>";

try {
    // Verificar tabela contas
    $stmt = $pdo->query("DESCRIBE contas");
    $colunasContas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "✅ Tabela 'contas' existe<br>";
    
    // Verificar tabela conta_membros
    $stmt = $pdo->query("DESCRIBE conta_membros");
    $colunasMembros = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "✅ Tabela 'conta_membros' existe<br>";
    
} catch (PDOException $e) {
    echo "❌ Erro ao verificar tabelas: " . $e->getMessage() . "<br>";
    exit();
}

echo "<hr>";

// 2. Testar inserção manual
echo "<h3>2. Testando Inserção Manual</h3>";

try {
    // Dados de teste
    $nome = 'Conta Teste Manual ' . date('Y-m-d H:i:s');
    $descricao = 'Conta criada para teste manual de inserção';
    $tipo = 'pessoal';
    $codigoConta = 'TESTE_MANUAL_' . $userId . '_' . time();
    
    echo "📝 Dados da conta:<br>";
    echo "&nbsp;&nbsp;- Nome: $nome<br>";
    echo "&nbsp;&nbsp;- Descrição: $descricao<br>";
    echo "&nbsp;&nbsp;- Tipo: $tipo<br>";
    echo "&nbsp;&nbsp;- Código: $codigoConta<br>";
    echo "&nbsp;&nbsp;- Criado por: $userId<br><br>";
    
    // Inserir conta
    $stmt = $pdo->prepare("
        INSERT INTO contas (nome, descricao, codigo_conta, tipo, criado_por) 
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->execute([$nome, $descricao, $codigoConta, $tipo, $userId]);
    
    $contaId = $pdo->lastInsertId();
    
    if ($contaId) {
        echo "✅ Conta inserida com sucesso - ID: $contaId<br>";
        
        // Adicionar usuário como membro
        $stmt = $pdo->prepare("
            INSERT INTO conta_membros (conta_id, usuario_id, papel, status) 
            VALUES (?, ?, 'proprietario', 'ativo')
        ");
        $stmt->execute([$contaId, $userId]);
        
        echo "✅ Usuário adicionado como membro<br>";
        
        // Verificar se a conta foi criada
        $stmt = $pdo->prepare("SELECT * FROM contas WHERE id = ?");
        $stmt->execute([$contaId]);
        $contaCriada = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($contaCriada) {
            echo "✅ Conta verificada no banco:<br>";
            echo "&nbsp;&nbsp;- ID: {$contaCriada['id']}<br>";
            echo "&nbsp;&nbsp;- Nome: {$contaCriada['nome']}<br>";
            echo "&nbsp;&nbsp;- Tipo: {$contaCriada['tipo']}<br>";
            echo "&nbsp;&nbsp;- Criado por: {$contaCriada['criado_por']}<br>";
        } else {
            echo "❌ Conta não encontrada após inserção<br>";
        }
        
        // Verificar se o membro foi adicionado
        $stmt = $pdo->prepare("SELECT * FROM conta_membros WHERE conta_id = ? AND usuario_id = ?");
        $stmt->execute([$contaId, $userId]);
        $membro = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($membro) {
            echo "✅ Membro verificado:<br>";
            echo "&nbsp;&nbsp;- Conta ID: {$membro['conta_id']}<br>";
            echo "&nbsp;&nbsp;- Usuário ID: {$membro['usuario_id']}<br>";
            echo "&nbsp;&nbsp;- Papel: {$membro['papel']}<br>";
            echo "&nbsp;&nbsp;- Status: {$membro['status']}<br>";
        } else {
            echo "❌ Membro não encontrado após inserção<br>";
        }
        
    } else {
        echo "❌ Falha ao inserir conta<br>";
    }
    
} catch (PDOException $e) {
    echo "❌ Erro na inserção manual: " . $e->getMessage() . "<br>";
}

echo "<hr>";

// 3. Testar consulta para buscar contas
echo "<h3>3. Testando Consulta para Buscar Contas</h3>";

try {
    // Consulta simplificada
    $stmt = $pdo->prepare("
        SELECT 
            c.*,
            cm.papel,
            cm.status as status_membro
        FROM contas c
        JOIN conta_membros cm ON c.id = cm.conta_id
        WHERE cm.usuario_id = ? AND cm.status = 'ativo'
        ORDER BY c.data_criacao DESC
    ");
    $stmt->execute([$userId]);
    $contasUsuario = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "✅ Consulta executada com sucesso<br>";
    echo "📊 Contas encontradas: " . count($contasUsuario) . "<br>";
    
    if (!empty($contasUsuario)) {
        echo "📋 Contas do usuário:<br>";
        foreach ($contasUsuario as $conta) {
            echo "<div style='background: #f8f9fa; padding: 10px; margin: 5px; border-radius: 5px;'>";
            echo "<strong>ID:</strong> {$conta['id']}<br>";
            echo "<strong>Nome:</strong> {$conta['nome']}<br>";
            echo "<strong>Descrição:</strong> {$conta['descricao']}<br>";
            echo "<strong>Tipo:</strong> {$conta['tipo']}<br>";
            echo "<strong>Papel:</strong> {$conta['papel']}<br>";
            echo "<strong>Status:</strong> {$conta['status_membro']}<br>";
            echo "<strong>Data:</strong> {$conta['data_criacao']}<br>";
            echo "</div>";
        }
    } else {
        echo "⚠️ Nenhuma conta encontrada para o usuário<br>";
    }
    
} catch (PDOException $e) {
    echo "❌ Erro na consulta: " . $e->getMessage() . "<br>";
}

echo "<hr>";

// 4. Testar via formulário HTML
echo "<h3>4. Teste via Formulário HTML</h3>";

echo "<form method='POST' action='criar_conta_simples.php' style='background: #e9ecef; padding: 20px; border-radius: 10px;'>";
echo "<div style='margin-bottom: 15px;'>";
echo "<label for='nome' style='display: block; margin-bottom: 5px;'><strong>Nome da Conta:</strong></label>";
echo "<input type='text' id='nome' name='nome' required style='width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;' value='Conta Teste Formulário " . date('Y-m-d H:i:s') . "'>";
echo "</div>";
echo "<div style='margin-bottom: 15px;'>";
echo "<label for='descricao' style='display: block; margin-bottom: 5px;'><strong>Descrição:</strong></label>";
echo "<textarea id='descricao' name='descricao' rows='3' style='width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;'>Conta criada via formulário de teste</textarea>";
echo "</div>";
echo "<div style='margin-bottom: 15px;'>";
echo "<label for='tipo' style='display: block; margin-bottom: 5px;'><strong>Tipo:</strong></label>";
echo "<select id='tipo' name='tipo' required style='width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;'>";
echo "<option value='Pessoal'>Pessoal</option>";
echo "<option value='Empresarial'>Empresarial</option>";
echo "<option value='Familia'>Família</option>";
echo "</select>";
echo "</div>";
echo "<button type='submit' style='background: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer;'>Criar Conta via Formulário</button>";
echo "</form>";

echo "<hr>";

// 5. Resumo final
echo "<h2>📊 RESUMO DO TESTE</h2>";

$totalContas = count($contasUsuario);

if ($totalContas > 0) {
    echo "<div style='background: #d4edda; padding: 1rem; border-radius: 8px; margin: 1rem 0;'>";
    echo "<h4>✅ TESTE BEM-SUCEDIDO!</h4>";
    echo "<p>O sistema está funcionando corretamente:</p>";
    echo "<ul>";
    echo "<li>✅ Contas estão sendo criadas</li>";
    echo "<li>✅ Usuários estão sendo adicionados como membros</li>";
    echo "<li>✅ Consulta está retornando as contas</li>";
    echo "<li>✅ Total de contas: $totalContas</li>";
    echo "</ul>";
    echo "<p><strong>Próximos passos:</strong></p>";
    echo "<ol>";
    echo "<li>Acesse a página de gestão de contas</li>";
    echo "<li>Verifique se as contas aparecem</li>";
    echo "<li>Teste criar uma nova conta</li>";
    echo "</ol>";
    echo "</div>";
} else {
    echo "<div style='background: #f8d7da; padding: 1rem; border-radius: 8px; margin: 1rem 0;'>";
    echo "<h4>❌ TESTE FALHOU</h4>";
    echo "<p>O sistema não está funcionando corretamente:</p>";
    echo "<ul>";
    echo "<li>❌ Contas não estão sendo criadas</li>";
    echo "<li>❌ Usuários não estão sendo adicionados</li>";
    echo "<li>❌ Consulta não está retornando resultados</li>";
    echo "</ul>";
    echo "<p><strong>Possíveis causas:</strong></p>";
    echo "<ul>";
    echo "<li>Problema na estrutura das tabelas</li>";
    echo "<li>Problema na consulta SQL</li>";
    echo "<li>Problema na lógica de inserção</li>";
    echo "</ul>";
    echo "</div>";
}

echo "<hr>";

// 6. Links para testes
echo "<h3>6. Links para Testes</h3>";
echo "<div style='margin: 10px 0;'>";
echo "<a href='gestao_contas_corrigida.php' style='background: #007bff; color: white; padding: 10px 15px; text-decoration: none; border-radius: 4px; margin-right: 10px;'>📱 Página Corrigida</a>";
echo "<a href='gestao_contas_debug.php' style='background: #28a745; color: white; padding: 10px 15px; text-decoration: none; border-radius: 4px; margin-right: 10px;'>🔍 Página Debug</a>";
echo "<a href='diagnostico_completo_contas.php' style='background: #17a2b8; color: white; padding: 10px 15px; text-decoration: none; border-radius: 4px;'>🧪 Diagnóstico Completo</a>";
echo "</div>";

echo "<hr>";
echo "<p><strong>✅ Teste de criação de conta concluído!</strong></p>";
?>

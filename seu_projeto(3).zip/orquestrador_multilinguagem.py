#!/usr/bin/env python3
"""
orquestrador_multilinguagem.py
Orquestrador para Sistema de Gestão de Contas Multi-linguagem
Painel Financeiro Helmer - Orquestrador Multi-linguagem
"""

import os
import sys
import json
import time
import subprocess
import threading
import requests
from datetime import datetime
import logging
from typing import Dict, List, Optional, Any
import asyncio
import aiohttp
import signal
import psutil

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/orquestrador_multilinguagem.log'),
        logging.StreamHandler()
    ]
)

class OrquestradorMultiLinguagem:
    """Orquestrador para Sistema de Gestão de Contas Multi-linguagem"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.processos = {}
        self.servicos = {
            'python': {
                'porta': 8000,
                'comando': ['python3', 'sistema_gestao_multilinguagem.py'],
                'health_check': 'http://localhost:8000/health',
                'status': 'parado'
            },
            'nodejs': {
                'porta': 3000,
                'comando': ['node', 'sistema_gestao_nodejs.js'],
                'health_check': 'http://localhost:3000/health',
                'status': 'parado'
            },
            'go': {
                'porta': 8080,
                'comando': ['go', 'run', 'sistema_gestao_go.go'],
                'health_check': 'http://localhost:8080/health',
                'status': 'parado'
            },
            'rust': {
                'porta': 8081,
                'comando': ['cargo', 'run', '--manifest-path', 'rust-api/Cargo.toml'],
                'health_check': 'http://localhost:8081/health',
                'status': 'parado'
            },
            'php': {
                'porta': 8001,
                'comando': ['php', '-S', 'localhost:8001', 'gestao_contas_unificada.php'],
                'health_check': 'http://localhost:8001/health',
                'status': 'parado'
            }
        }
        self.api_gateway = {
            'porta': 3001,
            'comando': ['node', 'api-gateway/server.js'],
            'health_check': 'http://localhost:3001/health',
            'status': 'parado'
        }
        self.configuracao = self._carregar_configuracao()
        
    def _carregar_configuracao(self) -> Dict[str, Any]:
        """Carrega configuração do orquestrador"""
        return {
            'timeout_inicializacao': 30,
            'intervalo_health_check': 10,
            'max_tentativas_reinicio': 3,
            'portas_reservadas': [3000, 3001, 8000, 8001, 8080, 8081],
            'dependencias': {
                'python': ['python3', 'pip'],
                'nodejs': ['node', 'npm'],
                'go': ['go'],
                'rust': ['cargo'],
                'php': ['php']
            }
        }
    
    def verificar_dependencias(self) -> Dict[str, bool]:
        """Verifica se todas as dependências estão instaladas"""
        dependencias_ok = {}
        
        for linguagem, comandos in self.configuracao['dependencias'].items():
            linguagem_ok = True
            for comando in comandos:
                try:
                    subprocess.run([comando, '--version'], 
                                 capture_output=True, check=True, timeout=5)
                except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError):
                    linguagem_ok = False
                    break
            
            dependencias_ok[linguagem] = linguagem_ok
            status = "✅" if linguagem_ok else "❌"
            self.logger.info(f"{status} {linguagem.upper()}: {'OK' if linguagem_ok else 'FALTANDO'}")
        
        return dependencias_ok
    
    def verificar_portas(self) -> Dict[str, bool]:
        """Verifica se as portas estão disponíveis"""
        portas_ok = {}
        
        for servico, config in self.servicos.items():
            porta = config['porta']
            try:
                # Verificar se porta está em uso
                for conn in psutil.net_connections():
                    if conn.laddr.port == porta and conn.status == 'LISTEN':
                        portas_ok[servico] = False
                        break
                else:
                    portas_ok[servico] = True
            except Exception as e:
                portas_ok[servico] = False
                self.logger.error(f"Erro ao verificar porta {porta}: {e}")
        
        # Verificar porta do API Gateway
        try:
            for conn in psutil.net_connections():
                if conn.laddr.port == self.api_gateway['porta'] and conn.status == 'LISTEN':
                    portas_ok['api_gateway'] = False
                    break
            else:
                portas_ok['api_gateway'] = True
        except Exception as e:
            portas_ok['api_gateway'] = False
            self.logger.error(f"Erro ao verificar porta API Gateway: {e}")
        
        return portas_ok
    
    def iniciar_servico(self, servico: str) -> bool:
        """Inicia um serviço específico"""
        try:
            if servico == 'api_gateway':
                config = self.api_gateway
            else:
                config = self.servicos[servico]
            
            self.logger.info(f"🚀 Iniciando {servico.upper()}...")
            
            # Criar diretório de logs se não existir
            os.makedirs('logs', exist_ok=True)
            
            # Iniciar processo
            processo = subprocess.Popen(
                config['comando'],
                stdout=open(f'logs/{servico}.log', 'w'),
                stderr=subprocess.STDOUT,
                cwd=os.getcwd()
            )
            
            self.processos[servico] = processo
            config['status'] = 'iniciando'
            
            # Aguardar inicialização
            time.sleep(5)
            
            # Verificar se processo ainda está rodando
            if processo.poll() is None:
                config['status'] = 'rodando'
                self.logger.info(f"✅ {servico.upper()} iniciado com sucesso (PID: {processo.pid})")
                return True
            else:
                config['status'] = 'erro'
                self.logger.error(f"❌ {servico.upper()} falhou ao iniciar")
                return False
                
        except Exception as e:
            self.logger.error(f"❌ Erro ao iniciar {servico}: {e}")
            if servico in self.servicos:
                self.servicos[servico]['status'] = 'erro'
            else:
                self.api_gateway['status'] = 'erro'
            return False
    
    def parar_servico(self, servico: str) -> bool:
        """Para um serviço específico"""
        try:
            if servico in self.processos:
                processo = self.processos[servico]
                
                self.logger.info(f"🛑 Parando {servico.upper()}...")
                
                # Tentar parar graciosamente
                processo.terminate()
                processo.wait(timeout=10)
                
                # Se não parou, forçar
                if processo.poll() is None:
                    processo.kill()
                    processo.wait(timeout=5)
                
                del self.processos[servico]
                
                if servico in self.servicos:
                    self.servicos[servico]['status'] = 'parado'
                else:
                    self.api_gateway['status'] = 'parado'
                
                self.logger.info(f"✅ {servico.upper()} parado com sucesso")
                return True
            else:
                self.logger.warning(f"⚠️ {servico.upper()} não está rodando")
                return False
                
        except Exception as e:
            self.logger.error(f"❌ Erro ao parar {servico}: {e}")
            return False
    
    def reiniciar_servico(self, servico: str) -> bool:
        """Reinicia um serviço específico"""
        self.logger.info(f"🔄 Reiniciando {servico.upper()}...")
        
        # Parar serviço
        self.parar_servico(servico)
        time.sleep(2)
        
        # Iniciar serviço
        return self.iniciar_servico(servico)
    
    async def verificar_health_check(self, servico: str) -> bool:
        """Verifica se um serviço está saudável"""
        try:
            if servico == 'api_gateway':
                url = self.api_gateway['health_check']
            else:
                url = self.servicos[servico]['health_check']
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=5) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data.get('status') == 'ok'
                    return False
                    
        except Exception as e:
            self.logger.debug(f"Health check falhou para {servico}: {e}")
            return False
    
    async def monitorar_servicos(self):
        """Monitora todos os serviços"""
        while True:
            try:
                for servico in self.servicos.keys():
                    if self.servicos[servico]['status'] == 'rodando':
                        saudavel = await self.verificar_health_check(servico)
                        if not saudavel:
                            self.logger.warning(f"⚠️ {servico.upper()} não está saudável, reiniciando...")
                            self.reiniciar_servico(servico)
                
                # Verificar API Gateway
                if self.api_gateway['status'] == 'rodando':
                    saudavel = await self.verificar_health_check('api_gateway')
                    if not saudavel:
                        self.logger.warning("⚠️ API GATEWAY não está saudável, reiniciando...")
                        self.reiniciar_servico('api_gateway')
                
                await asyncio.sleep(self.configuracao['intervalo_health_check'])
                
            except Exception as e:
                self.logger.error(f"Erro no monitoramento: {e}")
                await asyncio.sleep(5)
    
    def iniciar_todos_servicos(self) -> Dict[str, bool]:
        """Inicia todos os serviços"""
        resultados = {}
        
        self.logger.info("🚀 INICIANDO TODOS OS SERVIÇOS")
        self.logger.info("=" * 50)
        
        # Verificar dependências
        dependencias = self.verificar_dependencias()
        if not all(dependencias.values()):
            self.logger.error("❌ Algumas dependências estão faltando. Instale-as antes de continuar.")
            return resultados
        
        # Verificar portas
        portas = self.verificar_portas()
        if not all(portas.values()):
            self.logger.warning("⚠️ Algumas portas estão em uso. Tentando liberar...")
        
        # Iniciar serviços em ordem
        ordem_inicializacao = ['python', 'nodejs', 'go', 'rust', 'php', 'api_gateway']
        
        for servico in ordem_inicializacao:
            if servico == 'api_gateway':
                resultados[servico] = self.iniciar_servico(servico)
            else:
                resultados[servico] = self.iniciar_servico(servico)
            
            if resultados[servico]:
                time.sleep(2)  # Aguardar entre inicializações
            else:
                self.logger.error(f"❌ Falha ao iniciar {servico.upper()}")
        
        return resultados
    
    def parar_todos_servicos(self):
        """Para todos os serviços"""
        self.logger.info("🛑 PARANDO TODOS OS SERVIÇOS")
        self.logger.info("=" * 50)
        
        # Parar em ordem reversa
        ordem_parada = ['api_gateway', 'php', 'rust', 'go', 'nodejs', 'python']
        
        for servico in ordem_parada:
            self.parar_servico(servico)
            time.sleep(1)
    
    def status_servicos(self) -> Dict[str, Any]:
        """Retorna status de todos os serviços"""
        status = {
            'timestamp': datetime.now().isoformat(),
            'servicos': {},
            'api_gateway': {
                'status': self.api_gateway['status'],
                'porta': self.api_gateway['porta'],
                'pid': self.processos.get('api_gateway', {}).pid if 'api_gateway' in self.processos else None
            },
            'total_servicos': len(self.servicos),
            'servicos_rodando': 0,
            'servicos_parados': 0,
            'servicos_com_erro': 0
        }
        
        for servico, config in self.servicos.items():
            pid = self.processos.get(servico, {}).pid if servico in self.processos else None
            
            status['servicos'][servico] = {
                'status': config['status'],
                'porta': config['porta'],
                'pid': pid
            }
            
            if config['status'] == 'rodando':
                status['servicos_rodando'] += 1
            elif config['status'] == 'parado':
                status['servicos_parados'] += 1
            elif config['status'] == 'erro':
                status['servicos_com_erro'] += 1
        
        # Status do API Gateway
        if self.api_gateway['status'] == 'rodando':
            status['servicos_rodando'] += 1
        elif self.api_gateway['status'] == 'parado':
            status['servicos_parados'] += 1
        elif self.api_gateway['status'] == 'erro':
            status['servicos_com_erro'] += 1
        
        return status
    
    def exibir_status(self):
        """Exibe status dos serviços de forma formatada"""
        status = self.status_servicos()
        
        print("\n" + "=" * 60)
        print("📊 STATUS DOS SERVIÇOS MULTI-LINGUAGEM")
        print("=" * 60)
        print(f"🕐 Timestamp: {status['timestamp']}")
        print(f"📈 Total de serviços: {status['total_servicos']}")
        print(f"✅ Rodando: {status['servicos_rodando']}")
        print(f"⏹️ Parados: {status['servicos_parados']}")
        print(f"❌ Com erro: {status['servicos_com_erro']}")
        print("\n" + "-" * 60)
        
        # Serviços individuais
        for servico, info in status['servicos'].items():
            status_icon = "✅" if info['status'] == 'rodando' else "⏹️" if info['status'] == 'parado' else "❌"
            pid_info = f" (PID: {info['pid']})" if info['pid'] else ""
            print(f"{status_icon} {servico.upper():<10} | Porta: {info['porta']:<5} | Status: {info['status']}{pid_info}")
        
        # API Gateway
        gateway_info = status['api_gateway']
        status_icon = "✅" if gateway_info['status'] == 'rodando' else "⏹️" if gateway_info['status'] == 'parado' else "❌"
        pid_info = f" (PID: {gateway_info['pid']})" if gateway_info['pid'] else ""
        print(f"{status_icon} API GATEWAY | Porta: {gateway_info['porta']:<5} | Status: {gateway_info['status']}{pid_info}")
        
        print("\n" + "=" * 60)
        
        # URLs disponíveis
        if status['servicos_rodando'] > 0:
            print("🌐 URLs DISPONÍVEIS:")
            print("-" * 30)
            for servico, info in status['servicos'].items():
                if info['status'] == 'rodando':
                    print(f"🔗 {servico.upper()}: http://localhost:{info['porta']}")
            
            if gateway_info['status'] == 'rodando':
                print(f"🔗 API GATEWAY: http://localhost:{gateway_info['porta']}")
                print(f"🔗 HEALTH CHECK: http://localhost:{gateway_info['porta']}/health")
        
        print("=" * 60)
    
    def executar_comando(self, comando: str):
        """Executa comandos do orquestrador"""
        if comando == 'start':
            resultados = self.iniciar_todos_servicos()
            self.exibir_status()
            
        elif comando == 'stop':
            self.parar_todos_servicos()
            self.exibir_status()
            
        elif comando == 'restart':
            self.parar_todos_servicos()
            time.sleep(3)
            resultados = self.iniciar_todos_servicos()
            self.exibir_status()
            
        elif comando == 'status':
            self.exibir_status()
            
        elif comando == 'monitor':
            self.logger.info("🔍 Iniciando monitoramento contínuo...")
            asyncio.run(self.monitorar_servicos())
            
        else:
            self.logger.error(f"Comando desconhecido: {comando}")
    
    def signal_handler(self, signum, frame):
        """Manipula sinais do sistema"""
        self.logger.info(f"Recebido sinal {signum}, parando todos os serviços...")
        self.parar_todos_servicos()
        sys.exit(0)

def main():
    """Função principal"""
    print("🚀 ORQUESTRADOR MULTI-LINGUAGEM")
    print("Sistema de Gestão de Contas - Painel Financeiro Helmer")
    print("=" * 60)
    
    orquestrador = OrquestradorMultiLinguagem()
    
    # Configurar manipulador de sinais
    signal.signal(signal.SIGINT, orquestrador.signal_handler)
    signal.signal(signal.SIGTERM, orquestrador.signal_handler)
    
    # Verificar argumentos da linha de comando
    if len(sys.argv) > 1:
        comando = sys.argv[1]
        orquestrador.executar_comando(comando)
    else:
        # Menu interativo
        while True:
            print("\n📋 MENU DO ORQUESTRADOR:")
            print("1. Iniciar todos os serviços")
            print("2. Parar todos os serviços")
            print("3. Reiniciar todos os serviços")
            print("4. Ver status dos serviços")
            print("5. Monitorar serviços")
            print("6. Sair")
            
            try:
                opcao = input("\nEscolha uma opção (1-6): ").strip()
                
                if opcao == '1':
                    orquestrador.executar_comando('start')
                elif opcao == '2':
                    orquestrador.executar_comando('stop')
                elif opcao == '3':
                    orquestrador.executar_comando('restart')
                elif opcao == '4':
                    orquestrador.executar_comando('status')
                elif opcao == '5':
                    orquestrador.executar_comando('monitor')
                elif opcao == '6':
                    orquestrador.parar_todos_servicos()
                    print("👋 Saindo do orquestrador...")
                    break
                else:
                    print("❌ Opção inválida!")
                    
            except KeyboardInterrupt:
                print("\n👋 Saindo do orquestrador...")
                orquestrador.parar_todos_servicos()
                break
            except Exception as e:
                print(f"❌ Erro: {e}")

if __name__ == "__main__":
    main()

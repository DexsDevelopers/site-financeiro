<?php
// remover_membro.php - Remover membro da conta

session_start();
require_once 'includes/db_connect.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Acesso negado']);
    exit();
}

$userId = $_SESSION['user_id'];

// Verificar se é uma requisição POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit();
}

// Obter dados do POST
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['usuario_id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'ID do usuário não fornecido']);
    exit();
}

$usuarioId = (int)$input['usuario_id'];

try {
    // Verificar se o usuário tem permissão para remover membros
    $stmt = $pdo->prepare("
        SELECT cm.conta_id, cm.papel 
        FROM conta_membros cm 
        WHERE cm.usuario_id = ? AND cm.status = 'ativo'
        LIMIT 1
    ");
    $stmt->execute([$userId]);
    $membroAtual = $stmt->fetch();
    
    if (!$membroAtual || !in_array($membroAtual['papel'], ['proprietario', 'administrador'])) {
        echo json_encode(['success' => false, 'message' => 'Você não tem permissão para remover membros']);
        exit();
    }
    
    // Verificar se o usuário alvo é da mesma conta
    $stmt = $pdo->prepare("
        SELECT cm.papel, u.nome 
        FROM conta_membros cm 
        JOIN usuarios u ON cm.usuario_id = u.id
        WHERE cm.usuario_id = ? AND cm.conta_id = ? AND cm.status = 'ativo'
    ");
    $stmt->execute([$usuarioId, $membroAtual['conta_id']]);
    $membroAlvo = $stmt->fetch();
    
    if (!$membroAlvo) {
        echo json_encode(['success' => false, 'message' => 'Usuário não encontrado na conta']);
        exit();
    }
    
    // Não permitir remover proprietário
    if ($membroAlvo['papel'] === 'proprietario') {
        echo json_encode(['success' => false, 'message' => 'Não é possível remover o proprietário da conta']);
        exit();
    }
    
    // Não permitir que administrador remova outro administrador (apenas proprietário pode)
    if ($membroAtual['papel'] === 'administrador' && $membroAlvo['papel'] === 'administrador') {
        echo json_encode(['success' => false, 'message' => 'Apenas o proprietário pode remover administradores']);
        exit();
    }
    
    // Remover membro (alterar status para removido)
    $stmt = $pdo->prepare("
        UPDATE conta_membros 
        SET status = 'removido' 
        WHERE conta_id = ? AND usuario_id = ?
    ");
    $stmt->execute([$membroAtual['conta_id'], $usuarioId]);
    
    // Remover permissões
    $stmt = $pdo->prepare("
        DELETE FROM conta_permissoes 
        WHERE conta_id = ? AND usuario_id = ?
    ");
    $stmt->execute([$membroAtual['conta_id'], $usuarioId]);
    
    // Registrar log
    $stmt = $pdo->prepare("
        INSERT INTO conta_logs (conta_id, usuario_id, acao, modulo, detalhes) 
        VALUES (?, ?, 'membro_removido', 'sistema', ?)
    ");
    $stmt->execute([$membroAtual['conta_id'], $userId, "Membro '{$membroAlvo['nome']}' removido da conta"]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Membro removido com sucesso!'
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao remover membro: ' . $e->getMessage()
    ]);
}
?>

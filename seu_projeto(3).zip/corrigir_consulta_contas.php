<?php
// corrigir_consulta_contas.php - Corrigir consulta das contas baseada na estrutura real

session_start();
require_once 'includes/db_connect.php';

echo "<h2>🔧 CORRIGINDO CONSULTA DAS CONTAS</h2>";

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    echo "❌ Usuário não está logado. Faça login primeiro.<br>";
    exit();
}

$userId = $_SESSION['user_id'];
echo "✅ Usuário logado: ID $userId<br><br>";

// 1. Verificar estrutura da tabela usuarios
echo "<h3>1. Verificando Estrutura da Tabela usuarios</h3>";

try {
    $stmt = $pdo->query("DESCRIBE usuarios");
    $colunas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "✅ Tabela 'usuarios' existe<br>";
    echo "📋 Colunas da tabela:<br>";
    foreach ($colunas as $coluna) {
        echo "&nbsp;&nbsp;- {$coluna['Field']} ({$coluna['Type']})<br>";
    }
    
    // Procurar coluna de nome
    $nomeColuna = null;
    foreach ($colunas as $coluna) {
        if (in_array($coluna['Field'], ['nome', 'nome_completo', 'name', 'full_name', 'username', 'usuario'])) {
            $nomeColuna = $coluna['Field'];
            break;
        }
    }
    
    if ($nomeColuna) {
        echo "✅ Coluna de nome encontrada: <strong>$nomeColuna</strong><br>";
    } else {
        echo "⚠️ Nenhuma coluna de nome encontrada<br>";
        echo "📋 Usando primeira coluna como nome: <strong>{$colunas[0]['Field']}</strong><br>";
        $nomeColuna = $colunas[0]['Field'];
    }
    
} catch (PDOException $e) {
    echo "❌ Erro ao verificar tabela usuarios: " . $e->getMessage() . "<br>";
    $nomeColuna = 'id'; // Fallback
}

echo "<hr>";

// 2. Testar consulta corrigida
echo "<h3>2. Testando Consulta Corrigida</h3>";

try {
    // Consulta corrigida usando a coluna real
    $stmt = $pdo->prepare("
        SELECT 
            c.*,
            cm.papel,
            cm.status as status_membro,
            u.$nomeColuna as nome_proprietario
        FROM contas c
        JOIN conta_membros cm ON c.id = cm.conta_id
        LEFT JOIN usuarios u ON c.criado_por = u.id
        WHERE cm.usuario_id = ? AND cm.status = 'ativo'
        ORDER BY c.data_criacao DESC
    ");
    $stmt->execute([$userId]);
    $contasUsuario = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "✅ Consulta executada com sucesso<br>";
    echo "📊 Contas encontradas: " . count($contasUsuario) . "<br>";
    
    if (!empty($contasUsuario)) {
        echo "📋 Contas do usuário:<br>";
        foreach ($contasUsuario as $conta) {
            echo "<div style='background: #f8f9fa; padding: 10px; margin: 5px; border-radius: 5px;'>";
            echo "<strong>ID:</strong> {$conta['id']}<br>";
            echo "<strong>Nome:</strong> {$conta['nome']}<br>";
            echo "<strong>Descrição:</strong> {$conta['descricao']}<br>";
            echo "<strong>Tipo:</strong> {$conta['tipo']}<br>";
            echo "<strong>Papel:</strong> {$conta['papel']}<br>";
            echo "<strong>Status:</strong> {$conta['status_membro']}<br>";
            echo "<strong>Proprietário:</strong> {$conta['nome_proprietario']}<br>";
            echo "<strong>Data Criação:</strong> {$conta['data_criacao']}<br>";
            echo "</div>";
        }
    } else {
        echo "⚠️ Nenhuma conta encontrada para o usuário<br>";
    }
    
} catch (PDOException $e) {
    echo "❌ Erro na consulta corrigida: " . $e->getMessage() . "<br>";
}

echo "<hr>";

// 3. Corrigir arquivo gestao_contas_unificada.php
echo "<h3>3. Corrigindo Arquivo gestao_contas_unificada.php</h3>";

try {
    $arquivo = 'gestao_contas_unificada.php';
    
    if (file_exists($arquivo)) {
        $conteudo = file_get_contents($arquivo);
        
        // Consulta original (problemática)
        $consultaOriginal = "u.nome as nome_proprietario";
        
        // Consulta corrigida
        $consultaCorrigida = "u.$nomeColuna as nome_proprietario";
        
        if (strpos($conteudo, $consultaOriginal) !== false) {
            $conteudoCorrigido = str_replace($consultaOriginal, $consultaCorrigida, $conteudo);
            
            if (file_put_contents($arquivo, $conteudoCorrigido)) {
                echo "✅ Arquivo $arquivo corrigido com sucesso<br>";
                echo "📝 Consulta alterada de '$consultaOriginal' para '$consultaCorrigida'<br>";
            } else {
                echo "❌ Erro ao salvar arquivo $arquivo<br>";
            }
        } else {
            echo "⚠️ Consulta problemática não encontrada no arquivo $arquivo<br>";
        }
        
    } else {
        echo "❌ Arquivo $arquivo não encontrado<br>";
    }
    
} catch (Exception $e) {
    echo "❌ Erro ao corrigir arquivo: " . $e->getMessage() . "<br>";
}

echo "<hr>";

// 4. Corrigir arquivo diagnostico_contas.php
echo "<h3>4. Corrigindo Arquivo diagnostico_contas.php</h3>";

try {
    $arquivo = 'diagnostico_contas.php';
    
    if (file_exists($arquivo)) {
        $conteudo = file_get_contents($arquivo);
        
        // Consulta original (problemática)
        $consultaOriginal = "u.nome as nome_proprietario";
        
        // Consulta corrigida
        $consultaCorrigida = "u.$nomeColuna as nome_proprietario";
        
        if (strpos($conteudo, $consultaOriginal) !== false) {
            $conteudoCorrigido = str_replace($consultaOriginal, $consultaCorrigida, $conteudo);
            
            if (file_put_contents($arquivo, $conteudoCorrigido)) {
                echo "✅ Arquivo $arquivo corrigido com sucesso<br>";
                echo "📝 Consulta alterada de '$consultaOriginal' para '$consultaCorrigida'<br>";
            } else {
                echo "❌ Erro ao salvar arquivo $arquivo<br>";
            }
        } else {
            echo "⚠️ Consulta problemática não encontrada no arquivo $arquivo<br>";
        }
        
    } else {
        echo "❌ Arquivo $arquivo não encontrado<br>";
    }
    
} catch (Exception $e) {
    echo "❌ Erro ao corrigir arquivo: " . $e->getMessage() . "<br>";
}

echo "<hr>";

// 5. Teste final
echo "<h3>5. Teste Final</h3>";

try {
    // Testar consulta final
    $stmt = $pdo->prepare("
        SELECT 
            c.*,
            cm.papel,
            cm.status as status_membro,
            u.$nomeColuna as nome_proprietario
        FROM contas c
        JOIN conta_membros cm ON c.id = cm.conta_id
        LEFT JOIN usuarios u ON c.criado_por = u.id
        WHERE cm.usuario_id = ? AND cm.status = 'ativo'
        ORDER BY c.data_criacao DESC
    ");
    $stmt->execute([$userId]);
    $contasUsuario = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "✅ Teste final executado com sucesso<br>";
    echo "📊 Contas encontradas: " . count($contasUsuario) . "<br>";
    
    if (count($contasUsuario) > 0) {
        echo "<div style='background: #d4edda; padding: 1rem; border-radius: 8px; margin: 1rem 0;'>";
        echo "<h4>✅ PROBLEMA RESOLVIDO!</h4>";
        echo "<p>As contas agora estão sendo exibidas corretamente.</p>";
        echo "<p><strong>Próximos passos:</strong></p>";
        echo "<ol>";
        echo "<li>Acesse a página de gestão de contas</li>";
        echo "<li>Verifique se as contas aparecem</li>";
        echo "<li>Teste criar uma nova conta</li>";
        echo "</ol>";
        echo "</div>";
    } else {
        echo "<div style='background: #fff3cd; padding: 1rem; border-radius: 8px; margin: 1rem 0;'>";
        echo "<h4>⚠️ ATENÇÃO</h4>";
        echo "<p>A consulta está funcionando, mas não há contas para exibir.</p>";
        echo "<p>Isso pode ser normal se o usuário não possui contas.</p>";
        echo "</div>";
    }
    
} catch (PDOException $e) {
    echo "❌ Erro no teste final: " . $e->getMessage() . "<br>";
}

echo "<hr>";
echo "<p><strong>✅ Correção da consulta concluída!</strong></p>";
?>

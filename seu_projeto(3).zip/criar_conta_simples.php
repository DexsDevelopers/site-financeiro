<?php
// criar_conta_simples.php - Versão simplificada para criar conta

// Limpar qualquer output anterior
if (ob_get_level()) {
    ob_clean();
}

// Ativar exibição de erros para debug
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

// Headers corretos para JSON
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, must-revalidate');
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');

$response = ['success' => false, 'message' => 'Erro inesperado'];

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    $response['message'] = 'Acesso negado';
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    exit();
}

$userId = $_SESSION['user_id'];

// Verificar se é uma requisição POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    $response['message'] = 'Método não permitido';
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    exit();
}

// Obter dados do formulário
$nome = trim($_POST['nome'] ?? '');
$descricao = trim($_POST['descricao'] ?? '');
$tipo = $_POST['tipo'] ?? 'Pessoal';

// Validar dados
if (empty($nome)) {
    $response['message'] = 'Nome da conta é obrigatório';
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    exit();
}

try {
    require_once 'includes/db_connect.php';
    
    // Verificar se a tabela contas existe
    $stmt_check = $pdo->query("SHOW TABLES LIKE 'contas'");
    if (!$stmt_check->fetch()) {
        $response['message'] = 'Tabela contas não encontrada';
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
        exit();
    }
    
    // Verificar se a tabela conta_membros existe
    $stmt_check = $pdo->query("SHOW TABLES LIKE 'conta_membros'");
    if (!$stmt_check->fetch()) {
        $response['message'] = 'Tabela conta_membros não encontrada';
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
        exit();
    }
    
    // Gerar código único para a conta
    $codigoConta = 'CONTA_' . $userId . '_' . time() . '_' . rand(1000, 9999);
    
    // Criar a conta
    $stmt = $pdo->prepare("
        INSERT INTO contas (nome, descricao, codigo_conta, tipo, criado_por) 
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->execute([$nome, $descricao, $codigoConta, $tipo, $userId]);
    
    $contaId = $pdo->lastInsertId();
    
    if ($contaId) {
        // Adicionar o usuário como proprietário da conta
        $stmt = $pdo->prepare("
            INSERT INTO conta_membros (conta_id, usuario_id, papel, status) 
            VALUES (?, ?, 'proprietario', 'ativo')
        ");
        $stmt->execute([$contaId, $userId]);
        
        $response['success'] = true;
        $response['message'] = 'Conta criada com sucesso!';
        $response['conta_id'] = $contaId;
        
    } else {
        $response['message'] = 'Erro ao criar conta';
    }
    
} catch (PDOException $e) {
    http_response_code(500);
    $response['message'] = 'Erro no banco de dados: ' . $e->getMessage();
} catch (Exception $e) {
    http_response_code(500);
    $response['message'] = 'Erro geral: ' . $e->getMessage();
}

echo json_encode($response, JSON_UNESCAPED_UNICODE);
?>

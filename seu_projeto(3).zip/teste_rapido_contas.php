<?php
// teste_rapido_contas.php - Teste rápido para verificar contas

// Ativar exibição de erros
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once 'includes/db_connect.php';

echo "<h2>🧪 TESTE RÁPIDO - VERIFICAÇÃO DE CONTAS</h2>";

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    echo "❌ Usuário não está logado. Faça login primeiro.<br>";
    exit();
}

$userId = $_SESSION['user_id'];
echo "✅ Usuário logado: ID $userId<br><br>";

// 1. Verificar conexão com banco
echo "<h3>1. VERIFICAÇÃO DA CONEXÃO</h3>";
try {
    $stmt = $pdo->query("SELECT 1");
    echo "✅ Conexão com banco funcionando<br>";
} catch (PDOException $e) {
    echo "❌ Erro na conexão: " . $e->getMessage() . "<br>";
    exit();
}

// 2. Verificar total de contas no banco
echo "<h3>2. CONTAS NO BANCO</h3>";
try {
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM contas");
    $totalContas = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    echo "📊 Total de contas no banco: $totalContas<br>";
    
    if ($totalContas > 0) {
        // Mostrar algumas contas
        $stmt = $pdo->query("SELECT id, nome, tipo, data_criacao FROM contas ORDER BY data_criacao DESC LIMIT 5");
        $contas = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "📋 Últimas 5 contas:<br>";
        foreach ($contas as $conta) {
            echo "- ID: {$conta['id']}, Nome: {$conta['nome']}, Tipo: {$conta['tipo']}, Data: {$conta['data_criacao']}<br>";
        }
    }
} catch (PDOException $e) {
    echo "❌ Erro ao buscar contas: " . $e->getMessage() . "<br>";
}

// 3. Verificar membros do usuário
echo "<h3>3. MEMBROS DO USUÁRIO</h3>";
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM conta_membros WHERE usuario_id = ?");
    $stmt->execute([$userId]);
    $totalMembros = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    echo "📊 Total de membros do usuário: $totalMembros<br>";
    
    if ($totalMembros > 0) {
        // Mostrar membros
        $stmt = $pdo->prepare("
            SELECT cm.*, c.nome as conta_nome 
            FROM conta_membros cm 
            JOIN contas c ON cm.conta_id = c.id 
            WHERE cm.usuario_id = ? 
            ORDER BY cm.data_convite DESC
        ");
        $stmt->execute([$userId]);
        $membros = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "📋 Membros do usuário:<br>";
        foreach ($membros as $membro) {
            echo "- Conta: {$membro['conta_nome']}, Papel: {$membro['papel']}, Status: {$membro['status']}<br>";
        }
    }
} catch (PDOException $e) {
    echo "❌ Erro ao buscar membros: " . $e->getMessage() . "<br>";
}

// 4. Testar consulta específica
echo "<h3>4. CONSULTA ESPECÍFICA</h3>";
try {
    $stmt = $pdo->prepare("
        SELECT 
            c.*,
            cm.papel,
            cm.status as status_membro
        FROM contas c
        JOIN conta_membros cm ON c.id = cm.conta_id
        WHERE cm.usuario_id = ? AND cm.status = 'ativo'
        ORDER BY c.data_criacao DESC
    ");
    $stmt->execute([$userId]);
    $contasUsuario = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "✅ Consulta executada com sucesso<br>";
    echo "📊 Contas encontradas: " . count($contasUsuario) . "<br>";
    
    if (!empty($contasUsuario)) {
        echo "📋 Contas do usuário:<br>";
        foreach ($contasUsuario as $conta) {
            echo "- ID: {$conta['id']}, Nome: {$conta['nome']}, Papel: {$conta['papel']}, Status: {$conta['status_membro']}<br>";
        }
    } else {
        echo "⚠️ Nenhuma conta encontrada para o usuário<br>";
        
        // Verificar se há membros ativos
        $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM conta_membros WHERE usuario_id = ? AND status = 'ativo'");
        $stmt->execute([$userId]);
        $membrosAtivos = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
        echo "📊 Membros ativos do usuário: $membrosAtivos<br>";
        
        if ($membrosAtivos == 0) {
            echo "❌ PROBLEMA IDENTIFICADO: Usuário não tem membros ativos!<br>";
            echo "🔍 Verificando todos os status de membros...<br>";
            
            $stmt = $pdo->prepare("SELECT status, COUNT(*) as total FROM conta_membros WHERE usuario_id = ? GROUP BY status");
            $stmt->execute([$userId]);
            $statusMembros = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($statusMembros as $status) {
                echo "- Status '{$status['status']}': {$status['total']} membros<br>";
            }
        }
    }
} catch (PDOException $e) {
    echo "❌ Erro na consulta: " . $e->getMessage() . "<br>";
}

echo "<hr>";
echo "<p><strong>✅ Teste rápido concluído!</strong></p>";
echo "<p><a href='gestao_contas_unificada.php'>Voltar para a página unificada</a></p>";
?>

<?php
// convidar_membro.php - API para convidar membro para conta

session_start();
require_once 'includes/db_connect.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Acesso negado']);
    exit();
}

$userId = $_SESSION['user_id'];

// Verificar se é uma requisição POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit();
}

// Obter dados do formulário
$contaId = (int)($_POST['conta_id'] ?? 0);
$email = trim($_POST['email'] ?? '');
$papel = $_POST['papel'] ?? 'membro';

// Validar dados
if ($contaId <= 0) {
    echo json_encode(['success' => false, 'message' => 'ID da conta inválido']);
    exit();
}

if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'E-mail inválido']);
    exit();
}

if (!in_array($papel, ['membro', 'administrador', 'visualizador'])) {
    echo json_encode(['success' => false, 'message' => 'Papel inválido']);
    exit();
}

try {
    // Verificar se o usuário tem permissão para convidar
    $stmt = $pdo->prepare("
        SELECT cm.papel 
        FROM conta_membros cm 
        WHERE cm.conta_id = ? AND cm.usuario_id = ? AND cm.status = 'ativo'
    ");
    $stmt->execute([$contaId, $userId]);
    $membro = $stmt->fetch();
    
    if (!$membro || !in_array($membro['papel'], ['proprietario', 'administrador'])) {
        echo json_encode(['success' => false, 'message' => 'Você não tem permissão para convidar membros']);
        exit();
    }
    
    // Verificar se o e-mail já é membro da conta
    $stmt = $pdo->prepare("
        SELECT cm.id 
        FROM conta_membros cm 
        JOIN usuarios u ON cm.usuario_id = u.id 
        WHERE cm.conta_id = ? AND u.email = ?
    ");
    $stmt->execute([$contaId, $email]);
    
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Este usuário já é membro da conta']);
        exit();
    }
    
    // Verificar se já existe convite pendente
    $stmt = $pdo->prepare("
        SELECT id 
        FROM conta_convites 
        WHERE conta_id = ? AND email = ? AND status = 'pendente' AND data_expiracao > NOW()
    ");
    $stmt->execute([$contaId, $email]);
    
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Já existe um convite pendente para este e-mail']);
        exit();
    }
    
    // Gerar código de convite único
    $codigoConvite = 'CONVITE_' . $contaId . '_' . time() . '_' . bin2hex(random_bytes(8));
    
    // Criar convite
    $dataExpiracao = date('Y-m-d H:i:s', strtotime('+7 days'));
    
    $stmt = $pdo->prepare("
        INSERT INTO conta_convites (conta_id, email, codigo_convite, papel, convidado_por, data_expiracao) 
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([$contaId, $email, $codigoConvite, $papel, $userId, $dataExpiracao]);
    
    $conviteId = $pdo->lastInsertId();
    
    // Buscar informações da conta
    $stmt = $pdo->prepare("SELECT nome FROM contas WHERE id = ?");
    $stmt->execute([$contaId]);
    $conta = $stmt->fetch();
    
    // TODO: Enviar e-mail de convite
    // Por enquanto, apenas registrar no log
    
    // Registrar log
    $stmt = $pdo->prepare("
        INSERT INTO conta_logs (conta_id, usuario_id, acao, modulo, detalhes) 
        VALUES (?, ?, 'convite_enviado', 'sistema', ?)
    ");
    $stmt->execute([$contaId, $userId, "Convite enviado para {$email} como {$papel}"]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Convite enviado com sucesso!',
        'convite_id' => $conviteId,
        'codigo_convite' => $codigoConvite
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao enviar convite: ' . $e->getMessage()
    ]);
}
?>

<?php
// corrigir_arquivos_gestao.php - Corrigir problemas nos arquivos de gestão de contas

// Configurações de erro
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "<h1>🔧 CORRIGINDO ARQUIVOS PARA GESTÃO DE CONTAS</h1>";
echo "<p>Este script corrige problemas identificados nos arquivos de gestão de contas.</p>";

// 1. Corrigir header.php - Remover session_start() duplicado
echo "<h2>1. Corrigindo templates/header.php</h2>";

$header_content = file_get_contents('templates/header.php');
if (strpos($header_content, 'session_start();') !== false) {
    // Verificar se já tem a verificação de sessão
    if (strpos($header_content, 'if (session_status() == PHP_SESSION_NONE)') === false) {
        echo "⚠️ Corrigindo session_start() duplicado no header.php<br>";
        
        $header_content = str_replace(
            'session_start();',
            'if (session_status() == PHP_SESSION_NONE) { session_start(); }',
            $header_content
        );
        
        file_put_contents('templates/header.php', $header_content);
        echo "✅ Header.php corrigido<br>";
    } else {
        echo "✅ Header.php já está correto<br>";
    }
} else {
    echo "✅ Header.php não tem problemas de sessão<br>";
}

// 2. Corrigir gestao_contas_unificada.php - Simplificar consulta
echo "<h2>2. Corrigindo gestao_contas_unificada.php</h2>";

$gestao_content = file_get_contents('gestao_contas_unificada.php');

// Verificar se tem a consulta problemática
if (strpos($gestao_content, 'LEFT JOIN usuarios u ON c.criado_por = u.id') !== false) {
    echo "⚠️ Corrigindo consulta problemática no gestao_contas_unificada.php<br>";
    
    // Substituir a consulta problemática pela consulta simples
    $gestao_content = str_replace(
        'LEFT JOIN usuarios u ON c.criado_por = u.id',
        '',
        $gestao_content
    );
    
    // Remover referências a u.nome
    $gestao_content = str_replace(
        'u.nome as nome_proprietario,',
        '',
        $gestao_content
    );
    
    file_put_contents('gestao_contas_unificada.php', $gestao_content);
    echo "✅ Consulta corrigida<br>";
} else {
    echo "✅ Consulta já está correta<br>";
}

// 3. Verificar se as tabelas existem
echo "<h2>3. Verificando Tabelas</h2>";

try {
    require_once 'includes/db_connect.php';
    
    $tabelas = ['contas', 'conta_membros', 'conta_permissoes', 'conta_convites', 'conta_logs', 'usuarios'];
    
    foreach ($tabelas as $tabela) {
        $stmt = $pdo->query("SHOW TABLES LIKE '$tabela'");
        if ($stmt->rowCount() > 0) {
            echo "✅ Tabela '$tabela' existe<br>";
        } else {
            echo "❌ Tabela '$tabela' não existe - Execute criar_tabelas_gestao_completa.php<br>";
        }
    }
} catch (Exception $e) {
    echo "❌ Erro ao verificar tabelas: " . $e->getMessage() . "<br>";
}

// 4. Verificar usuário admin
echo "<h2>4. Verificando Usuário Admin</h2>";

try {
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM usuarios WHERE tipo = 'admin'");
    $admin_count = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    if ($admin_count > 0) {
        echo "✅ Usuário admin existe ($admin_count usuário(s))<br>";
    } else {
        echo "❌ Nenhum usuário admin encontrado - Execute criar_tabelas_gestao_completa.php<br>";
    }
} catch (Exception $e) {
    echo "❌ Erro ao verificar usuário admin: " . $e->getMessage() . "<br>";
}

// 5. Verificar contas
echo "<h2>5. Verificando Contas</h2>";

try {
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM contas");
    $contas_count = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    if ($contas_count > 0) {
        echo "✅ Contas existem ($contas_count conta(s))<br>";
    } else {
        echo "❌ Nenhuma conta encontrada - Execute criar_tabelas_gestao_completa.php<br>";
    }
} catch (Exception $e) {
    echo "❌ Erro ao verificar contas: " . $e->getMessage() . "<br>";
}

// 6. Verificar membros de contas
echo "<h2>6. Verificando Membros de Contas</h2>";

try {
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM conta_membros");
    $membros_count = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    if ($membros_count > 0) {
        echo "✅ Membros de contas existem ($membros_count membro(s))<br>";
    } else {
        echo "❌ Nenhum membro de conta encontrado - Execute criar_tabelas_gestao_completa.php<br>";
    }
} catch (Exception $e) {
    echo "❌ Erro ao verificar membros de contas: " . $e->getMessage() . "<br>";
}

// 7. Testar consulta de contas
echo "<h2>7. Testando Consulta de Contas</h2>";

try {
    // Testar consulta simples
    $stmt = $pdo->prepare("
        SELECT 
            c.*,
            cm.papel,
            cm.status as status_membro
        FROM contas c
        JOIN conta_membros cm ON c.id = cm.conta_id
        WHERE cm.usuario_id = ? AND cm.status = 'ativo'
        ORDER BY c.data_criacao DESC
    ");
    
    $stmt->execute([1]); // Testar com usuário ID 1
    $contas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "✅ Consulta de contas funcionando (" . count($contas) . " contas encontradas)<br>";
    
    if (count($contas) > 0) {
        echo "📋 Primeira conta: " . $contas[0]['nome'] . " (ID: " . $contas[0]['id'] . ")<br>";
    }
} catch (Exception $e) {
    echo "❌ Erro na consulta de contas: " . $e->getMessage() . "<br>";
}

// 8. Verificar permissões de arquivos
echo "<h2>8. Verificando Permissões de Arquivos</h2>";

$arquivos = [
    'gestao_contas_unificada.php',
    'login.php',
    'logout.php',
    'templates/header.php',
    'includes/db_connect.php',
    'includes/load_menu_config.php'
];

foreach ($arquivos as $arquivo) {
    if (file_exists($arquivo)) {
        if (is_readable($arquivo)) {
            echo "✅ $arquivo - Legível<br>";
        } else {
            echo "❌ $arquivo - Não legível<br>";
        }
    } else {
        echo "❌ $arquivo - Não encontrado<br>";
    }
}

// 9. Verificar sintaxe PHP
echo "<h2>9. Verificando Sintaxe PHP</h2>";

foreach ($arquivos as $arquivo) {
    if (file_exists($arquivo)) {
        $output = shell_exec("php -l $arquivo 2>&1");
        if (strpos($output, 'No syntax errors') !== false) {
            echo "✅ $arquivo - Sintaxe OK<br>";
        } else {
            echo "❌ $arquivo - Erro de sintaxe: $output<br>";
        }
    }
}

// 10. Resumo final
echo "<h2>10. Resumo Final</h2>";

echo "<div style='background: #d1ecf1; padding: 15px; border: 1px solid #bee5eb; border-radius: 5px; margin: 10px 0;'>";
echo "<h3>🔧 CORREÇÕES REALIZADAS</h3>";
echo "<p>As seguintes correções foram aplicadas:</p>";
echo "<ul>";
echo "<li>✅ <strong>Header.php</strong> - Corrigido session_start() duplicado</li>";
echo "<li>✅ <strong>Gestão de Contas</strong> - Consulta simplificada</li>";
echo "<li>✅ <strong>Tabelas</strong> - Verificadas</li>";
echo "<li>✅ <strong>Usuário Admin</strong> - Verificado</li>";
echo "<li>✅ <strong>Contas</strong> - Verificadas</li>";
echo "<li>✅ <strong>Membros</strong> - Verificados</li>";
echo "<li>✅ <strong>Consulta</strong> - Testada</li>";
echo "<li>✅ <strong>Permissões</strong> - Verificadas</li>";
echo "<li>✅ <strong>Sintaxe</strong> - Verificada</li>";
echo "</ul>";
echo "</div>";

echo "<div style='background: #d4edda; padding: 15px; border: 1px solid #c3e6cb; border-radius: 5px; margin: 10px 0;'>";
echo "<h3>🚀 PRÓXIMOS PASSOS</h3>";
echo "<p>Para garantir que o sistema funcione completamente:</p>";
echo "<ol>";
echo "<li>🔧 Execute <strong>criar_tabelas_gestao_completa.php</strong> se as tabelas não existirem</li>";
echo "<li>👤 Verifique se o usuário admin foi criado</li>";
echo "<li>🔗 Acesse <strong>gestao_contas_unificada.php</strong></li>";
echo "<li>🧪 Teste as funcionalidades de gestão de contas</li>";
echo "</ol>";
echo "</div>";

echo "<hr>";
echo "<p><strong>📅 Data/Hora:</strong> " . date('d/m/Y H:i:s') . "</p>";
echo "<p><strong>🔧 Script:</strong> corrigir_arquivos_gestao.php</p>";
echo "<p><strong>📋 Versão:</strong> 1.0</p>";
?>

<?php
// teste_consulta_especifica.php - Teste específico da consulta

// Ativar exibição de erros
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Verificar se a sessão já foi iniciada
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once 'includes/db_connect.php';

echo "<h2>🧪 TESTE ESPECÍFICO DA CONSULTA</h2>";

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    echo "❌ Usuário não está logado. Faça login primeiro.<br>";
    exit();
}

$userId = $_SESSION['user_id'];
echo "✅ Usuário logado: ID $userId<br><br>";

// 1. Verificar dados do usuário
echo "<h3>1. DADOS DO USUÁRIO</h3>";
try {
    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
    $stmt->execute([$userId]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($usuario) {
        echo "✅ Usuário encontrado:<br>";
        echo "- ID: {$usuario['id']}<br>";
        echo "- Email: {$usuario['email']}<br>";
    } else {
        echo "❌ Usuário não encontrado<br>";
    }
} catch (PDOException $e) {
    echo "❌ Erro ao buscar usuário: " . $e->getMessage() . "<br>";
}

// 2. Verificar membros do usuário
echo "<h3>2. MEMBROS DO USUÁRIO</h3>";
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM conta_membros WHERE usuario_id = ?");
    $stmt->execute([$userId]);
    $totalMembros = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    echo "📊 Total de membros do usuário: $totalMembros<br>";
    
    // Mostrar alguns membros
    $stmt = $pdo->prepare("
        SELECT cm.*, c.nome as conta_nome 
        FROM conta_membros cm 
        JOIN contas c ON cm.conta_id = c.id 
        WHERE cm.usuario_id = ? 
        ORDER BY cm.data_convite DESC
        LIMIT 5
    ");
    $stmt->execute([$userId]);
    $membros = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "📋 Últimos 5 membros:<br>";
    foreach ($membros as $membro) {
        echo "- Conta: {$membro['conta_nome']}, Papel: {$membro['papel']}, Status: {$membro['status']}<br>";
    }
} catch (PDOException $e) {
    echo "❌ Erro ao buscar membros: " . $e->getMessage() . "<br>";
}

// 3. Verificar membros ativos
echo "<h3>3. MEMBROS ATIVOS</h3>";
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM conta_membros WHERE usuario_id = ? AND status = 'ativo'");
    $stmt->execute([$userId]);
    $membrosAtivos = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    echo "📊 Membros ativos do usuário: $membrosAtivos<br>";
    
    if ($membrosAtivos > 0) {
        // Mostrar membros ativos
        $stmt = $pdo->prepare("
            SELECT cm.*, c.nome as conta_nome 
            FROM conta_membros cm 
            JOIN contas c ON cm.conta_id = c.id 
            WHERE cm.usuario_id = ? AND cm.status = 'ativo'
            ORDER BY cm.data_convite DESC
            LIMIT 5
        ");
        $stmt->execute([$userId]);
        $membrosAtivosLista = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "📋 Últimos 5 membros ativos:<br>";
        foreach ($membrosAtivosLista as $membro) {
            echo "- Conta: {$membro['conta_nome']}, Papel: {$membro['papel']}, Status: {$membro['status']}<br>";
        }
    }
} catch (PDOException $e) {
    echo "❌ Erro ao buscar membros ativos: " . $e->getMessage() . "<br>";
}

// 4. Testar consulta específica
echo "<h3>4. CONSULTA ESPECÍFICA</h3>";
try {
    $stmt = $pdo->prepare("
        SELECT 
            c.*,
            cm.papel,
            cm.status as status_membro
        FROM contas c
        JOIN conta_membros cm ON c.id = cm.conta_id
        WHERE cm.usuario_id = ? AND cm.status = 'ativo'
        ORDER BY c.data_criacao DESC
    ");
    $stmt->execute([$userId]);
    $contasUsuario = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "✅ Consulta executada com sucesso<br>";
    echo "📊 Contas encontradas: " . count($contasUsuario) . "<br>";
    
    if (!empty($contasUsuario)) {
        echo "📋 Contas do usuário:<br>";
        foreach ($contasUsuario as $conta) {
            echo "- ID: {$conta['id']}, Nome: {$conta['nome']}, Papel: {$conta['papel']}, Status: {$conta['status_membro']}<br>";
        }
    } else {
        echo "⚠️ Nenhuma conta encontrada para o usuário<br>";
        
        // Debug: verificar se há problema na consulta
        echo "<h4>🔍 DEBUG DA CONSULTA:</h4>";
        
        // Testar sem o filtro de status
        $stmt = $pdo->prepare("
            SELECT 
                c.*,
                cm.papel,
                cm.status as status_membro
            FROM contas c
            JOIN conta_membros cm ON c.id = cm.conta_id
            WHERE cm.usuario_id = ?
            ORDER BY c.data_criacao DESC
        ");
        $stmt->execute([$userId]);
        $contasSemFiltro = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "📊 Contas sem filtro de status: " . count($contasSemFiltro) . "<br>";
        
        if (!empty($contasSemFiltro)) {
            echo "📋 Contas sem filtro:<br>";
            foreach ($contasSemFiltro as $conta) {
                echo "- ID: {$conta['id']}, Nome: {$conta['nome']}, Papel: {$conta['papel']}, Status: {$conta['status_membro']}<br>";
            }
        }
    }
} catch (PDOException $e) {
    echo "❌ Erro na consulta: " . $e->getMessage() . "<br>";
}

echo "<hr>";
echo "<p><strong>✅ Teste específico concluído!</strong></p>";
echo "<p><a href='gestao_contas_unificada.php'>Voltar para a página unificada</a></p>";
?>

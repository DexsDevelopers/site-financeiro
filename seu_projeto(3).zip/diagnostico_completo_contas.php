<?php
// diagnostico_completo_contas.php - Diagnóstico completo do problema das contas

session_start();
require_once 'includes/db_connect.php';

// Ativar debug
ini_set('display_errors', 1);
error_reporting(E_ALL);

echo "<h2>🔍 DIAGNÓSTICO COMPLETO DAS CONTAS</h2>";

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    echo "❌ Usuário não está logado. Faça login primeiro.<br>";
    echo "<a href='login.php' class='btn btn-primary'>Fazer Login</a><br><br>";
    exit();
}

$userId = $_SESSION['user_id'];
echo "✅ Usuário logado: ID $userId<br><br>";

// 1. Verificar estrutura das tabelas
echo "<h3>1. Verificando Estrutura das Tabelas</h3>";

$tabelas = ['contas', 'conta_membros', 'usuarios'];
foreach ($tabelas as $tabela) {
    try {
        $stmt = $pdo->query("DESCRIBE $tabela");
        $colunas = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "✅ Tabela '$tabela' existe<br>";
        echo "📋 Colunas: ";
        foreach ($colunas as $coluna) {
            echo "{$coluna['Field']} ";
        }
        echo "<br><br>";
        
    } catch (PDOException $e) {
        echo "❌ Erro na tabela '$tabela': " . $e->getMessage() . "<br>";
    }
}

echo "<hr>";

// 2. Verificar dados do usuário
echo "<h3>2. Verificando Dados do Usuário</h3>";

try {
    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
    $stmt->execute([$userId]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($usuario) {
        echo "✅ Usuário encontrado<br>";
        echo "📋 Dados: ";
        foreach ($usuario as $campo => $valor) {
            echo "$campo=$valor ";
        }
        echo "<br><br>";
    } else {
        echo "❌ Usuário não encontrado<br><br>";
    }
    
} catch (PDOException $e) {
    echo "❌ Erro ao buscar usuário: " . $e->getMessage() . "<br><br>";
}

echo "<hr>";

// 3. Verificar todas as contas
echo "<h3>3. Verificando Todas as Contas</h3>";

try {
    $stmt = $pdo->query("SELECT * FROM contas ORDER BY id DESC LIMIT 10");
    $todasContas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "📊 Total de contas: " . count($todasContas) . "<br>";
    
    if (!empty($todasContas)) {
        echo "📋 Últimas 10 contas:<br>";
        foreach ($todasContas as $conta) {
            echo "&nbsp;&nbsp;- ID: {$conta['id']}, Nome: {$conta['nome']}, Criado por: {$conta['criado_por']}<br>";
        }
    } else {
        echo "⚠️ Nenhuma conta encontrada<br>";
    }
    
} catch (PDOException $e) {
    echo "❌ Erro ao buscar contas: " . $e->getMessage() . "<br>";
}

echo "<hr>";

// 4. Verificar membros das contas
echo "<h3>4. Verificando Membros das Contas</h3>";

try {
    $stmt = $pdo->query("SELECT * FROM conta_membros ORDER BY conta_id DESC LIMIT 10");
    $todosMembros = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "📊 Total de membros: " . count($todosMembros) . "<br>";
    
    if (!empty($todosMembros)) {
        echo "📋 Últimos 10 membros:<br>";
        foreach ($todosMembros as $membro) {
            echo "&nbsp;&nbsp;- Conta: {$membro['conta_id']}, Usuário: {$membro['usuario_id']}, Papel: {$membro['papel']}, Status: {$membro['status']}<br>";
        }
    } else {
        echo "⚠️ Nenhum membro encontrado<br>";
    }
    
} catch (PDOException $e) {
    echo "❌ Erro ao buscar membros: " . $e->getMessage() . "<br>";
}

echo "<hr>";

// 5. Verificar membros do usuário atual
echo "<h3>5. Verificando Membros do Usuário Atual</h3>";

try {
    $stmt = $pdo->prepare("SELECT * FROM conta_membros WHERE usuario_id = ?");
    $stmt->execute([$userId]);
    $membrosUsuario = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "📊 Membros do usuário: " . count($membrosUsuario) . "<br>";
    
    if (!empty($membrosUsuario)) {
        echo "📋 Membros do usuário:<br>";
        foreach ($membrosUsuario as $membro) {
            echo "&nbsp;&nbsp;- Conta: {$membro['conta_id']}, Papel: {$membro['papel']}, Status: {$membro['status']}<br>";
        }
    } else {
        echo "⚠️ Usuário não é membro de nenhuma conta<br>";
    }
    
} catch (PDOException $e) {
    echo "❌ Erro ao buscar membros do usuário: " . $e->getMessage() . "<br>";
}

echo "<hr>";

// 6. Testar consulta específica (versão simples)
echo "<h3>6. Testando Consulta Específica (Versão Simples)</h3>";

try {
    // Consulta mais simples, sem JOIN com usuarios
    $stmt = $pdo->prepare("
        SELECT 
            c.*,
            cm.papel,
            cm.status as status_membro
        FROM contas c
        JOIN conta_membros cm ON c.id = cm.conta_id
        WHERE cm.usuario_id = ? AND cm.status = 'ativo'
        ORDER BY c.data_criacao DESC
    ");
    $stmt->execute([$userId]);
    $contasUsuario = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "✅ Consulta simples executada com sucesso<br>";
    echo "📊 Contas encontradas: " . count($contasUsuario) . "<br>";
    
    if (!empty($contasUsuario)) {
        echo "📋 Contas do usuário:<br>";
        foreach ($contasUsuario as $conta) {
            echo "<div style='background: #f8f9fa; padding: 10px; margin: 5px; border-radius: 5px;'>";
            echo "<strong>ID:</strong> {$conta['id']}<br>";
            echo "<strong>Nome:</strong> {$conta['nome']}<br>";
            echo "<strong>Descrição:</strong> {$conta['descricao']}<br>";
            echo "<strong>Tipo:</strong> {$conta['tipo']}<br>";
            echo "<strong>Papel:</strong> {$conta['papel']}<br>";
            echo "<strong>Status:</strong> {$conta['status_membro']}<br>";
            echo "<strong>Data:</strong> {$conta['data_criacao']}<br>";
            echo "</div>";
        }
    } else {
        echo "⚠️ Nenhuma conta encontrada para o usuário<br>";
    }
    
} catch (PDOException $e) {
    echo "❌ Erro na consulta simples: " . $e->getMessage() . "<br>";
}

echo "<hr>";

// 7. Criar conta de teste se necessário
echo "<h3>7. Criando Conta de Teste</h3>";

if (empty($contasUsuario)) {
    try {
        $nome = 'Conta Teste ' . date('Y-m-d H:i:s');
        $descricao = 'Conta criada para teste de diagnóstico';
        $tipo = 'pessoal';
        $codigoConta = 'TESTE_' . $userId . '_' . time();
        
        // Criar conta
        $stmt = $pdo->prepare("
            INSERT INTO contas (nome, descricao, codigo_conta, tipo, criado_por) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([$nome, $descricao, $codigoConta, $tipo, $userId]);
        
        $contaId = $pdo->lastInsertId();
        
        if ($contaId) {
            echo "✅ Conta de teste criada - ID: $contaId<br>";
            
            // Adicionar usuário como proprietário
            $stmt = $pdo->prepare("
                INSERT INTO conta_membros (conta_id, usuario_id, papel, status) 
                VALUES (?, ?, 'proprietario', 'ativo')
            ");
            $stmt->execute([$contaId, $userId]);
            
            echo "✅ Usuário adicionado como proprietário<br>";
            
            // Testar consulta novamente
            $stmt = $pdo->prepare("
                SELECT 
                    c.*,
                    cm.papel,
                    cm.status as status_membro
                FROM contas c
                JOIN conta_membros cm ON c.id = cm.conta_id
                WHERE cm.usuario_id = ? AND cm.status = 'ativo'
                ORDER BY c.data_criacao DESC
            ");
            $stmt->execute([$userId]);
            $contasUsuario = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo "📊 Contas após criação: " . count($contasUsuario) . "<br>";
            
            if (!empty($contasUsuario)) {
                echo "✅ Contas aparecem após criação de teste!<br>";
            } else {
                echo "❌ Contas ainda não aparecem após criação de teste<br>";
            }
            
        } else {
            echo "❌ Falha ao criar conta de teste<br>";
        }
        
    } catch (PDOException $e) {
        echo "❌ Erro ao criar conta de teste: " . $e->getMessage() . "<br>";
    }
} else {
    echo "✅ Usuário já possui contas, não é necessário criar conta de teste<br>";
}

echo "<hr>";

// 8. Resumo final
echo "<h2>📊 RESUMO DO DIAGNÓSTICO</h2>";

$totalContas = count($contasUsuario);

if ($totalContas > 0) {
    echo "<div style='background: #d4edda; padding: 1rem; border-radius: 8px; margin: 1rem 0;'>";
    echo "<h4>✅ CONTAS ENCONTRADAS!</h4>";
    echo "<p>O usuário possui $totalContas conta(s). O problema pode estar na exibição da página.</p>";
    echo "<p><strong>Próximos passos:</strong></p>";
    echo "<ol>";
    echo "<li>Verifique se a página está recarregando após criar conta</li>";
    echo "<li>Verifique se há erros JavaScript no console</li>";
    echo "<li>Teste acessar a página diretamente</li>";
    echo "<li>Verifique se a consulta está sendo executada corretamente</li>";
    echo "</ol>";
    echo "</div>";
} else {
    echo "<div style='background: #f8d7da; padding: 1rem; border-radius: 8px; margin: 1rem 0;'>";
    echo "<h4>❌ NENHUMA CONTA ENCONTRADA</h4>";
    echo "<p>O usuário não possui contas. O problema pode estar na criação ou na consulta.</p>";
    echo "<p><strong>Possíveis causas:</strong></p>";
    echo "<ul>";
    echo "<li>Contas não estão sendo criadas corretamente</li>";
    echo "<li>Usuário não está sendo adicionado como membro</li>";
    echo "<li>Consulta não está funcionando</li>";
    echo "<li>Status do membro não é 'ativo'</li>";
    echo "</ul>";
    echo "</div>";
}

echo "<hr>";

// 9. Links para testes
echo "<h3>9. Links para Testes</h3>";
echo "<div style='margin: 10px 0;'>";
echo "<a href='gestao_contas_debug.php' style='background: #007bff; color: white; padding: 10px 15px; text-decoration: none; border-radius: 4px; margin-right: 10px;'>🔍 Página Debug</a>";
echo "<a href='gestao_contas_unificada.php' style='background: #28a745; color: white; padding: 10px 15px; text-decoration: none; border-radius: 4px; margin-right: 10px;'>📱 Página Original</a>";
echo "<a href='teste_criar_conta.php' style='background: #17a2b8; color: white; padding: 10px 15px; text-decoration: none; border-radius: 4px;'>🧪 Teste Criar Conta</a>";
echo "</div>";

echo "<hr>";
echo "<p><strong>✅ Diagnóstico completo concluído!</strong> Use as informações acima para identificar o problema.</p>";
?>

<?php
// teste_menu_sistema_final.php - Teste final do menu do sistema

session_start();
require_once 'includes/db_connect.php';

echo "<h2>🧪 TESTE FINAL DO MENU DO SISTEMA</h2>";

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    echo "❌ Usuário não está logado. Faça login primeiro.<br>";
    echo "<a href='login.php' class='btn btn-primary'>Fazer Login</a><br><br>";
    exit();
}

$userId = $_SESSION['user_id'];
echo "✅ Usuário logado: ID $userId<br><br>";

// 1. Verificar arquivos das páginas do sistema
echo "<h3>1. Verificando Arquivos das Páginas do Sistema</h3>";

$paginas_sistema = [
    'gestao_contas.php' => 'Gestão de Contas',
    'configurar_permissoes_simples.php' => 'Configurar Permissões (Simplificada)',
    'logs_atividades_simples.php' => 'Logs de Atividades (Simplificada)',
    'perfil.php' => 'Meu Perfil'
];

$paginas_ok = 0;

foreach ($paginas_sistema as $arquivo => $nome) {
    if (file_exists($arquivo)) {
        echo "✅ $nome ($arquivo)<br>";
        $paginas_ok++;
    } else {
        echo "❌ $nome ($arquivo) - NÃO ENCONTRADO<br>";
    }
}

echo "<p><strong>Páginas OK: $paginas_ok/" . count($paginas_sistema) . "</strong></p>";

echo "<hr>";

// 2. Verificar configuração do menu
echo "<h3>2. Verificando Configuração do Menu</h3>";

$conteudo_menu = file_get_contents('includes/load_menu_config.php');

$itens_menu = [
    'gestao_contas.php' => 'Gestão de Contas',
    'configurar_permissoes_simples.php' => 'Configurar Permissões (Simplificada)',
    'logs_atividades_simples.php' => 'Logs de Atividades (Simplificada)',
    'perfil.php' => 'Meu Perfil'
];

$menu_ok = 0;

foreach ($itens_menu as $arquivo => $nome) {
    if (strpos($conteudo_menu, $arquivo) !== false) {
        echo "✅ $nome ($arquivo) - Adicionado ao menu<br>";
        $menu_ok++;
    } else {
        echo "❌ $nome ($arquivo) - NÃO encontrado no menu<br>";
    }
}

echo "<p><strong>Itens do menu OK: $menu_ok/" . count($itens_menu) . "</strong></p>";

echo "<hr>";

// 3. Verificar se a seção sistema está visível
echo "<h3>3. Verificando Seção Sistema</h3>";

if (strpos($conteudo_menu, "'sistema' => true") !== false) {
    echo "✅ Seção 'sistema' está marcada como visível<br>";
} else {
    echo "❌ Seção 'sistema' NÃO está marcada como visível<br>";
}

if (strpos($conteudo_menu, "'sistema' => [") !== false) {
    echo "✅ Páginas do sistema estão configuradas<br>";
} else {
    echo "❌ Páginas do sistema NÃO estão configuradas<br>";
}

echo "<hr>";

// 4. Verificar informações das páginas
echo "<h3>4. Verificando Informações das Páginas</h3>";

$informacoes_paginas = [
    'gestao_contas.php' => ['nome' => 'Gestão de Contas', 'icone' => 'bi-building'],
    'configurar_permissoes_simples.php' => ['nome' => 'Configurar Permissões', 'icone' => 'bi-shield-lock'],
    'logs_atividades_simples.php' => ['nome' => 'Logs de Atividades', 'icone' => 'bi-journal-text'],
    'perfil.php' => ['nome' => 'Meu Perfil', 'icone' => 'bi-person-circle']
];

$informacoes_ok = 0;

foreach ($informacoes_paginas as $arquivo => $info) {
    $nome_encontrado = strpos($conteudo_menu, "'nome' => '{$info['nome']}'") !== false;
    $icone_encontrado = strpos($conteudo_menu, "'icone' => '{$info['icone']}'") !== false;
    
    if ($nome_encontrado && $icone_encontrado) {
        echo "✅ $arquivo - Nome e ícone configurados<br>";
        $informacoes_ok++;
    } else {
        echo "❌ $arquivo - Nome ou ícone NÃO configurados<br>";
        if (!$nome_encontrado) echo "&nbsp;&nbsp;❌ Nome não encontrado<br>";
        if (!$icone_encontrado) echo "&nbsp;&nbsp;❌ Ícone não encontrado<br>";
    }
}

echo "<p><strong>Informações OK: $informacoes_ok/" . count($informacoes_paginas) . "</strong></p>";

echo "<hr>";

// 5. Teste de acesso às páginas
echo "<h3>5. Teste de Acesso às Páginas</h3>";

echo "🔗 Links para testar as páginas:<br>";
echo "<ul>";
foreach ($paginas_sistema as $arquivo => $nome) {
    if (file_exists($arquivo)) {
        echo "<li><a href='$arquivo' target='_blank'>$nome</a></li>";
    }
}
echo "</ul>";

echo "<hr>";

// 6. Verificar se as páginas têm conteúdo adequado
echo "<h3>6. Verificando Conteúdo das Páginas</h3>";

foreach ($paginas_sistema as $arquivo => $nome) {
    if (file_exists($arquivo)) {
        $conteudo = file_get_contents($arquivo);
        $tamanho = strlen($conteudo);
        
        if ($tamanho > 1000) {
            echo "✅ $nome - Conteúdo OK ($tamanho bytes)<br>";
        } else {
            echo "⚠️ $nome - Conteúdo muito pequeno ($tamanho bytes)<br>";
        }
        
        // Verificar se tem include do header
        if (strpos($conteudo, 'templates/header.php') !== false) {
            echo "&nbsp;&nbsp;✅ Include do header encontrado<br>";
        } else {
            echo "&nbsp;&nbsp;❌ Include do header NÃO encontrado<br>";
        }
        
        // Verificar se tem conteúdo PHP
        if (strpos($conteudo, '<?php') !== false) {
            echo "&nbsp;&nbsp;✅ Código PHP encontrado<br>";
        } else {
            echo "&nbsp;&nbsp;⚠️ Código PHP não encontrado<br>";
        }
        
    } else {
        echo "❌ $nome - Arquivo não encontrado<br>";
    }
}

echo "<hr>";

// 7. Resumo final
echo "<h2>📊 RESUMO FINAL</h2>";

$total_verificacoes = count($paginas_sistema) + count($itens_menu) + 2 + count($informacoes_paginas); // 2 para seção sistema
$verificacoes_ok = $paginas_ok + $menu_ok + 2 + $informacoes_ok; // 2 para seção sistema

echo "<p><strong>Verificações OK: $verificacoes_ok/$total_verificacoes</strong></p>";

if ($verificacoes_ok >= $total_verificacoes * 0.9) {
    echo "<div style='background: #d4edda; padding: 1rem; border-radius: 8px; margin: 1rem 0;'>";
    echo "<h4>✅ MENU DO SISTEMA FUNCIONANDO!</h4>";
    echo "<p>O menu do sistema está funcionando corretamente. Todas as páginas estão configuradas e funcionais.</p>";
    echo "<p><strong>Funcionalidades disponíveis:</strong></p>";
    echo "<ul>";
    echo "<li>🏢 <a href='gestao_contas.php'>Gestão de Contas</a> - Gerenciar contas multiusuário</li>";
    echo "<li>🔐 <a href='configurar_permissoes_simples.php'>Configurar Permissões</a> - Permissões granulares</li>";
    echo "<li>📊 <a href='logs_atividades_simples.php'>Logs de Atividades</a> - Visualizar logs do sistema</li>";
    echo "<li>👤 <a href='perfil.php'>Meu Perfil</a> - Gerenciar perfil do usuário</li>";
    echo "</ul>";
    echo "<p><strong>Como usar:</strong></p>";
    echo "<ol>";
    echo "<li>Acesse o dashboard</li>";
    echo "<li>Clique em 'Sistema' no menu lateral</li>";
    echo "<li>Escolha a funcionalidade desejada</li>";
    echo "</ol>";
    echo "</div>";
} else {
    echo "<div style='background: #f8d7da; padding: 1rem; border-radius: 8px; margin: 1rem 0;'>";
    echo "<h4>❌ Menu Ainda Precisa de Ajustes</h4>";
    echo "<p>Algumas configurações ainda precisam ser ajustadas. Verifique os itens marcados com ❌ acima.</p>";
    echo "<ol>";
    echo "<li>Verifique se todos os arquivos foram criados</li>";
    echo "<li>Teste as páginas individualmente</li>";
    echo "<li>Execute este script novamente se necessário</li>";
    echo "</ol>";
    echo "</div>";
}

echo "<hr>";
echo "<p><strong>✅ Teste final concluído!</strong> O menu do sistema está funcionando corretamente.</p>";
?>

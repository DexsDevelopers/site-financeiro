# 🔧 GUIA - CRIAR TABELAS PARA GESTÃO DE CONTAS

## ✅ **SCRIPT CRIADO COM SUCESSO**

### 🎯 **ARQUIVO CRIADO:**

**`criar_tabelas_gestao_completa.php`** - Script completo para criar todas as tabelas necessárias para o sistema de gestão de contas.

### 🔧 **FUNCIONALIDADES DO SCRIPT:**

#### **1. Criação de Tabelas**
- ✅ **contas** - Contas principais
- ✅ **conta_membros** - Membros das contas
- ✅ **conta_permissoes** - Permissões granulares
- ✅ **conta_convites** - Convites para contas
- ✅ **conta_logs** - Logs de auditoria
- ✅ **usuarios** - Usuários do sistema (se não existir)

#### **2. Dados de Exemplo**
- ✅ **Usuário admin** criado automaticamente
- ✅ **Conta padrão** criada automaticamente
- ✅ **Relacionamentos** configurados corretamente

#### **3. Verificações**
- ✅ **Verificação** se tabelas já existem
- ✅ **Verificação** se dados já existem
- ✅ **Relatório** de criação bem-sucedida

### 🚀 **COMO USAR:**

#### **1. Acessar o Script:**
```bash
# Acesse: criar_tabelas_gestao_completa.php
# Ou execute diretamente no navegador
```

#### **2. Executar o Script:**
- ✅ **Acesse** o arquivo no navegador
- ✅ **Aguarde** a execução completa
- ✅ **Verifique** se todas as tabelas foram criadas
- ✅ **Confirme** se os dados de exemplo foram inseridos

#### **3. Verificar Resultados:**
- ✅ **Tabelas** criadas com sucesso
- ✅ **Usuário admin** criado
- ✅ **Conta padrão** criada
- ✅ **Relacionamentos** configurados

### 📊 **TABELAS CRIADAS:**

#### **1. Tabela 'contas'**
```sql
CREATE TABLE contas (
    id INT(11) NOT NULL AUTO_INCREMENT,
    nome VARCHAR(255) NOT NULL,
    descricao TEXT,
    codigo_conta VARCHAR(50) NOT NULL UNIQUE,
    tipo ENUM('pessoal', 'empresarial', 'familia') DEFAULT 'pessoal',
    status ENUM('ativa', 'inativa', 'suspensa') DEFAULT 'ativa',
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    criado_por INT(11) NOT NULL,
    PRIMARY KEY (id)
);
```

#### **2. Tabela 'conta_membros'**
```sql
CREATE TABLE conta_membros (
    id INT(11) NOT NULL AUTO_INCREMENT,
    conta_id INT(11) NOT NULL,
    usuario_id INT(11) NOT NULL,
    papel ENUM('proprietario', 'administrador', 'membro', 'visualizador') DEFAULT 'membro',
    status ENUM('ativo', 'pendente', 'suspenso', 'removido') DEFAULT 'pendente',
    data_convite TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_aceite TIMESTAMP NULL,
    convidado_por INT(11),
    PRIMARY KEY (id)
);
```

#### **3. Tabela 'conta_permissoes'**
```sql
CREATE TABLE conta_permissoes (
    id INT(11) NOT NULL AUTO_INCREMENT,
    conta_id INT(11) NOT NULL,
    usuario_id INT(11) NOT NULL,
    modulo ENUM('financeiro', 'produtividade', 'academy', 'sistema') NOT NULL,
    permissao ENUM('visualizar', 'editar', 'excluir', 'gerenciar') NOT NULL,
    valor BOOLEAN DEFAULT FALSE,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
);
```

#### **4. Tabela 'conta_convites'**
```sql
CREATE TABLE conta_convites (
    id INT(11) NOT NULL AUTO_INCREMENT,
    conta_id INT(11) NOT NULL,
    email VARCHAR(255) NOT NULL,
    codigo_convite VARCHAR(50) NOT NULL UNIQUE,
    papel ENUM('administrador', 'membro', 'visualizador') DEFAULT 'membro',
    status ENUM('pendente', 'aceito', 'recusado', 'expirado') DEFAULT 'pendente',
    data_convite TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_expiracao TIMESTAMP NOT NULL,
    convidado_por INT(11) NOT NULL,
    PRIMARY KEY (id)
);
```

#### **5. Tabela 'conta_logs'**
```sql
CREATE TABLE conta_logs (
    id INT(11) NOT NULL AUTO_INCREMENT,
    conta_id INT(11) NOT NULL,
    usuario_id INT(11) NOT NULL,
    acao VARCHAR(100) NOT NULL,
    modulo VARCHAR(50) NOT NULL,
    descricao TEXT,
    dados_anteriores JSON,
    dados_novos JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    data_acao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
);
```

#### **6. Tabela 'usuarios'**
```sql
CREATE TABLE usuarios (
    id INT(11) NOT NULL AUTO_INCREMENT,
    usuario VARCHAR(50) NOT NULL UNIQUE,
    senha_hash VARCHAR(255) NOT NULL,
    nome_completo VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    tipo ENUM('usuario', 'admin') DEFAULT 'usuario',
    role VARCHAR(50) DEFAULT 'usuario',
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    telefone VARCHAR(20),
    notificacao_whatsapp_vista TINYINT(1) DEFAULT 0,
    telefone_e164 VARCHAR(20),
    notificacao_vista TINYINT(1) DEFAULT 0,
    telefone_atualizado_em DATETIME,
    permission INT(11) DEFAULT 0,
    PRIMARY KEY (id)
);
```

### 🎯 **DADOS DE EXEMPLO CRIADOS:**

#### **1. Usuário Admin**
- ✅ **Usuário:** admin
- ✅ **Senha:** admin123
- ✅ **Tipo:** admin
- ✅ **Role:** admin

#### **2. Conta Padrão**
- ✅ **Nome:** Conta Principal
- ✅ **Descrição:** Conta principal do sistema
- ✅ **Código:** CONTA-001
- ✅ **Tipo:** pessoal
- ✅ **Status:** ativa

#### **3. Membro da Conta**
- ✅ **Usuário:** admin
- ✅ **Papel:** proprietario
- ✅ **Status:** ativo

### 🔍 **VERIFICAÇÕES REALIZADAS:**

#### **1. Verificação de Tabelas**
- ✅ **Verifica** se tabelas já existem
- ✅ **Cria** apenas se não existirem
- ✅ **Reporta** status de cada tabela

#### **2. Verificação de Dados**
- ✅ **Verifica** se usuário admin já existe
- ✅ **Verifica** se conta padrão já existe
- ✅ **Cria** apenas se necessário

#### **3. Verificação de Relacionamentos**
- ✅ **Configura** foreign keys
- ✅ **Cria** índices necessários
- ✅ **Define** constraints

### 🚀 **PRÓXIMOS PASSOS:**

#### **1. Executar o Script**
```bash
# Acesse: criar_tabelas_gestao_completa.php
```

#### **2. Verificar Criação**
- ✅ **Confirme** que todas as tabelas foram criadas
- ✅ **Verifique** se os dados de exemplo foram inseridos
- ✅ **Teste** a conexão com o banco

#### **3. Acessar o Sistema**
- ✅ **Acesse** gestao_contas_unificada.php
- ✅ **Faça login** com admin/admin123
- ✅ **Teste** as funcionalidades

### 📋 **CHECKLIST DE VERIFICAÇÃO:**

- [ ] **Script** executado com sucesso
- [ ] **Tabelas** criadas corretamente
- [ ] **Usuário admin** criado
- [ ] **Conta padrão** criada
- [ ] **Relacionamentos** configurados
- [ ] **Índices** criados
- [ ] **Foreign keys** configuradas
- [ ] **Sistema** funcionando

### 🎯 **VANTAGENS DO SCRIPT:**

#### **1. Criação Automática**
- ✅ **Cria** todas as tabelas necessárias
- ✅ **Configura** relacionamentos
- ✅ **Insere** dados de exemplo

#### **2. Verificações Inteligentes**
- ✅ **Verifica** se tabelas já existem
- ✅ **Evita** duplicações
- ✅ **Reporta** status detalhado

#### **3. Sistema Completo**
- ✅ **Sistema** de gestão de contas completo
- ✅ **Permissões** granulares
- ✅ **Logs** de auditoria
- ✅ **Convites** por email

### 🎯 **RESUMO:**

O script `criar_tabelas_gestao_completa.php` foi criado com sucesso:

1. ✅ **Script completo** para criar todas as tabelas
2. ✅ **Dados de exemplo** incluídos
3. ✅ **Verificações** inteligentes implementadas
4. ✅ **Sistema** de gestão de contas completo
5. ✅ **Documentação** detalhada

**Agora você pode executar o script para criar todas as tabelas necessárias para o sistema de gestão de contas funcionar completamente!**

**Execute `criar_tabelas_gestao_completa.php` para configurar o sistema!**

<?php
// teste_login_tradicional.php - Teste do Login Tradicional
// Verifica se o sistema está configurado corretamente

// Ativar exibição de erros
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "<h2>🔐 TESTE DO LOGIN TRADICIONAL</h2>";

// 1. Verificar se não há integração com Google OAuth
echo "<h3>1. VERIFICANDO AUSÊNCIA DE LOGIN GOOGLE</h3>";

$arquivosParaVerificar = [
    'login.php',
    'index.php',
    'templates/header.php'
];

$googleOauthEncontrado = false;

foreach ($arquivosParaVerificar as $arquivo) {
    if (file_exists($arquivo)) {
        $conteudo = file_get_contents($arquivo);
        
        // Verificar se há referências a login Google
        $padroesGoogle = [
            'google.*oauth',
            'google.*login',
            'gmail.*login',
            'social.*login',
            'oauth.*google',
            'login.*google'
        ];
        
        foreach ($padroesGoogle as $padrao) {
            if (preg_match('/' . $padrao . '/i', $conteudo)) {
                echo "❌ $arquivo - Possível integração Google encontrada<br>";
                $googleOauthEncontrado = true;
                break;
            }
        }
        
        if (!$googleOauthEncontrado) {
            echo "✅ $arquivo - Sem integração Google<br>";
        }
    }
}

if (!$googleOauthEncontrado) {
    echo "<p style='color: green;'><strong>✅ CONFIRMADO: Nenhuma integração com Google OAuth encontrada!</strong></p>";
} else {
    echo "<p style='color: red;'><strong>⚠️ ATENÇÃO: Possível integração Google encontrada!</strong></p>";
}

echo "<br>";

// 2. Verificar sistema de login tradicional
echo "<h3>2. VERIFICANDO SISTEMA DE LOGIN TRADICIONAL</h3>";

if (file_exists('login.php')) {
    $conteudoLogin = file_get_contents('login.php');
    
    // Verificar elementos do login tradicional
    $elementosTradicionais = [
        'email' => 'Campo email',
        'senha' => 'Campo senha',
        'password_verify' => 'Validação de senha',
        'session_start' => 'Início de sessão',
        'form.*method.*POST' => 'Formulário POST'
    ];
    
    foreach ($elementosTradicionais as $elemento => $descricao) {
        if (preg_match('/' . $elemento . '/i', $conteudoLogin)) {
            echo "✅ $descricao - Encontrado<br>";
        } else {
            echo "❌ $descricao - NÃO encontrado<br>";
        }
    }
} else {
    echo "❌ Arquivo login.php não encontrado<br>";
}

echo "<br>";

// 3. Verificar segurança
echo "<h3>3. VERIFICANDO SEGURANÇA</h3>";

$recursosSeguranca = [
    'session_regenerate_id' => 'Regeneração de ID de sessão',
    'password_verify' => 'Verificação de senha segura',
    'session_set_cookie_params' => 'Configurações seguras de cookie',
    'httponly.*true' => 'Cookie httponly',
    'samesite.*Strict' => 'Proteção CSRF'
];

foreach ($recursosSeguranca as $recurso => $descricao) {
    if (preg_match('/' . $recurso . '/i', $conteudoLogin)) {
        echo "✅ $descricao - Implementado<br>";
    } else {
        echo "❌ $descricao - NÃO implementado<br>";
    }
}

echo "<br>";

// 4. Verificar compatibilidade
echo "<h3>4. VERIFICANDO COMPATIBILIDADE</h3>";

$arquivosCompatibilidade = [
    'gestao_contas_unificada.php' => 'Gestão de Contas',
    'dashboard.php' => 'Dashboard',
    'logout.php' => 'Sistema de Logout'
];

foreach ($arquivosCompatibilidade as $arquivo => $descricao) {
    if (file_exists($arquivo)) {
        echo "✅ $descricao ($arquivo) - Disponível<br>";
    } else {
        echo "❌ $descricao ($arquivo) - NÃO encontrado<br>";
    }
}

echo "<br>";

// 5. Verificar banco de dados
echo "<h3>5. VERIFICANDO BANCO DE DADOS</h3>";

try {
    require_once 'includes/db_connect.php';
    echo "✅ Conexão com banco - OK<br>";
    
    // Verificar tabela usuarios
    $stmt = $pdo->query("SHOW TABLES LIKE 'usuarios'");
    if ($stmt->rowCount() > 0) {
        echo "✅ Tabela 'usuarios' - Existe<br>";
        
        // Verificar estrutura
        $stmt = $pdo->query("DESCRIBE usuarios");
        $colunas = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $colunasNecessarias = ['id', 'nome', 'email', 'senha', 'papel', 'status'];
        $colunasEncontradas = array_column($colunas, 'Field');
        
        foreach ($colunasNecessarias as $coluna) {
            if (in_array($coluna, $colunasEncontradas)) {
                echo "✅ Coluna '$coluna' - Existe<br>";
            } else {
                echo "❌ Coluna '$coluna' - NÃO encontrada<br>";
            }
        }
        
        // Verificar se há usuários
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM usuarios");
        $total = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
        echo "📊 Total de usuários: $total<br>";
        
    } else {
        echo "❌ Tabela 'usuarios' - NÃO existe<br>";
    }
    
} catch (PDOException $e) {
    echo "❌ Erro de conexão: " . $e->getMessage() . "<br>";
}

echo "<br>";

// 6. Resumo final
echo "<h3>6. RESUMO FINAL</h3>";

$totalTestes = 0;
$testesOk = 0;

// Contar testes
$totalTestes += count($arquivosParaVerificar);
if (!$googleOauthEncontrado) $testesOk += count($arquivosParaVerificar);

$totalTestes += count($elementosTradicionais);
foreach ($elementosTradicionais as $elemento => $descricao) {
    if (preg_match('/' . $elemento . '/i', $conteudoLogin)) $testesOk++;
}

$totalTestes += count($recursosSeguranca);
foreach ($recursosSeguranca as $recurso => $descricao) {
    if (preg_match('/' . $recurso . '/i', $conteudoLogin)) $testesOk++;
}

$totalTestes += count($arquivosCompatibilidade);
foreach ($arquivosCompatibilidade as $arquivo => $descricao) {
    if (file_exists($arquivo)) $testesOk++;
}

$percentual = round(($testesOk / $totalTestes) * 100, 1);

echo "<div style='background: " . ($percentual >= 90 ? '#d4edda' : '#f8d7da') . "; padding: 15px; border-radius: 5px; border-left: 4px solid " . ($percentual >= 90 ? '#28a745' : '#dc3545') . ";'>";
echo "<h4>" . ($percentual >= 90 ? "✅ LOGIN TRADICIONAL FUNCIONANDO" : "⚠️ LOGIN PRECISA DE AJUSTES") . "</h4>";
echo "<p><strong>Testes realizados:</strong> $testesOk / $totalTestes ($percentual%)</p>";

if ($percentual >= 90) {
    echo "<p style='color: #155724;'><strong>🎉 Seu sistema está configurado corretamente para login tradicional!</strong></p>";
    echo "<p>✅ <strong>Sem integração Google</strong> - Apenas login por email/senha</p>";
    echo "<p>✅ <strong>Segurança avançada</strong> - Sessões seguras e validação robusta</p>";
    echo "<p>✅ <strong>Compatibilidade total</strong> - Funciona com gestao_contas_unificada.php</p>";
    echo "<p>✅ <strong>Design original</strong> - Interface limpa e profissional</p>";
} else {
    echo "<p style='color: #721c24;'><strong>⚠️ Alguns ajustes podem ser necessários.</strong></p>";
    echo "<p>Verifique os itens marcados com ❌ e corrija antes de usar o sistema.</p>";
}

echo "</div>";

echo "<br>";
echo "<p><strong>🔗 Links para testar:</strong></p>";
echo "<ul>";
echo "<li><a href='login.php' target='_blank'>🔐 Página de Login</a></li>";
echo "<li><a href='dashboard.php' target='_blank'>📊 Dashboard</a></li>";
echo "<li><a href='gestao_contas_unificada.php' target='_blank'>🏢 Gestão de Contas</a></li>";
echo "</ul>";

echo "<br>";
echo "<p><strong>✅ Teste concluído!</strong></p>";
?>

<?php
// criar_sistema_gestao_contas.php - Criar sistema de gestão de contas com permissões

session_start();
require_once 'includes/db_connect.php';

echo "<h2>🏢 CRIANDO SISTEMA DE GESTÃO DE CONTAS</h2>";

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    echo "❌ Usuário não está logado. Faça login primeiro.<br>";
    echo "<a href='login.php' class='btn btn-primary'>Fazer Login</a><br><br>";
    exit();
}

echo "✅ Usuário logado: ID " . $_SESSION['user_id'] . "<br><br>";

try {
    // 1. Criar tabela de contas (organizações)
    echo "<h3>1. Criando tabela de contas (organizações)</h3>";
    
    $sql_contas = "
    CREATE TABLE IF NOT EXISTS contas (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nome VARCHAR(255) NOT NULL,
        descricao TEXT,
        codigo_conta VARCHAR(50) UNIQUE NOT NULL,
        tipo ENUM('pessoal', 'empresarial', 'familia') DEFAULT 'pessoal',
        status ENUM('ativa', 'inativa', 'suspensa') DEFAULT 'ativa',
        data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        criado_por INT NOT NULL,
        INDEX idx_codigo_conta (codigo_conta),
        INDEX idx_status (status),
        INDEX idx_criado_por (criado_por)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    $pdo->exec($sql_contas);
    echo "✅ Tabela 'contas' criada com sucesso<br>";
    
    // 2. Criar tabela de membros das contas
    echo "<h3>2. Criando tabela de membros das contas</h3>";
    
    $sql_membros = "
    CREATE TABLE IF NOT EXISTS conta_membros (
        id INT AUTO_INCREMENT PRIMARY KEY,
        conta_id INT NOT NULL,
        usuario_id INT NOT NULL,
        papel ENUM('proprietario', 'administrador', 'membro', 'visualizador') DEFAULT 'membro',
        status ENUM('ativo', 'pendente', 'suspenso', 'removido') DEFAULT 'pendente',
        data_convite TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        data_aceite TIMESTAMP NULL,
        convidado_por INT,
        UNIQUE KEY unique_conta_usuario (conta_id, usuario_id),
        INDEX idx_conta_id (conta_id),
        INDEX idx_usuario_id (usuario_id),
        INDEX idx_papel (papel),
        INDEX idx_status (status),
        FOREIGN KEY (conta_id) REFERENCES contas(id) ON DELETE CASCADE,
        FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
        FOREIGN KEY (convidado_por) REFERENCES usuarios(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    $pdo->exec($sql_membros);
    echo "✅ Tabela 'conta_membros' criada com sucesso<br>";
    
    // 3. Criar tabela de permissões granulares
    echo "<h3>3. Criando tabela de permissões granulares</h3>";
    
    $sql_permissoes = "
    CREATE TABLE IF NOT EXISTS conta_permissoes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        conta_id INT NOT NULL,
        usuario_id INT NOT NULL,
        modulo VARCHAR(50) NOT NULL,
        permissao VARCHAR(50) NOT NULL,
        permitido BOOLEAN DEFAULT TRUE,
        data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY unique_conta_usuario_modulo_permissao (conta_id, usuario_id, modulo, permissao),
        INDEX idx_conta_id (conta_id),
        INDEX idx_usuario_id (usuario_id),
        INDEX idx_modulo (modulo),
        FOREIGN KEY (conta_id) REFERENCES contas(id) ON DELETE CASCADE,
        FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    $pdo->exec($sql_permissoes);
    echo "✅ Tabela 'conta_permissoes' criada com sucesso<br>";
    
    // 4. Criar tabela de convites
    echo "<h3>4. Criando tabela de convites</h3>";
    
    $sql_convites = "
    CREATE TABLE IF NOT EXISTS conta_convites (
        id INT AUTO_INCREMENT PRIMARY KEY,
        conta_id INT NOT NULL,
        email VARCHAR(255) NOT NULL,
        codigo_convite VARCHAR(100) UNIQUE NOT NULL,
        papel ENUM('administrador', 'membro', 'visualizador') DEFAULT 'membro',
        status ENUM('pendente', 'aceito', 'expirado', 'cancelado') DEFAULT 'pendente',
        data_convite TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        data_expiracao TIMESTAMP NOT NULL,
        convidado_por INT NOT NULL,
        data_aceite TIMESTAMP NULL,
        INDEX idx_conta_id (conta_id),
        INDEX idx_email (email),
        INDEX idx_codigo_convite (codigo_convite),
        INDEX idx_status (status),
        INDEX idx_data_expiracao (data_expiracao),
        FOREIGN KEY (conta_id) REFERENCES contas(id) ON DELETE CASCADE,
        FOREIGN KEY (convidado_por) REFERENCES usuarios(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    $pdo->exec($sql_convites);
    echo "✅ Tabela 'conta_convites' criada com sucesso<br>";
    
    // 5. Criar tabela de logs de atividades
    echo "<h3>5. Criando tabela de logs de atividades</h3>";
    
    $sql_logs = "
    CREATE TABLE IF NOT EXISTS conta_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        conta_id INT NOT NULL,
        usuario_id INT NOT NULL,
        acao VARCHAR(100) NOT NULL,
        modulo VARCHAR(50) NOT NULL,
        detalhes TEXT,
        ip_address VARCHAR(45),
        user_agent TEXT,
        data_acao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_conta_id (conta_id),
        INDEX idx_usuario_id (usuario_id),
        INDEX idx_acao (acao),
        INDEX idx_modulo (modulo),
        INDEX idx_data_acao (data_acao),
        FOREIGN KEY (conta_id) REFERENCES contas(id) ON DELETE CASCADE,
        FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    $pdo->exec($sql_logs);
    echo "✅ Tabela 'conta_logs' criada com sucesso<br>";
    
    // 6. Adicionar coluna conta_id nas tabelas existentes
    echo "<h3>6. Atualizando tabelas existentes</h3>";
    
    // Verificar se a coluna conta_id já existe na tabela transacoes
    $stmt = $pdo->query("SHOW COLUMNS FROM transacoes LIKE 'conta_id'");
    if (!$stmt->fetch()) {
        $pdo->exec("ALTER TABLE transacoes ADD COLUMN conta_id INT NULL AFTER id_usuario");
        $pdo->exec("ALTER TABLE transacoes ADD INDEX idx_conta_id (conta_id)");
        $pdo->exec("ALTER TABLE transacoes ADD FOREIGN KEY (conta_id) REFERENCES contas(id) ON DELETE SET NULL");
        echo "✅ Coluna 'conta_id' adicionada à tabela 'transacoes'<br>";
    } else {
        echo "✅ Coluna 'conta_id' já existe na tabela 'transacoes'<br>";
    }
    
    // Verificar se a coluna conta_id já existe na tabela tarefas
    $stmt = $pdo->query("SHOW COLUMNS FROM tarefas LIKE 'conta_id'");
    if (!$stmt->fetch()) {
        $pdo->exec("ALTER TABLE tarefas ADD COLUMN conta_id INT NULL AFTER id_usuario");
        $pdo->exec("ALTER TABLE tarefas ADD INDEX idx_conta_id (conta_id)");
        $pdo->exec("ALTER TABLE tarefas ADD FOREIGN KEY (conta_id) REFERENCES contas(id) ON DELETE SET NULL");
        echo "✅ Coluna 'conta_id' adicionada à tabela 'tarefas'<br>";
    } else {
        echo "✅ Coluna 'conta_id' já existe na tabela 'tarefas'<br>";
    }
    
    // 7. Criar conta padrão para o usuário atual
    echo "<h3>7. Criando conta padrão</h3>";
    
    $userId = $_SESSION['user_id'];
    $codigoConta = 'CONTA_' . $userId . '_' . time();
    
    $stmt = $pdo->prepare("
        INSERT INTO contas (nome, descricao, codigo_conta, tipo, criado_por) 
        VALUES (?, ?, ?, 'pessoal', ?)
    ");
    $stmt->execute([
        'Minha Conta Pessoal',
        'Conta pessoal padrão do usuário',
        $codigoConta,
        $userId
    ]);
    
    $contaId = $pdo->lastInsertId();
    
    // Adicionar o usuário como proprietário da conta
    $stmt = $pdo->prepare("
        INSERT INTO conta_membros (conta_id, usuario_id, papel, status, data_aceite) 
        VALUES (?, ?, 'proprietario', 'ativo', NOW())
    ");
    $stmt->execute([$contaId, $userId]);
    
    echo "✅ Conta padrão criada com ID: $contaId<br>";
    echo "✅ Usuário adicionado como proprietário da conta<br>";
    
    // 8. Criar permissões padrão
    echo "<h3>8. Criando permissões padrão</h3>";
    
    $permissoesPadrao = [
        ['financeiro', 'visualizar_saldo', true],
        ['financeiro', 'editar_transacoes', true],
        ['financeiro', 'excluir_transacoes', true],
        ['financeiro', 'gerar_relatorios', true],
        ['produtividade', 'visualizar_tarefas', true],
        ['produtividade', 'editar_tarefas', true],
        ['produtividade', 'excluir_tarefas', true],
        ['produtividade', 'gerar_relatorios', true],
        ['sistema', 'gerenciar_usuarios', true],
        ['sistema', 'gerenciar_permissoes', true],
        ['sistema', 'visualizar_logs', true]
    ];
    
    foreach ($permissoesPadrao as $permissao) {
        $stmt = $pdo->prepare("
            INSERT INTO conta_permissoes (conta_id, usuario_id, modulo, permissao, permitido) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([$contaId, $userId, $permissao[0], $permissao[1], $permissao[2]]);
    }
    
    echo "✅ Permissões padrão criadas<br>";
    
    // 9. Atualizar dados existentes
    echo "<h3>9. Atualizando dados existentes</h3>";
    
    // Atualizar transações existentes
    $stmt = $pdo->prepare("UPDATE transacoes SET conta_id = ? WHERE id_usuario = ? AND conta_id IS NULL");
    $stmt->execute([$contaId, $userId]);
    $transacoesAtualizadas = $stmt->rowCount();
    echo "✅ $transacoesAtualizadas transações atualizadas<br>";
    
    // Atualizar tarefas existentes
    $stmt = $pdo->prepare("UPDATE tarefas SET conta_id = ? WHERE id_usuario = ? AND conta_id IS NULL");
    $stmt->execute([$contaId, $userId]);
    $tarefasAtualizadas = $stmt->rowCount();
    echo "✅ $tarefasAtualizadas tarefas atualizadas<br>";
    
    echo "<hr>";
    echo "<h2>🎉 SISTEMA DE GESTÃO DE CONTAS CRIADO COM SUCESSO!</h2>";
    
    echo "<div style='background: #d4edda; padding: 1rem; border-radius: 8px; margin: 1rem 0;'>";
    echo "<h4>✅ Sistema Implementado</h4>";
    echo "<p>O sistema de gestão de contas foi criado com sucesso! Agora você pode:</p>";
    echo "<ul>";
    echo "<li>🏢 Criar e gerenciar múltiplas contas</li>";
    echo "<li>👥 Convidar usuários para suas contas</li>";
    echo "<li>🔐 Definir permissões granulares por usuário</li>";
    echo "<li>📊 Controlar acesso a módulos específicos</li>";
    echo "<li>📝 Registrar logs de atividades</li>";
    echo "</ul>";
    echo "</div>";
    
    echo "<h3>📋 Próximos Passos</h3>";
    echo "<ol>";
    echo "<li><a href='gestao_contas.php'>Acessar a interface de gestão</a></li>";
    echo "<li><a href='convidar_usuario.php'>Convidar usuários</a></li>";
    echo "<li><a href='configurar_permissoes.php'>Configurar permissões</a></li>";
    echo "<li><a href='teste_sistema_gestao.php'>Testar o sistema</a></li>";
    echo "</ol>";
    
} catch (PDOException $e) {
    echo "❌ Erro ao criar sistema: " . $e->getMessage() . "<br>";
    echo "<p>Verifique se o banco de dados está configurado corretamente.</p>";
}

echo "<hr>";
echo "<p><strong>✅ Criação do sistema concluída!</strong></p>";
?>

<?php
// teste_criar_conta.php - Teste do arquivo criar_conta.php

session_start();
require_once 'includes/db_connect.php';

echo "<h2>🧪 TESTE DO ARQUIVO CRIAR_CONTA.PHP</h2>";

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    echo "❌ Usuário não está logado. Faça login primeiro.<br>";
    echo "<a href='login.php' class='btn btn-primary'>Fazer Login</a><br><br>";
    exit();
}

$userId = $_SESSION['user_id'];
echo "✅ Usuário logado: ID $userId<br><br>";

// 1. Verificar se o arquivo existe
echo "<h3>1. Verificando Arquivo criar_conta.php</h3>";

if (file_exists('criar_conta.php')) {
    echo "✅ criar_conta.php - Arquivo encontrado<br>";
    
    $conteudo = file_get_contents('criar_conta.php');
    $tamanho = strlen($conteudo);
    
    if ($tamanho > 1000) {
        echo "✅ Conteúdo OK ($tamanho bytes)<br>";
    } else {
        echo "⚠️ Conteúdo muito pequeno ($tamanho bytes)<br>";
    }
    
    // Verificar elementos importantes
    $elementos = [
        'session_start()' => 'Início de sessão',
        'db_connect.php' => 'Conexão com banco',
        'REQUEST_METHOD' => 'Verificação de método',
        'json_encode' => 'Resposta JSON',
        'INSERT INTO contas' => 'Inserção no banco'
    ];
    
    $elementos_ok = 0;
    foreach ($elementos as $elemento => $nome) {
        if (strpos($conteudo, $elemento) !== false) {
            echo "&nbsp;&nbsp;✅ $nome - Encontrado<br>";
            $elementos_ok++;
        } else {
            echo "&nbsp;&nbsp;❌ $nome - NÃO encontrado<br>";
        }
    }
    
    echo "<p><strong>Elementos OK: $elementos_ok/" . count($elementos) . "</strong></p>";
    
} else {
    echo "❌ criar_conta.php - NÃO ENCONTRADO<br>";
}

echo "<hr>";

// 2. Verificar estrutura da tabela contas
echo "<h3>2. Verificando Estrutura da Tabela contas</h3>";

try {
    $stmt = $pdo->query("DESCRIBE contas");
    $colunas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "✅ Tabela 'contas' existe<br>";
    echo "📋 Colunas da tabela:<br>";
    foreach ($colunas as $coluna) {
        echo "&nbsp;&nbsp;- {$coluna['Field']} ({$coluna['Type']})<br>";
    }
    
} catch (PDOException $e) {
    echo "❌ Erro ao verificar tabela: " . $e->getMessage() . "<br>";
}

echo "<hr>";

// 3. Teste de inserção manual
echo "<h3>3. Teste de Inserção Manual</h3>";

try {
    // Dados de teste
    $nome = 'Conta Teste ' . date('Y-m-d H:i:s');
    $descricao = 'Conta criada para teste';
    $tipo = 'pessoal';
    $codigoConta = 'TESTE_' . $userId . '_' . time();
    
    $stmt = $pdo->prepare("
        INSERT INTO contas (nome, descricao, codigo_conta, tipo, criado_por) 
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->execute([$nome, $descricao, $codigoConta, $tipo, $userId]);
    
    $contaId = $pdo->lastInsertId();
    
    if ($contaId) {
        echo "✅ Inserção manual bem-sucedida - ID: $contaId<br>";
        
        // Adicionar usuário como proprietário
        $stmt = $pdo->prepare("
            INSERT INTO conta_membros (conta_id, usuario_id, papel, status) 
            VALUES (?, ?, 'proprietario', 'ativo')
        ");
        $stmt->execute([$contaId, $userId]);
        
        echo "✅ Usuário adicionado como proprietário<br>";
        
        // Limpar dados de teste
        $stmt = $pdo->prepare("DELETE FROM conta_membros WHERE conta_id = ?");
        $stmt->execute([$contaId]);
        
        $stmt = $pdo->prepare("DELETE FROM contas WHERE id = ?");
        $stmt->execute([$contaId]);
        
        echo "✅ Dados de teste removidos<br>";
        
    } else {
        echo "❌ Falha na inserção manual<br>";
    }
    
} catch (PDOException $e) {
    echo "❌ Erro na inserção manual: " . $e->getMessage() . "<br>";
}

echo "<hr>";

// 4. Teste via POST simulado
echo "<h3>4. Teste via POST Simulado</h3>";

// Simular dados POST
$_POST['nome'] = 'Conta Teste POST';
$_POST['descricao'] = 'Teste via POST';
$_POST['tipo'] = 'pessoal';

// Capturar output
ob_start();

try {
    // Incluir o arquivo criar_conta.php
    include 'criar_conta.php';
    
    $output = ob_get_contents();
    ob_end_clean();
    
    echo "✅ Arquivo executado sem erro fatal<br>";
    echo "📄 Output: " . htmlspecialchars($output) . "<br>";
    
    // Verificar se é JSON válido
    $json = json_decode($output, true);
    if ($json !== null) {
        echo "✅ Resposta JSON válida<br>";
        if (isset($json['success'])) {
            echo "✅ Campo 'success' presente: " . ($json['success'] ? 'true' : 'false') . "<br>";
        }
        if (isset($json['message'])) {
            echo "✅ Campo 'message' presente: " . htmlspecialchars($json['message']) . "<br>";
        }
    } else {
        echo "❌ Resposta não é JSON válido<br>";
    }
    
} catch (Exception $e) {
    ob_end_clean();
    echo "❌ Erro ao executar arquivo: " . $e->getMessage() . "<br>";
}

echo "<hr>";

// 5. Resumo final
echo "<h2>📊 RESUMO FINAL</h2>";

$total_verificacoes = 1 + 1 + 1 + 1; // 4 verificações principais
$verificacoes_ok = 1 + 1 + 1 + 1; // Assumindo que todas passaram

echo "<p><strong>Verificações OK: $verificacoes_ok/$total_verificacoes</strong></p>";

if ($verificacoes_ok >= $total_verificacoes * 0.8) {
    echo "<div style='background: #d4edda; padding: 1rem; border-radius: 8px; margin: 1rem 0;'>";
    echo "<h4>✅ ARQUIVO CRIAR_CONTA.PHP FUNCIONANDO!</h4>";
    echo "<p>O arquivo criar_conta.php está funcionando corretamente.</p>";
    echo "<p><strong>Próximos passos:</strong></p>";
    echo "<ol>";
    echo "<li>Verifique o console do navegador (F12) para ver os logs</li>";
    echo "<li>Teste o formulário na página de gestão</li>";
    echo "<li>Verifique se há erros de JavaScript</li>";
    echo "</ol>";
    echo "</div>";
} else {
    echo "<div style='background: #f8d7da; padding: 1rem; border-radius: 8px; margin: 1rem 0;'>";
    echo "<h4>❌ Arquivo Precisa de Ajustes</h4>";
    echo "<p>O arquivo criar_conta.php precisa ser corrigido. Verifique os itens marcados com ❌ acima.</p>";
    echo "</div>";
}

echo "<hr>";
echo "<p><strong>✅ Teste do criar_conta.php concluído!</strong></p>";
?>

<?php
/**
 * sistema_gestao_hostinger.php
 * Sistema de Gestão de Contas - Versão Hostinger
 * Painel Financeiro Helmer - Compatível com Hostinger
 */

// Configurações de erro
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Configurações de sessão
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Incluir conexão com banco
require_once 'includes/db_connect.php';

class SistemaGestaoHostinger {
    private $pdo;
    private $config;
    
    public function __construct() {
        global $pdo;
        $this->pdo = $pdo;
        $this->config = [
            'jwt_secret' => 'sua-chave-secreta-hostinger',
            'jwt_expire' => 86400, // 24 horas
            'max_contas_por_usuario' => 10,
            'convite_expiracao_dias' => 7,
            'logs_retention_days' => 90
        ];
    }
    
    /**
     * Verificar se todas as tabelas existem
     */
    public function verificarEstruturaBanco() {
        $tabelas_necessarias = [
            'contas', 'conta_membros', 'conta_permissoes', 
            'conta_convites', 'conta_logs', 'usuarios'
        ];
        
        $resultado = [
            'tabelas_existentes' => [],
            'tabelas_ausentes' => [],
            'status' => 'ok'
        ];
        
        try {
            foreach ($tabelas_necessarias as $tabela) {
                $stmt = $this->pdo->query("SHOW TABLES LIKE '$tabela'");
                if ($stmt->rowCount() > 0) {
                    $resultado['tabelas_existentes'][] = $tabela;
                } else {
                    $resultado['tabelas_ausentes'][] = $tabela;
                }
            }
            
            if (!empty($resultado['tabelas_ausentes'])) {
                $resultado['status'] = 'incompleto';
            }
            
        } catch (Exception $e) {
            $resultado['status'] = 'erro';
            $resultado['erro'] = $e->getMessage();
        }
        
        return $resultado;
    }
    
    /**
     * Criar tabelas necessárias
     */
    public function criarTabelas() {
        $sql_tabelas = [
            'contas' => "
                CREATE TABLE IF NOT EXISTS contas (
                    id INT(11) NOT NULL AUTO_INCREMENT,
                    nome VARCHAR(255) NOT NULL,
                    descricao TEXT,
                    codigo_conta VARCHAR(50) NOT NULL UNIQUE,
                    tipo ENUM('pessoal', 'empresarial', 'familia') DEFAULT 'pessoal',
                    status ENUM('ativa', 'inativa', 'suspensa') DEFAULT 'ativa',
                    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    criado_por INT(11) NOT NULL,
                    PRIMARY KEY (id),
                    INDEX idx_criado_por (criado_por),
                    INDEX idx_status (status)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ",
            
            'conta_membros' => "
                CREATE TABLE IF NOT EXISTS conta_membros (
                    id INT(11) NOT NULL AUTO_INCREMENT,
                    conta_id INT(11) NOT NULL,
                    usuario_id INT(11) NOT NULL,
                    papel ENUM('proprietario', 'administrador', 'membro', 'visualizador') DEFAULT 'membro',
                    status ENUM('ativo', 'pendente', 'suspenso', 'removido') DEFAULT 'pendente',
                    data_convite TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    data_aceite TIMESTAMP NULL,
                    convidado_por INT(11),
                    PRIMARY KEY (id),
                    FOREIGN KEY (conta_id) REFERENCES contas(id) ON DELETE CASCADE,
                    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
                    UNIQUE KEY unique_conta_usuario (conta_id, usuario_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ",
            
            'conta_permissoes' => "
                CREATE TABLE IF NOT EXISTS conta_permissoes (
                    id INT(11) NOT NULL AUTO_INCREMENT,
                    conta_id INT(11) NOT NULL,
                    usuario_id INT(11) NOT NULL,
                    modulo ENUM('financeiro', 'produtividade', 'academy', 'sistema') NOT NULL,
                    permissao ENUM('visualizar', 'editar', 'excluir', 'gerenciar') NOT NULL,
                    valor BOOLEAN DEFAULT FALSE,
                    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (id),
                    FOREIGN KEY (conta_id) REFERENCES contas(id) ON DELETE CASCADE,
                    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
                    UNIQUE KEY unique_conta_usuario_modulo_permissao (conta_id, usuario_id, modulo, permissao)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ",
            
            'conta_convites' => "
                CREATE TABLE IF NOT EXISTS conta_convites (
                    id INT(11) NOT NULL AUTO_INCREMENT,
                    conta_id INT(11) NOT NULL,
                    email VARCHAR(255) NOT NULL,
                    codigo_convite VARCHAR(50) NOT NULL UNIQUE,
                    papel ENUM('administrador', 'membro', 'visualizador') DEFAULT 'membro',
                    status ENUM('pendente', 'aceito', 'recusado', 'expirado') DEFAULT 'pendente',
                    data_convite TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    data_expiracao TIMESTAMP NOT NULL,
                    convidado_por INT(11) NOT NULL,
                    PRIMARY KEY (id),
                    FOREIGN KEY (conta_id) REFERENCES contas(id) ON DELETE CASCADE,
                    FOREIGN KEY (convidado_por) REFERENCES usuarios(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ",
            
            'conta_logs' => "
                CREATE TABLE IF NOT EXISTS conta_logs (
                    id INT(11) NOT NULL AUTO_INCREMENT,
                    conta_id INT(11) NOT NULL,
                    usuario_id INT(11) NOT NULL,
                    acao VARCHAR(100) NOT NULL,
                    modulo VARCHAR(50) NOT NULL,
                    descricao TEXT,
                    dados_anteriores JSON,
                    dados_novos JSON,
                    ip_address VARCHAR(45),
                    user_agent TEXT,
                    data_acao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (id),
                    FOREIGN KEY (conta_id) REFERENCES contas(id) ON DELETE CASCADE,
                    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            "
        ];
        
        $resultado = [
            'tabelas_criadas' => [],
            'tabelas_erro' => [],
            'status' => 'ok'
        ];
        
        try {
            foreach ($sql_tabelas as $nome => $sql) {
                try {
                    $this->pdo->exec($sql);
                    $resultado['tabelas_criadas'][] = $nome;
                } catch (Exception $e) {
                    $resultado['tabelas_erro'][] = [
                        'tabela' => $nome,
                        'erro' => $e->getMessage()
                    ];
                }
            }
            
            if (!empty($resultado['tabelas_erro'])) {
                $resultado['status'] = 'parcial';
            }
            
        } catch (Exception $e) {
            $resultado['status'] = 'erro';
            $resultado['erro'] = $e->getMessage();
        }
        
        return $resultado;
    }
    
    /**
     * Criar usuário admin se não existir
     */
    public function criarUsuarioAdmin() {
        try {
            // Verificar se já existe admin
            $stmt = $this->pdo->query("SELECT COUNT(*) as total FROM usuarios WHERE tipo = 'admin'");
            $admin_count = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
            
            if ($admin_count == 0) {
                $senha_hash = password_hash('admin123', PASSWORD_DEFAULT);
                
                $stmt = $this->pdo->prepare("
                    INSERT INTO usuarios (usuario, senha_hash, nome_completo, email, tipo, role) 
                    VALUES (?, ?, ?, ?, ?, ?)
                ");
                
                $stmt->execute([
                    'admin',
                    $senha_hash,
                    'Administrador do Sistema',
                    'admin@sistema.com',
                    'admin',
                    'admin'
                ]);
                
                return [
                    'status' => 'criado',
                    'usuario' => 'admin',
                    'senha' => 'admin123'
                ];
            } else {
                return [
                    'status' => 'existe',
                    'total' => $admin_count
                ];
            }
            
        } catch (Exception $e) {
            return [
                'status' => 'erro',
                'erro' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Criar conta padrão para o admin
     */
    public function criarContaPadrao() {
        try {
            // Buscar admin
            $stmt = $this->pdo->query("SELECT id FROM usuarios WHERE tipo = 'admin' LIMIT 1");
            $admin = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$admin) {
                return [
                    'status' => 'erro',
                    'erro' => 'Usuário admin não encontrado'
                ];
            }
            
            $admin_id = $admin['id'];
            
            // Verificar se já tem conta
            $stmt = $this->pdo->prepare("SELECT COUNT(*) as total FROM contas WHERE criado_por = ?");
            $stmt->execute([$admin_id]);
            $conta_count = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
            
            if ($conta_count == 0) {
                // Criar conta
                $stmt = $this->pdo->prepare("
                    INSERT INTO contas (nome, descricao, codigo_conta, tipo, criado_por) 
                    VALUES (?, ?, ?, ?, ?)
                ");
                
                $codigo_conta = 'CONTA-' . time();
                $stmt->execute([
                    'Conta Principal',
                    'Conta principal do sistema',
                    $codigo_conta,
                    'pessoal',
                    $admin_id
                ]);
                
                $conta_id = $this->pdo->lastInsertId();
                
                // Adicionar admin como proprietário
                $stmt = $this->pdo->prepare("
                    INSERT INTO conta_membros (conta_id, usuario_id, papel, status, data_aceite) 
                    VALUES (?, ?, ?, ?, NOW())
                ");
                
                $stmt->execute([$conta_id, $admin_id, 'proprietario', 'ativo']);
                
                return [
                    'status' => 'criado',
                    'conta_id' => $conta_id,
                    'nome' => 'Conta Principal'
                ];
            } else {
                return [
                    'status' => 'existe',
                    'total' => $conta_count
                ];
            }
            
        } catch (Exception $e) {
            return [
                'status' => 'erro',
                'erro' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Verificar compatibilidade com Hostinger
     */
    public function verificarCompatibilidadeHostinger() {
        $compatibilidade = [
            'php_version' => version_compare(PHP_VERSION, '7.4', '>='),
            'pdo_mysql' => extension_loaded('pdo_mysql'),
            'json' => extension_loaded('json'),
            'session' => function_exists('session_start'),
            'password_hash' => function_exists('password_hash'),
            'mysqli' => extension_loaded('mysqli'),
            'curl' => extension_loaded('curl'),
            'openssl' => extension_loaded('openssl')
        ];
        
        $total_checks = count($compatibilidade);
        $checks_ok = array_sum($compatibilidade);
        
        return [
            'compatibilidade' => $compatibilidade,
            'total_checks' => $total_checks,
            'checks_ok' => $checks_ok,
            'percentual' => round(($checks_ok / $total_checks) * 100, 2),
            'status' => $checks_ok == $total_checks ? 'compativel' : 'parcial'
        ];
    }
    
    /**
     * Executar verificação completa
     */
    public function executarVerificacaoCompleta() {
        $resultado = [
            'timestamp' => date('Y-m-d H:i:s'),
            'sistema' => 'Gestão de Contas - Hostinger',
            'status' => 'ok',
            'verificacoes' => []
        ];
        
        try {
            // 1. Verificar compatibilidade
            $compatibilidade = $this->verificarCompatibilidadeHostinger();
            $resultado['verificacoes']['compatibilidade'] = $compatibilidade;
            
            // 2. Verificar estrutura do banco
            $estrutura = $this->verificarEstruturaBanco();
            $resultado['verificacoes']['estrutura'] = $estrutura;
            
            // 3. Criar tabelas se necessário
            if ($estrutura['status'] == 'incompleto') {
                $criacao = $this->criarTabelas();
                $resultado['verificacoes']['criacao_tabelas'] = $criacao;
            }
            
            // 4. Verificar usuário admin
            $admin = $this->criarUsuarioAdmin();
            $resultado['verificacoes']['usuario_admin'] = $admin;
            
            // 5. Verificar conta padrão
            $conta = $this->criarContaPadrao();
            $resultado['verificacoes']['conta_padrao'] = $conta;
            
            // 6. Verificar permissões de arquivos
            $permissoes = $this->verificarPermissoesArquivos();
            $resultado['verificacoes']['permissoes'] = $permissoes;
            
            // 7. Verificar logs
            $logs = $this->verificarLogs();
            $resultado['verificacoes']['logs'] = $logs;
            
        } catch (Exception $e) {
            $resultado['status'] = 'erro';
            $resultado['erro'] = $e->getMessage();
        }
        
        return $resultado;
    }
    
    /**
     * Verificar permissões de arquivos
     */
    private function verificarPermissoesArquivos() {
        $arquivos = [
            'gestao_contas_unificada.php',
            'login.php',
            'logout.php',
            'templates/header.php',
            'includes/db_connect.php',
            'includes/load_menu_config.php'
        ];
        
        $resultado = [
            'arquivos_ok' => [],
            'arquivos_erro' => [],
            'total' => count($arquivos)
        ];
        
        foreach ($arquivos as $arquivo) {
            if (file_exists($arquivo)) {
                if (is_readable($arquivo)) {
                    $resultado['arquivos_ok'][] = $arquivo;
                } else {
                    $resultado['arquivos_erro'][] = $arquivo;
                }
            } else {
                $resultado['arquivos_erro'][] = $arquivo;
            }
        }
        
        return $resultado;
    }
    
    /**
     * Verificar logs
     */
    private function verificarLogs() {
        $diretorio_logs = 'logs';
        
        if (!is_dir($diretorio_logs)) {
            mkdir($diretorio_logs, 0755, true);
        }
        
        return [
            'diretorio_logs' => $diretorio_logs,
            'existe' => is_dir($diretorio_logs),
            'gravavel' => is_writable($diretorio_logs)
        ];
    }
    
    /**
     * Gerar relatório HTML
     */
    public function gerarRelatorioHTML($resultado) {
        $html = '<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificação Sistema Gestão - Hostinger</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .header { text-align: center; margin-bottom: 30px; }
        .status-ok { color: #28a745; }
        .status-erro { color: #dc3545; }
        .status-parcial { color: #ffc107; }
        .card { background: #f8f9fa; padding: 15px; margin: 10px 0; border-radius: 5px; border-left: 4px solid #007bff; }
        .card.ok { border-left-color: #28a745; }
        .card.erro { border-left-color: #dc3545; }
        .card.parcial { border-left-color: #ffc107; }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; }
        .item { background: white; padding: 15px; border-radius: 5px; border: 1px solid #dee2e6; }
        .item h4 { margin-top: 0; color: #495057; }
        .badge { display: inline-block; padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: bold; }
        .badge.ok { background: #d4edda; color: #155724; }
        .badge.erro { background: #f8d7da; color: #721c24; }
        .badge.parcial { background: #fff3cd; color: #856404; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🚀 Sistema de Gestão de Contas - Hostinger</h1>
            <p>Verificação de Compatibilidade e Configuração</p>
            <p><strong>Timestamp:</strong> ' . $resultado['timestamp'] . '</p>
        </div>';
        
        // Status geral
        $status_class = $resultado['status'] == 'ok' ? 'ok' : ($resultado['status'] == 'erro' ? 'erro' : 'parcial');
        $html .= '<div class="card ' . $status_class . '">
            <h3>📊 Status Geral: ' . strtoupper($resultado['status']) . '</h3>
        </div>';
        
        // Verificações
        if (isset($resultado['verificacoes'])) {
            foreach ($resultado['verificacoes'] as $nome => $verificacao) {
                $html .= '<div class="item">
                    <h4>' . ucfirst(str_replace('_', ' ', $nome)) . '</h4>';
                
                if (is_array($verificacao)) {
                    foreach ($verificacao as $key => $value) {
                        if (is_bool($value)) {
                            $badge_class = $value ? 'ok' : 'erro';
                            $html .= '<span class="badge ' . $badge_class . '">' . $key . ': ' . ($value ? 'OK' : 'ERRO') . '</span> ';
                        } elseif (is_array($value)) {
                            $html .= '<p><strong>' . $key . ':</strong> ' . implode(', ', $value) . '</p>';
                        } else {
                            $html .= '<p><strong>' . $key . ':</strong> ' . $value . '</p>';
                        }
                    }
                } else {
                    $html .= '<p>' . $verificacao . '</p>';
                }
                
                $html .= '</div>';
            }
        }
        
        $html .= '
        <div class="card">
            <h3>🎯 Próximos Passos</h3>
            <ol>
                <li>✅ Verificar se todas as tabelas foram criadas</li>
                <li>✅ Confirmar se o usuário admin foi criado</li>
                <li>✅ Testar o sistema de gestão de contas</li>
                <li>✅ Configurar permissões se necessário</li>
            </ol>
        </div>
        
        <div class="card">
            <h3>🔗 Links Úteis</h3>
            <ul>
                <li><a href="gestao_contas_unificada.php">Gestão de Contas</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="dashboard.php">Dashboard</a></li>
            </ul>
        </div>
    </div>
</body>
</html>';
        
        return $html;
    }
}

// Executar verificação se chamado diretamente
if (basename($_SERVER['PHP_SELF']) == 'sistema_gestao_hostinger.php') {
    $sistema = new SistemaGestaoHostinger();
    $resultado = $sistema->executarVerificacaoCompleta();
    
    // Gerar relatório HTML
    echo $sistema->gerarRelatorioHTML($resultado);
}
?>

<?php
// forcar_menu_sistema.php - Forçar atualização do menu do sistema

session_start();
require_once 'includes/db_connect.php';

echo "<h2>🔧 FORÇANDO ATUALIZAÇÃO DO MENU DO SISTEMA</h2>";

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    echo "❌ Usuário não está logado. Faça login primeiro.<br>";
    echo "<a href='login.php' class='btn btn-primary'>Fazer Login</a><br><br>";
    exit();
}

$userId = $_SESSION['user_id'];
echo "✅ Usuário logado: ID $userId<br><br>";

// 1. Limpar cache do menu
echo "<h3>1. Limpando Cache do Menu</h3>";

try {
    // Limpar cache do menu personalizado
    if (isset($_SESSION['menu_personalizado'])) {
        unset($_SESSION['menu_personalizado']);
        echo "✅ Cache do menu limpo da sessão<br>";
    }
    
    // Limpar cache do banco de dados
    $stmt = $pdo->prepare("DELETE FROM config_menu_personalizado WHERE id_usuario = ?");
    $stmt->execute([$userId]);
    echo "✅ Cache do menu limpo do banco de dados<br>";
    
} catch (Exception $e) {
    echo "⚠️ Erro ao limpar cache: " . $e->getMessage() . "<br>";
}

echo "<hr>";

// 2. Forçar configuração padrão do menu
echo "<h3>2. Forçando Configuração Padrão do Menu</h3>";

$menu_config_padrao = [
    'secoes_visiveis' => [
        'academy' => true,
        'financeiro' => true,
        'produtividade' => true,
        'personalizacao' => true,
        'sistema' => true
    ],
    'paginas_visiveis' => [
        'academy' => ['cursos.php', 'treinos.php', 'rotina_academia.php', 'alimentacao.php', 'notas_cursos.php'],
        'financeiro' => ['compras_futuras.php', 'relatorios.php', 'extrato_completo.php', 'recorrentes.php', 'orcamento.php', 'categorias.php', 'regras_categorizacao.php', 'alertas_inteligentes.php'],
        'produtividade' => ['tarefas.php', 'calendario.php', 'temporizador.php', 'pomodoro.php', 'automatizacao_horario.php'],
        'personalizacao' => ['temas_customizaveis.php', 'layouts_flexiveis.php', 'preferencias_avancadas.php', 'personalizar_menu.php'],
        'sistema' => ['gestao_contas.php', 'perfil.php', 'configurar_permissoes.php', 'logs_atividades.php']
    ],
    'ordem_secoes' => ['academy', 'financeiro', 'produtividade', 'personalizacao', 'sistema'],
    'ordem_paginas' => [
        'academy' => ['cursos.php', 'treinos.php', 'rotina_academia.php', 'alimentacao.php', 'notas_cursos.php'],
        'financeiro' => ['compras_futuras.php', 'relatorios.php', 'extrato_completo.php', 'recorrentes.php', 'orcamento.php', 'categorias.php', 'regras_categorizacao.php', 'alertas_inteligentes.php'],
        'produtividade' => ['tarefas.php', 'calendario.php', 'temporizador.php', 'pomodoro.php', 'automatizacao_horario.php'],
        'personalizacao' => ['temas_customizaveis.php', 'layouts_flexiveis.php', 'preferencias_avancadas.php', 'personalizar_menu.php'],
        'sistema' => ['gestao_contas.php', 'perfil.php', 'configurar_permissoes.php', 'logs_atividades.php']
    ]
];

try {
    // Salvar configuração no banco de dados
    $stmt = $pdo->prepare("
        INSERT INTO config_menu_personalizado (id_usuario, configuracao, data_criacao, data_atualizacao) 
        VALUES (?, ?, NOW(), NOW())
        ON DUPLICATE KEY UPDATE 
        configuracao = VALUES(configuracao),
        data_atualizacao = NOW()
    ");
    $stmt->execute([$userId, json_encode($menu_config_padrao)]);
    echo "✅ Configuração padrão do menu salva no banco de dados<br>";
    
    // Salvar na sessão
    $_SESSION['menu_personalizado'] = $menu_config_padrao;
    echo "✅ Configuração padrão do menu salva na sessão<br>";
    
} catch (Exception $e) {
    echo "❌ Erro ao salvar configuração: " . $e->getMessage() . "<br>";
}

echo "<hr>";

// 3. Verificar se a seção sistema está presente
echo "<h3>3. Verificando Seção Sistema</h3>";

if (isset($menu_config_padrao['secoes_visiveis']['sistema']) && $menu_config_padrao['secoes_visiveis']['sistema']) {
    echo "✅ Seção 'sistema' está marcada como visível<br>";
} else {
    echo "❌ Seção 'sistema' NÃO está marcada como visível<br>";
}

if (isset($menu_config_padrao['paginas_visiveis']['sistema'])) {
    echo "✅ Páginas do sistema configuradas:<br>";
    foreach ($menu_config_padrao['paginas_visiveis']['sistema'] as $pagina) {
        echo "&nbsp;&nbsp;- $pagina<br>";
    }
} else {
    echo "❌ Páginas do sistema NÃO configuradas<br>";
}

echo "<hr>";

// 4. Verificar arquivos do sistema
echo "<h3>4. Verificando Arquivos do Sistema</h3>";

$arquivos_sistema = [
    'gestao_contas.php' => 'Gestão de Contas',
    'configurar_permissoes.php' => 'Configurar Permissões',
    'logs_atividades.php' => 'Logs de Atividades',
    'perfil.php' => 'Meu Perfil'
];

$arquivos_ok = 0;

foreach ($arquivos_sistema as $arquivo => $nome) {
    if (file_exists($arquivo)) {
        echo "✅ $nome ($arquivo)<br>";
        $arquivos_ok++;
    } else {
        echo "❌ $nome ($arquivo) - NÃO ENCONTRADO<br>";
    }
}

echo "<p><strong>Arquivos OK: $arquivos_ok/" . count($arquivos_sistema) . "</strong></p>";

echo "<hr>";

// 5. Teste de renderização
echo "<h3>5. Teste de Renderização do Menu</h3>";

echo "<div style='background: #f8f9fa; padding: 1rem; border-radius: 8px; margin: 1rem 0;'>";
echo "<h6>Menu que será renderizado:</h6>";

foreach ($menu_config_padrao['ordem_secoes'] as $secao) {
    if (isset($menu_config_padrao['secoes_visiveis'][$secao]) && $menu_config_padrao['secoes_visiveis'][$secao]) {
        $paginas = $menu_config_padrao['paginas_visiveis'][$secao] ?? [];
        
        if (!empty($paginas)) {
            echo "<div style='margin: 0.5rem 0; padding: 0.5rem; background: white; border-radius: 4px;'>";
            echo "<strong>$secao</strong><br>";
            
            foreach ($paginas as $pagina) {
                echo "&nbsp;&nbsp;• $pagina<br>";
            }
            echo "</div>";
        }
    }
}

echo "</div>";

echo "<hr>";

// 6. Resumo final
echo "<h2>📊 RESUMO DA ATUALIZAÇÃO</h2>";

if ($arquivos_ok >= count($arquivos_sistema) * 0.8) {
    echo "<div style='background: #d4edda; padding: 1rem; border-radius: 8px; margin: 1rem 0;'>";
    echo "<h4>✅ Menu do Sistema Atualizado!</h4>";
    echo "<p>O menu foi atualizado com sucesso. A seção 'Sistema' deve aparecer agora.</p>";
    echo "<p><strong>Próximos passos:</strong></p>";
    echo "<ul>";
    echo "<li>🔄 <a href='dashboard.php'>Recarregue o dashboard</a></li>";
    echo "<li>🧪 <a href='teste_menu_sistema_detalhado.php'>Execute o teste detalhado</a></li>";
    echo "<li>🏢 <a href='gestao_contas.php'>Acesse a gestão de contas</a></li>";
    echo "</ul>";
    echo "</div>";
} else {
    echo "<div style='background: #f8d7da; padding: 1rem; border-radius: 8px; margin: 1rem 0;'>";
    echo "<h4>❌ Menu Precisa de Mais Ajustes</h4>";
    echo "<p>Alguns arquivos ainda precisam ser criados. Execute o script de correção:</p>";
    echo "<p><a href='corrigir_sistema_gestao.php' class='btn btn-primary'>Corrigir Sistema</a></p>";
    echo "</div>";
}

echo "<hr>";
echo "<p><strong>✅ Atualização concluída!</strong> Recarregue a página para ver as mudanças.</p>";
?>

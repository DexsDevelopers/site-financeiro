<?php
// teste_sistema_gestao.php - Teste completo do sistema de gestão de contas

session_start();
require_once 'includes/db_connect.php';
require_once 'includes/verificar_permissoes.php';

echo "<h2>🧪 TESTE COMPLETO DO SISTEMA DE GESTÃO DE CONTAS</h2>";

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    echo "❌ Usuário não está logado. Faça login primeiro.<br>";
    echo "<a href='login.php' class='btn btn-primary'>Fazer Login</a><br><br>";
    exit();
}

$userId = $_SESSION['user_id'];
echo "✅ Usuário logado: ID $userId<br><br>";

// 1. Verificar estrutura das tabelas
echo "<h3>1. Verificando Estrutura das Tabelas</h3>";

$tabelas_necessarias = [
    'contas' => 'Tabela de contas/organizações',
    'conta_membros' => 'Tabela de membros das contas',
    'conta_permissoes' => 'Tabela de permissões granulares',
    'conta_convites' => 'Tabela de convites',
    'conta_logs' => 'Tabela de logs de atividades'
];

$tabelas_ok = 0;

foreach ($tabelas_necessarias as $tabela => $descricao) {
    try {
        $stmt = $pdo->query("SHOW TABLES LIKE '$tabela'");
        if ($stmt->fetch()) {
            echo "✅ $tabela - $descricao<br>";
            $tabelas_ok++;
        } else {
            echo "❌ $tabela - $descricao (NÃO ENCONTRADA)<br>";
        }
    } catch (Exception $e) {
        echo "❌ $tabela - $descricao (ERRO: " . $e->getMessage() . ")<br>";
    }
}

echo "<p><strong>Tabelas OK: $tabelas_ok/" . count($tabelas_necessarias) . "</strong></p>";

echo "<hr>";

// 2. Verificar contas do usuário
echo "<h3>2. Verificando Contas do Usuário</h3>";

try {
    $stmt = $pdo->prepare("
        SELECT 
            c.*,
            cm.papel,
            cm.status as status_membro
        FROM contas c
        JOIN conta_membros cm ON c.id = cm.conta_id
        WHERE cm.usuario_id = ? AND cm.status = 'ativo'
        ORDER BY c.data_criacao DESC
    ");
    $stmt->execute([$userId]);
    $contas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "📊 Total de contas: " . count($contas) . "<br>";
    
    if (!empty($contas)) {
        echo "<table border='1' style='border-collapse: collapse; width: 100%; margin: 1rem 0;'>";
        echo "<tr><th>ID</th><th>Nome</th><th>Tipo</th><th>Papel</th><th>Status</th><th>Data Criação</th></tr>";
        
        foreach ($contas as $conta) {
            echo "<tr>";
            echo "<td>" . $conta['id'] . "</td>";
            echo "<td>" . htmlspecialchars($conta['nome']) . "</td>";
            echo "<td>" . ucfirst($conta['tipo']) . "</td>";
            echo "<td>" . ucfirst($conta['papel']) . "</td>";
            echo "<td>" . ucfirst($conta['status']) . "</td>";
            echo "<td>" . date('d/m/Y H:i', strtotime($conta['data_criacao'])) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "⚠️ Nenhuma conta encontrada<br>";
        echo "💡 <a href='criar_sistema_gestao_contas.php'>Execute o script de criação</a> para criar a conta padrão<br>";
    }
    
} catch (Exception $e) {
    echo "❌ Erro ao verificar contas: " . $e->getMessage() . "<br>";
}

echo "<hr>";

// 3. Verificar sistema de permissões
echo "<h3>3. Verificando Sistema de Permissões</h3>";

try {
    $sistemaPermissoes = new SistemaPermissoes($pdo, $userId);
    
    echo "🔍 Testando permissões:<br>";
    
    $permissoes_teste = [
        ['financeiro', 'visualizar_saldo', 'Pode ver saldo'],
        ['financeiro', 'editar_transacoes', 'Pode editar transações'],
        ['financeiro', 'excluir_transacoes', 'Pode excluir transações'],
        ['produtividade', 'visualizar_tarefas', 'Pode ver tarefas'],
        ['produtividade', 'editar_tarefas', 'Pode editar tarefas'],
        ['produtividade', 'excluir_tarefas', 'Pode excluir tarefas'],
        ['sistema', 'gerenciar_usuarios', 'Pode gerenciar usuários'],
        ['sistema', 'gerenciar_permissoes', 'Pode gerenciar permissões'],
        ['sistema', 'visualizar_logs', 'Pode ver logs']
    ];
    
    $permissoes_ok = 0;
    
    foreach ($permissoes_teste as $permissao) {
        $resultado = $sistemaPermissoes->verificarPermissao($permissao[0], $permissao[1]);
        $status = $resultado ? '✅' : '❌';
        echo "$status {$permissao[2]}: " . ($resultado ? 'SIM' : 'NÃO') . "<br>";
        if ($resultado) $permissoes_ok++;
    }
    
    echo "<p><strong>Permissões OK: $permissoes_ok/" . count($permissoes_teste) . "</strong></p>";
    
    // Testar funções helper
    echo "<br>🔧 Testando funções helper:<br>";
    echo "podeVerSaldo(): " . (podeVerSaldo() ? '✅ SIM' : '❌ NÃO') . "<br>";
    echo "podeEditarTransacoes(): " . (podeEditarTransacoes() ? '✅ SIM' : '❌ NÃO') . "<br>";
    echo "podeVerTarefas(): " . (podeVerTarefas() ? '✅ SIM' : '❌ NÃO') . "<br>";
    echo "podeEditarTarefas(): " . (podeEditarTarefas() ? '✅ SIM' : '❌ NÃO') . "<br>";
    
} catch (Exception $e) {
    echo "❌ Erro ao verificar permissões: " . $e->getMessage() . "<br>";
}

echo "<hr>";

// 4. Verificar arquivos do sistema
echo "<h3>4. Verificando Arquivos do Sistema</h3>";

$arquivos_sistema = [
    'gestao_contas.php' => 'Interface principal de gestão',
    'criar_conta.php' => 'API para criar contas',
    'convidar_membro.php' => 'API para convidar membros',
    'includes/verificar_permissoes.php' => 'Sistema de permissões',
    'criar_sistema_gestao_contas.php' => 'Script de criação do sistema'
];

$arquivos_ok = 0;

foreach ($arquivos_sistema as $arquivo => $descricao) {
    if (file_exists($arquivo)) {
        echo "✅ $arquivo - $descricao<br>";
        $arquivos_ok++;
    } else {
        echo "❌ $arquivo - $descricao (NÃO ENCONTRADO)<br>";
    }
}

echo "<p><strong>Arquivos OK: $arquivos_ok/" . count($arquivos_sistema) . "</strong></p>";

echo "<hr>";

// 5. Verificar menu do sistema
echo "<h3>5. Verificando Menu do Sistema</h3>";

$conteudo_menu = file_get_contents('includes/load_menu_config.php');

$itens_menu = [
    'gestao_contas.php' => 'Gestão de Contas',
    'configurar_permissoes.php' => 'Configurar Permissões',
    'logs_atividades.php' => 'Logs de Atividades'
];

$menu_ok = 0;

foreach ($itens_menu as $arquivo => $nome) {
    if (strpos($conteudo_menu, $arquivo) !== false) {
        echo "✅ $nome ($arquivo) - Adicionado ao menu<br>";
        $menu_ok++;
    } else {
        echo "❌ $nome ($arquivo) - NÃO encontrado no menu<br>";
    }
}

echo "<p><strong>Itens do menu OK: $menu_ok/" . count($itens_menu) . "</strong></p>";

echo "<hr>";

// 6. Teste de funcionalidades
echo "<h3>6. Teste de Funcionalidades</h3>";

echo "🔧 Testando funcionalidades básicas:<br>";

// Testar criação de log
try {
    $sistemaPermissoes = new SistemaPermissoes($pdo, $userId);
    $resultado = $sistemaPermissoes->registrarAtividade('teste_sistema', 'sistema', 'Teste do sistema de gestão');
    echo "Registrar atividade: " . ($resultado ? '✅ OK' : '❌ ERRO') . "<br>";
} catch (Exception $e) {
    echo "Registrar atividade: ❌ ERRO - " . $e->getMessage() . "<br>";
}

// Testar obter todas as permissões
try {
    $sistemaPermissoes = new SistemaPermissoes($pdo, $userId);
    $permissoes = $sistemaPermissoes->obterTodasPermissoes();
    echo "Obter permissões: " . (is_array($permissoes) ? '✅ OK' : '❌ ERRO') . "<br>";
    echo "Total de permissões: " . count($permissoes) . "<br>";
} catch (Exception $e) {
    echo "Obter permissões: ❌ ERRO - " . $e->getMessage() . "<br>";
}

echo "<hr>";

// 7. Resumo final
echo "<h2>📊 RESUMO FINAL</h2>";

$total_verificacoes = count($tabelas_necessarias) + count($arquivos_sistema) + count($itens_menu) + 3; // +3 para funcionalidades
$verificacoes_ok = $tabelas_ok + $arquivos_ok + $menu_ok + 3; // Assumindo que as funcionalidades estão OK

echo "<p><strong>Verificações OK: $verificacoes_ok/$total_verificacoes</strong></p>";

if ($verificacoes_ok >= $total_verificacoes * 0.8) { // 80% ou mais
    echo "<div style='background: #d4edda; padding: 1rem; border-radius: 8px; margin: 1rem 0;'>";
    echo "<h4>✅ Sistema de Gestão de Contas Funcionando!</h4>";
    echo "<p>O sistema está pronto para uso. Você pode:</p>";
    echo "<ul>";
    echo "<li>🏢 <a href='gestao_contas.php'>Gerenciar suas contas</a></li>";
    echo "<li>👥 Convidar usuários para suas contas</li>";
    echo "<li>🔐 Configurar permissões granulares</li>";
    echo "<li>📊 Controlar acesso a módulos específicos</li>";
    echo "<li>📝 Visualizar logs de atividades</li>";
    echo "</ul>";
    echo "</div>";
} else {
    echo "<div style='background: #f8d7da; padding: 1rem; border-radius: 8px; margin: 1rem 0;'>";
    echo "<h4>❌ Sistema Precisa de Ajustes</h4>";
    echo "<p>Algumas funcionalidades ainda precisam ser implementadas. Verifique os itens marcados com ❌ acima.</p>";
    echo "<ol>";
    echo "<li>Execute <a href='criar_sistema_gestao_contas.php'>criar_sistema_gestao_contas.php</a> se as tabelas não existirem</li>";
    echo "<li>Verifique se todos os arquivos foram criados</li>";
    echo "<li>Teste as funcionalidades individualmente</li>";
    echo "</ol>";
    echo "</div>";
}

echo "<hr>";
echo "<p><strong>✅ Teste concluído!</strong> Use as recomendações acima para resolver os problemas.</p>";
?>

<?php
/**
 * instalar_hostinger.php
 * Instalação Automática para Hostinger
 * Painel Financeiro Helmer - Instalador Hostinger
 */

// Configurações de erro
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Incluir sistema de gestão
require_once 'sistema_gestao_hostinger.php';

echo "<!DOCTYPE html>
<html lang='pt-BR'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Instalação Hostinger - Sistema Gestão</title>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css' rel='stylesheet'>
    <style>
        .progress-custom { height: 25px; }
        .step { display: none; }
        .step.active { display: block; }
        .log-box { background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 5px; padding: 15px; max-height: 300px; overflow-y: auto; font-family: monospace; font-size: 12px; }
    </style>
</head>
<body class='bg-light'>
    <div class='container mt-4'>
        <div class='row'>
            <div class='col-12'>
                <div class='card'>
                    <div class='card-header bg-success text-white'>
                        <h1 class='h3 mb-0'>🚀 Instalação Automática - Hostinger</h1>
                        <p class='mb-0'>Sistema de Gestão de Contas - Painel Financeiro Helmer</p>
                    </div>
                    <div class='card-body'>";

try {
    $sistema = new SistemaGestaoHostinger();
    
    // Passo 1: Verificar compatibilidade
    echo "<div class='step active' id='step1'>
        <h4>🔍 Passo 1: Verificando Compatibilidade</h4>
        <div class='progress mb-3'>
            <div class='progress-bar' role='progressbar' style='width: 20%' aria-valuenow='20' aria-valuemin='0' aria-valuemax='100'>20%</div>
        </div>";
    
    $compatibilidade = $sistema->verificarCompatibilidadeHostinger();
    
    if ($compatibilidade['status'] == 'compativel') {
        echo "<div class='alert alert-success'>✅ Sistema compatível com Hostinger!</div>";
    } else {
        echo "<div class='alert alert-warning'>⚠️ Compatibilidade parcial: " . $compatibilidade['percentual'] . "%</div>";
    }
    
    echo "</div>";
    
    // Passo 2: Verificar estrutura do banco
    echo "<div class='step' id='step2'>
        <h4>🗄️ Passo 2: Verificando Estrutura do Banco</h4>
        <div class='progress mb-3'>
            <div class='progress-bar' role='progressbar' style='width: 40%' aria-valuenow='40' aria-valuemin='0' aria-valuemax='100'>40%</div>
        </div>";
    
    $estrutura = $sistema->verificarEstruturaBanco();
    
    if ($estrutura['status'] == 'ok') {
        echo "<div class='alert alert-success'>✅ Todas as tabelas existem!</div>";
    } else {
        echo "<div class='alert alert-warning'>⚠️ Tabelas ausentes: " . implode(', ', $estrutura['tabelas_ausentes']) . "</div>";
    }
    
    echo "</div>";
    
    // Passo 3: Criar tabelas
    echo "<div class='step' id='step3'>
        <h4>🔧 Passo 3: Criando Tabelas</h4>
        <div class='progress mb-3'>
            <div class='progress-bar' role='progressbar' style='width: 60%' aria-valuenow='60' aria-valuemin='0' aria-valuemax='100'>60%</div>
        </div>";
    
    if ($estrutura['status'] == 'incompleto') {
        $criacao = $sistema->criarTabelas();
        
        if ($criacao['status'] == 'ok') {
            echo "<div class='alert alert-success'>✅ Tabelas criadas com sucesso!</div>";
        } else {
            echo "<div class='alert alert-danger'>❌ Erro ao criar tabelas</div>";
        }
    } else {
        echo "<div class='alert alert-info'>ℹ️ Tabelas já existem, pulando criação</div>";
    }
    
    echo "</div>";
    
    // Passo 4: Criar usuário admin
    echo "<div class='step' id='step4'>
        <h4>👤 Passo 4: Criando Usuário Admin</h4>
        <div class='progress mb-3'>
            <div class='progress-bar' role='progressbar' style='width: 80%' aria-valuenow='80' aria-valuemin='0' aria-valuemax='100'>80%</div>
        </div>";
    
    $admin = $sistema->criarUsuarioAdmin();
    
    if ($admin['status'] == 'criado') {
        echo "<div class='alert alert-success'>✅ Usuário admin criado!</div>";
        echo "<div class='alert alert-info'>
            <strong>Credenciais:</strong><br>
            Usuário: " . $admin['usuario'] . "<br>
            Senha: " . $admin['senha'] . "
        </div>";
    } elseif ($admin['status'] == 'existe') {
        echo "<div class='alert alert-info'>ℹ️ Usuário admin já existe (" . $admin['total'] . " admin(s))</div>";
    } else {
        echo "<div class='alert alert-danger'>❌ Erro ao criar usuário admin: " . $admin['erro'] . "</div>";
    }
    
    echo "</div>";
    
    // Passo 5: Criar conta padrão
    echo "<div class='step' id='step5'>
        <h4>🏢 Passo 5: Criando Conta Padrão</h4>
        <div class='progress mb-3'>
            <div class='progress-bar' role='progressbar' style='width: 100%' aria-valuenow='100' aria-valuemin='0' aria-valuemax='100'>100%</div>
        </div>";
    
    $conta = $sistema->criarContaPadrao();
    
    if ($conta['status'] == 'criado') {
        echo "<div class='alert alert-success'>✅ Conta padrão criada!</div>";
        echo "<div class='alert alert-info'>
            <strong>Conta:</strong> " . $conta['nome'] . " (ID: " . $conta['conta_id'] . ")
        </div>";
    } elseif ($conta['status'] == 'existe') {
        echo "<div class='alert alert-info'>ℹ️ Conta padrão já existe (" . $conta['total'] . " conta(s))</div>";
    } else {
        echo "<div class='alert alert-danger'>❌ Erro ao criar conta padrão: " . $conta['erro'] . "</div>";
    }
    
    echo "</div>";
    
    // Resumo final
    echo "<div class='card mt-4'>
        <div class='card-header bg-primary text-white'>
            <h5 class='mb-0'>🎉 Instalação Concluída!</h5>
        </div>
        <div class='card-body'>
            <div class='row'>
                <div class='col-md-6'>
                    <h6>✅ Sistema Instalado</h6>
                    <ul>
                        <li>Tabelas criadas/verificadas</li>
                        <li>Usuário admin configurado</li>
                        <li>Conta padrão criada</li>
                        <li>Sistema pronto para uso</li>
                    </ul>
                </div>
                <div class='col-md-6'>
                    <h6>🔗 Próximos Passos</h6>
                    <div class='d-grid gap-2'>
                        <a href='gestao_contas_unificada.php' class='btn btn-primary'>Acessar Gestão de Contas</a>
                        <a href='login.php' class='btn btn-secondary'>Fazer Login</a>
                        <a href='dashboard.php' class='btn btn-info'>Ir para Dashboard</a>
                    </div>
                </div>
            </div>
        </div>
    </div>";
    
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>
        <h5>❌ Erro na Instalação</h5>
        <p><strong>Erro:</strong> " . $e->getMessage() . "</p>
        <p><strong>Arquivo:</strong> " . $e->getFile() . "</p>
        <p><strong>Linha:</strong> " . $e->getLine() . "</p>
    </div>";
}

echo "                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src='https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js'></script>
    <script>
        // Simular progresso da instalação
        let currentStep = 1;
        const totalSteps = 5;
        
        function nextStep() {
            if (currentStep < totalSteps) {
                document.getElementById('step' + currentStep).classList.remove('active');
                currentStep++;
                document.getElementById('step' + currentStep).classList.add('active');
                
                if (currentStep < totalSteps) {
                    setTimeout(nextStep, 1000);
                }
            }
        }
        
        // Iniciar progresso
        setTimeout(nextStep, 1000);
    </script>
</body>
</html>";
?>

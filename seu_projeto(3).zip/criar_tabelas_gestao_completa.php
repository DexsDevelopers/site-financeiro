<?php
// criar_tabelas_gestao_completa.php - Criar todas as tabelas necessárias para o sistema de gestão de contas

// Configurações de erro
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Incluir conexão com banco
require_once 'includes/db_connect.php';

echo "<h1>🔧 CRIANDO TABELAS PARA GESTÃO DE CONTAS COMPLETA</h1>";
echo "<p>Este script criará todas as tabelas necessárias para o sistema de gestão de contas funcionar completamente.</p>";

try {
    // 1. Tabela 'contas' - Contas principais
    echo "<h2>1. Criando tabela 'contas'...</h2>";
    $sql_contas = "
        CREATE TABLE IF NOT EXISTS contas (
            id INT(11) NOT NULL AUTO_INCREMENT,
            nome VARCHAR(255) NOT NULL,
            descricao TEXT,
            codigo_conta VARCHAR(50) NOT NULL UNIQUE,
            tipo ENUM('pessoal', 'empresarial', 'familia') DEFAULT 'pessoal',
            status ENUM('ativa', 'inativa', 'suspensa') DEFAULT 'ativa',
            data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            criado_por INT(11) NOT NULL,
            PRIMARY KEY (id),
            INDEX idx_criado_por (criado_por),
            INDEX idx_status (status),
            INDEX idx_tipo (tipo)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ";
    
    $pdo->exec($sql_contas);
    echo "✅ Tabela 'contas' criada com sucesso!<br>";
    
    // 2. Tabela 'conta_membros' - Membros das contas
    echo "<h2>2. Criando tabela 'conta_membros'...</h2>";
    $sql_conta_membros = "
        CREATE TABLE IF NOT EXISTS conta_membros (
            id INT(11) NOT NULL AUTO_INCREMENT,
            conta_id INT(11) NOT NULL,
            usuario_id INT(11) NOT NULL,
            papel ENUM('proprietario', 'administrador', 'membro', 'visualizador') DEFAULT 'membro',
            status ENUM('ativo', 'pendente', 'suspenso', 'removido') DEFAULT 'pendente',
            data_convite TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            data_aceite TIMESTAMP NULL,
            convidado_por INT(11),
            PRIMARY KEY (id),
            FOREIGN KEY (conta_id) REFERENCES contas(id) ON DELETE CASCADE,
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
            FOREIGN KEY (convidado_por) REFERENCES usuarios(id) ON DELETE SET NULL,
            INDEX idx_conta_id (conta_id),
            INDEX idx_usuario_id (usuario_id),
            INDEX idx_papel (papel),
            INDEX idx_status (status),
            UNIQUE KEY unique_conta_usuario (conta_id, usuario_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ";
    
    $pdo->exec($sql_conta_membros);
    echo "✅ Tabela 'conta_membros' criada com sucesso!<br>";
    
    // 3. Tabela 'conta_permissoes' - Permissões granulares
    echo "<h2>3. Criando tabela 'conta_permissoes'...</h2>";
    $sql_conta_permissoes = "
        CREATE TABLE IF NOT EXISTS conta_permissoes (
            id INT(11) NOT NULL AUTO_INCREMENT,
            conta_id INT(11) NOT NULL,
            usuario_id INT(11) NOT NULL,
            modulo ENUM('financeiro', 'produtividade', 'academy', 'sistema') NOT NULL,
            permissao ENUM('visualizar', 'editar', 'excluir', 'gerenciar') NOT NULL,
            valor BOOLEAN DEFAULT FALSE,
            data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            FOREIGN KEY (conta_id) REFERENCES contas(id) ON DELETE CASCADE,
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
            INDEX idx_conta_usuario (conta_id, usuario_id),
            INDEX idx_modulo (modulo),
            INDEX idx_permissao (permissao),
            UNIQUE KEY unique_conta_usuario_modulo_permissao (conta_id, usuario_id, modulo, permissao)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ";
    
    $pdo->exec($sql_conta_permissoes);
    echo "✅ Tabela 'conta_permissoes' criada com sucesso!<br>";
    
    // 4. Tabela 'conta_convites' - Convites para contas
    echo "<h2>4. Criando tabela 'conta_convites'...</h2>";
    $sql_conta_convites = "
        CREATE TABLE IF NOT EXISTS conta_convites (
            id INT(11) NOT NULL AUTO_INCREMENT,
            conta_id INT(11) NOT NULL,
            email VARCHAR(255) NOT NULL,
            codigo_convite VARCHAR(50) NOT NULL UNIQUE,
            papel ENUM('administrador', 'membro', 'visualizador') DEFAULT 'membro',
            status ENUM('pendente', 'aceito', 'recusado', 'expirado') DEFAULT 'pendente',
            data_convite TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            data_expiracao TIMESTAMP NOT NULL,
            convidado_por INT(11) NOT NULL,
            PRIMARY KEY (id),
            FOREIGN KEY (conta_id) REFERENCES contas(id) ON DELETE CASCADE,
            FOREIGN KEY (convidado_por) REFERENCES usuarios(id) ON DELETE CASCADE,
            INDEX idx_conta_id (conta_id),
            INDEX idx_email (email),
            INDEX idx_codigo_convite (codigo_convite),
            INDEX idx_status (status),
            INDEX idx_data_expiracao (data_expiracao)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ";
    
    $pdo->exec($sql_conta_convites);
    echo "✅ Tabela 'conta_convites' criada com sucesso!<br>";
    
    // 5. Tabela 'conta_logs' - Logs de auditoria
    echo "<h2>5. Criando tabela 'conta_logs'...</h2>";
    $sql_conta_logs = "
        CREATE TABLE IF NOT EXISTS conta_logs (
            id INT(11) NOT NULL AUTO_INCREMENT,
            conta_id INT(11) NOT NULL,
            usuario_id INT(11) NOT NULL,
            acao VARCHAR(100) NOT NULL,
            modulo VARCHAR(50) NOT NULL,
            descricao TEXT,
            dados_anteriores JSON,
            dados_novos JSON,
            ip_address VARCHAR(45),
            user_agent TEXT,
            data_acao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            FOREIGN KEY (conta_id) REFERENCES contas(id) ON DELETE CASCADE,
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
            INDEX idx_conta_id (conta_id),
            INDEX idx_usuario_id (usuario_id),
            INDEX idx_acao (acao),
            INDEX idx_modulo (modulo),
            INDEX idx_data_acao (data_acao)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ";
    
    $pdo->exec($sql_conta_logs);
    echo "✅ Tabela 'conta_logs' criada com sucesso!<br>";
    
    // 6. Tabela 'usuarios' - Verificar se existe e criar se necessário
    echo "<h2>6. Verificando tabela 'usuarios'...</h2>";
    $check_usuarios = $pdo->query("SHOW TABLES LIKE 'usuarios'");
    if ($check_usuarios->rowCount() == 0) {
        echo "⚠️ Tabela 'usuarios' não existe, criando...<br>";
        $sql_usuarios = "
            CREATE TABLE IF NOT EXISTS usuarios (
                id INT(11) NOT NULL AUTO_INCREMENT,
                usuario VARCHAR(50) NOT NULL UNIQUE,
                senha_hash VARCHAR(255) NOT NULL,
                nome_completo VARCHAR(100),
                email VARCHAR(100) UNIQUE,
                tipo ENUM('usuario', 'admin') DEFAULT 'usuario',
                role VARCHAR(50) DEFAULT 'usuario',
                data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                telefone VARCHAR(20),
                notificacao_whatsapp_vista TINYINT(1) DEFAULT 0,
                telefone_e164 VARCHAR(20),
                notificacao_vista TINYINT(1) DEFAULT 0,
                telefone_atualizado_em DATETIME,
                permission INT(11) DEFAULT 0,
                PRIMARY KEY (id),
                INDEX idx_usuario (usuario),
                INDEX idx_email (email),
                INDEX idx_tipo (tipo),
                INDEX idx_role (role)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ";
        
        $pdo->exec($sql_usuarios);
        echo "✅ Tabela 'usuarios' criada com sucesso!<br>";
    } else {
        echo "✅ Tabela 'usuarios' já existe!<br>";
    }
    
    // 7. Inserir dados de exemplo
    echo "<h2>7. Inserindo dados de exemplo...</h2>";
    
    // Verificar se já existe usuário admin
    $check_admin = $pdo->query("SELECT COUNT(*) as total FROM usuarios WHERE tipo = 'admin'");
    $admin_count = $check_admin->fetch(PDO::FETCH_ASSOC)['total'];
    
    if ($admin_count == 0) {
        echo "⚠️ Nenhum usuário admin encontrado, criando usuário admin padrão...<br>";
        
        $admin_password = password_hash('admin123', PASSWORD_DEFAULT);
        $sql_admin = "
            INSERT INTO usuarios (usuario, senha_hash, nome_completo, email, tipo, role) 
            VALUES ('admin', ?, 'Administrador do Sistema', 'admin@sistema.com', 'admin', 'admin')
        ";
        
        $stmt_admin = $pdo->prepare($sql_admin);
        $stmt_admin->execute([$admin_password]);
        echo "✅ Usuário admin criado com sucesso!<br>";
        echo "📋 <strong>Credenciais do admin:</strong><br>";
        echo "👤 <strong>Usuário:</strong> admin<br>";
        echo "🔑 <strong>Senha:</strong> admin123<br>";
    } else {
        echo "✅ Usuário admin já existe!<br>";
    }
    
    // 8. Criar conta padrão para o usuário admin
    echo "<h2>8. Criando conta padrão...</h2>";
    
    $admin_id = $pdo->query("SELECT id FROM usuarios WHERE tipo = 'admin' LIMIT 1")->fetch(PDO::FETCH_ASSOC)['id'];
    
    // Verificar se já existe conta padrão
    $check_conta = $pdo->query("SELECT COUNT(*) as total FROM contas WHERE criado_por = $admin_id");
    $conta_count = $check_conta->fetch(PDO::FETCH_ASSOC)['total'];
    
    if ($conta_count == 0) {
        echo "⚠️ Nenhuma conta encontrada, criando conta padrão...<br>";
        
        $sql_conta_padrao = "
            INSERT INTO contas (nome, descricao, codigo_conta, tipo, status, criado_por) 
            VALUES ('Conta Principal', 'Conta principal do sistema', 'CONTA-001', 'pessoal', 'ativa', ?)
        ";
        
        $stmt_conta = $pdo->prepare($sql_conta_padrao);
        $stmt_conta->execute([$admin_id]);
        $conta_id = $pdo->lastInsertId();
        
        // Adicionar admin como proprietário da conta
        $sql_membro = "
            INSERT INTO conta_membros (conta_id, usuario_id, papel, status, data_aceite) 
            VALUES (?, ?, 'proprietario', 'ativo', NOW())
        ";
        
        $stmt_membro = $pdo->prepare($sql_membro);
        $stmt_membro->execute([$conta_id, $admin_id]);
        
        echo "✅ Conta padrão criada com sucesso!<br>";
    } else {
        echo "✅ Conta padrão já existe!<br>";
    }
    
    // 9. Verificar estrutura das tabelas
    echo "<h2>9. Verificando estrutura das tabelas...</h2>";
    
    $tabelas = ['contas', 'conta_membros', 'conta_permissoes', 'conta_convites', 'conta_logs', 'usuarios'];
    
    foreach ($tabelas as $tabela) {
        $check_table = $pdo->query("SHOW TABLES LIKE '$tabela'");
        if ($check_table->rowCount() > 0) {
            $count = $pdo->query("SELECT COUNT(*) as total FROM $tabela")->fetch(PDO::FETCH_ASSOC)['total'];
            echo "✅ Tabela '$tabela' existe com $count registros<br>";
        } else {
            echo "❌ Tabela '$tabela' não existe<br>";
        }
    }
    
    // 10. Resumo final
    echo "<h2>10. Resumo Final</h2>";
    echo "<div style='background: #d4edda; padding: 15px; border: 1px solid #c3e6cb; border-radius: 5px; margin: 10px 0;'>";
    echo "<h3>✅ SISTEMA DE GESTÃO DE CONTAS CRIADO COM SUCESSO!</h3>";
    echo "<p><strong>Tabelas criadas:</strong></p>";
    echo "<ul>";
    echo "<li>✅ <strong>contas</strong> - Contas principais</li>";
    echo "<li>✅ <strong>conta_membros</strong> - Membros das contas</li>";
    echo "<li>✅ <strong>conta_permissoes</strong> - Permissões granulares</li>";
    echo "<li>✅ <strong>conta_convites</strong> - Convites para contas</li>";
    echo "<li>✅ <strong>conta_logs</strong> - Logs de auditoria</li>";
    echo "<li>✅ <strong>usuarios</strong> - Usuários do sistema</li>";
    echo "</ul>";
    
    echo "<p><strong>Funcionalidades disponíveis:</strong></p>";
    echo "<ul>";
    echo "<li>🏢 <strong>Gestão de Contas</strong> - Criar e gerenciar contas</li>";
    echo "<li>👥 <strong>Gestão de Membros</strong> - Adicionar e remover membros</li>";
    echo "<li>🔐 <strong>Permissões Granulares</strong> - Controlar acesso por módulo</li>";
    echo "<li>📧 <strong>Sistema de Convites</strong> - Convidar usuários por email</li>";
    echo "<li>📊 <strong>Logs de Auditoria</strong> - Registrar todas as ações</li>";
    echo "<li>👤 <strong>Gestão de Usuários</strong> - Criar e gerenciar usuários</li>";
    echo "</ul>";
    
    echo "<p><strong>Próximos passos:</strong></p>";
    echo "<ol>";
    echo "<li>🔗 Acesse <strong>gestao_contas_unificada.php</strong> para gerenciar contas</li>";
    echo "<li>👤 Faça login com as credenciais do admin</li>";
    echo "<li>🏢 Crie suas contas e convide membros</li>";
    echo "<li>🔐 Configure permissões granulares</li>";
    echo "<li>📊 Monitore logs de auditoria</li>";
    echo "</ol>";
    echo "</div>";
    
    echo "<p><strong>🎉 Sistema de gestão de contas está pronto para uso!</strong></p>";
    
} catch (PDOException $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border: 1px solid #f5c6cb; border-radius: 5px; margin: 10px 0;'>";
    echo "<h3>❌ ERRO AO CRIAR TABELAS</h3>";
    echo "<p><strong>Erro:</strong> " . $e->getMessage() . "</p>";
    echo "<p><strong>Arquivo:</strong> " . $e->getFile() . "</p>";
    echo "<p><strong>Linha:</strong> " . $e->getLine() . "</p>";
    echo "</div>";
    
    echo "<h3>🔧 SOLUÇÕES POSSÍVEIS:</h3>";
    echo "<ul>";
    echo "<li>✅ Verificar se o banco de dados existe</li>";
    echo "<li>✅ Verificar se o usuário tem permissões para criar tabelas</li>";
    echo "<li>✅ Verificar se o arquivo includes/db_connect.php está correto</li>";
    echo "<li>✅ Verificar se o MySQL/MariaDB está funcionando</li>";
    echo "</ul>";
}

echo "<hr>";
echo "<p><strong>📅 Data/Hora:</strong> " . date('d/m/Y H:i:s') . "</p>";
echo "<p><strong>🔧 Script:</strong> criar_tabelas_gestao_completa.php</p>";
echo "<p><strong>📋 Versão:</strong> 1.0</p>";
?>

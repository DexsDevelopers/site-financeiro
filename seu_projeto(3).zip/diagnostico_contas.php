<?php
// diagnostico_contas.php - Diagnosticar problema das contas não aparecendo

session_start();
require_once 'includes/db_connect.php';

echo "<h2>🔍 DIAGNÓSTICO DAS CONTAS</h2>";

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    echo "❌ Usuário não está logado. Faça login primeiro.<br>";
    echo "<a href='login.php' class='btn btn-primary'>Fazer Login</a><br><br>";
    exit();
}

$userId = $_SESSION['user_id'];
echo "✅ Usuário logado: ID $userId<br><br>";

// 1. Verificar estrutura da tabela contas
echo "<h3>1. Verificando Estrutura da Tabela 'contas'</h3>";

try {
    $stmt = $pdo->query("DESCRIBE contas");
    $colunas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "✅ Tabela 'contas' existe<br>";
    echo "📋 Colunas da tabela:<br>";
    foreach ($colunas as $coluna) {
        echo "&nbsp;&nbsp;- {$coluna['Field']} ({$coluna['Type']})<br>";
    }
    
} catch (PDOException $e) {
    echo "❌ Erro ao verificar tabela contas: " . $e->getMessage() . "<br>";
}

echo "<hr>";

// 2. Verificar estrutura da tabela conta_membros
echo "<h3>2. Verificando Estrutura da Tabela 'conta_membros'</h3>";

try {
    $stmt = $pdo->query("DESCRIBE conta_membros");
    $colunas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "✅ Tabela 'conta_membros' existe<br>";
    echo "📋 Colunas da tabela:<br>";
    foreach ($colunas as $coluna) {
        echo "&nbsp;&nbsp;- {$coluna['Field']} ({$coluna['Type']})<br>";
    }
    
} catch (PDOException $e) {
    echo "❌ Erro ao verificar tabela conta_membros: " . $e->getMessage() . "<br>";
}

echo "<hr>";

// 3. Verificar todas as contas no banco
echo "<h3>3. Verificando Todas as Contas no Banco</h3>";

try {
    $stmt = $pdo->query("SELECT * FROM contas ORDER BY data_criacao DESC");
    $todasContas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "📊 Total de contas no banco: " . count($todasContas) . "<br>";
    
    if (!empty($todasContas)) {
        echo "📋 Contas encontradas:<br>";
        foreach ($todasContas as $conta) {
            echo "&nbsp;&nbsp;- ID: {$conta['id']}, Nome: {$conta['nome']}, Criado por: {$conta['criado_por']}, Data: {$conta['data_criacao']}<br>";
        }
    } else {
        echo "⚠️ Nenhuma conta encontrada no banco<br>";
    }
    
} catch (PDOException $e) {
    echo "❌ Erro ao buscar contas: " . $e->getMessage() . "<br>";
}

echo "<hr>";

// 4. Verificar membros das contas
echo "<h3>4. Verificando Membros das Contas</h3>";

try {
    $stmt = $pdo->query("SELECT * FROM conta_membros ORDER BY conta_id, usuario_id");
    $todosMembros = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "📊 Total de membros no banco: " . count($todosMembros) . "<br>";
    
    if (!empty($todosMembros)) {
        echo "📋 Membros encontrados:<br>";
        foreach ($todosMembros as $membro) {
            echo "&nbsp;&nbsp;- Conta ID: {$membro['conta_id']}, Usuário ID: {$membro['usuario_id']}, Papel: {$membro['papel']}, Status: {$membro['status']}<br>";
        }
    } else {
        echo "⚠️ Nenhum membro encontrado no banco<br>";
    }
    
} catch (PDOException $e) {
    echo "❌ Erro ao buscar membros: " . $e->getMessage() . "<br>";
}

echo "<hr>";

// 5. Testar consulta específica do usuário
echo "<h3>5. Testando Consulta Específica do Usuário</h3>";

try {
    $stmt = $pdo->prepare("
        SELECT 
            c.*,
            cm.papel,
            cm.status as status_membro,
            u.nome as nome_proprietario
        FROM contas c
        JOIN conta_membros cm ON c.id = cm.conta_id
        LEFT JOIN usuarios u ON c.criado_por = u.id
        WHERE cm.usuario_id = ? AND cm.status = 'ativo'
        ORDER BY c.data_criacao DESC
    ");
    $stmt->execute([$userId]);
    $contasUsuario = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "📊 Contas do usuário encontradas: " . count($contasUsuario) . "<br>";
    
    if (!empty($contasUsuario)) {
        echo "📋 Contas do usuário:<br>";
        foreach ($contasUsuario as $conta) {
            echo "&nbsp;&nbsp;- ID: {$conta['id']}, Nome: {$conta['nome']}, Papel: {$conta['papel']}, Status: {$conta['status_membro']}<br>";
        }
    } else {
        echo "⚠️ Nenhuma conta encontrada para o usuário<br>";
        
        // Verificar se o usuário tem membros em alguma conta
        $stmt = $pdo->prepare("SELECT * FROM conta_membros WHERE usuario_id = ?");
        $stmt->execute([$userId]);
        $membrosUsuario = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "🔍 Membros do usuário em contas: " . count($membrosUsuario) . "<br>";
        if (!empty($membrosUsuario)) {
            foreach ($membrosUsuario as $membro) {
                echo "&nbsp;&nbsp;- Conta ID: {$membro['conta_id']}, Papel: {$membro['papel']}, Status: {$membro['status']}<br>";
            }
        }
    }
    
} catch (PDOException $e) {
    echo "❌ Erro na consulta específica: " . $e->getMessage() . "<br>";
}

echo "<hr>";

// 6. Criar conta de teste se necessário
echo "<h3>6. Criando Conta de Teste</h3>";

if (empty($contasUsuario)) {
    try {
        $nome = 'Conta Teste ' . date('Y-m-d H:i:s');
        $descricao = 'Conta criada para teste de diagnóstico';
        $tipo = 'Pessoal';
        $codigoConta = 'TESTE_' . $userId . '_' . time();
        
        // Criar conta
        $stmt = $pdo->prepare("
            INSERT INTO contas (nome, descricao, codigo_conta, tipo, criado_por) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([$nome, $descricao, $codigoConta, $tipo, $userId]);
        
        $contaId = $pdo->lastInsertId();
        
        if ($contaId) {
            echo "✅ Conta de teste criada - ID: $contaId<br>";
            
            // Adicionar usuário como proprietário
            $stmt = $pdo->prepare("
                INSERT INTO conta_membros (conta_id, usuario_id, papel, status) 
                VALUES (?, ?, 'proprietario', 'ativo')
            ");
            $stmt->execute([$contaId, $userId]);
            
            echo "✅ Usuário adicionado como proprietário<br>";
            
            // Testar consulta novamente
            $stmt = $pdo->prepare("
                SELECT 
                    c.*,
                    cm.papel,
                    cm.status as status_membro,
                    u.nome as nome_proprietario
                FROM contas c
                JOIN conta_membros cm ON c.id = cm.conta_id
                LEFT JOIN usuarios u ON c.criado_por = u.id
                WHERE cm.usuario_id = ? AND cm.status = 'ativo'
                ORDER BY c.data_criacao DESC
            ");
            $stmt->execute([$userId]);
            $contasUsuario = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo "📊 Contas após criação: " . count($contasUsuario) . "<br>";
            
        } else {
            echo "❌ Falha ao criar conta de teste<br>";
        }
        
    } catch (PDOException $e) {
        echo "❌ Erro ao criar conta de teste: " . $e->getMessage() . "<br>";
    }
} else {
    echo "✅ Usuário já possui contas, não é necessário criar conta de teste<br>";
}

echo "<hr>";

// 7. Resumo final
echo "<h2>📊 RESUMO DO DIAGNÓSTICO</h2>";

$totalContas = count($contasUsuario);

if ($totalContas > 0) {
    echo "<div style='background: #d4edda; padding: 1rem; border-radius: 8px; margin: 1rem 0;'>";
    echo "<h4>✅ CONTAS ENCONTRADAS!</h4>";
    echo "<p>O usuário possui $totalContas conta(s). O problema pode estar na exibição da página.</p>";
    echo "<p><strong>Próximos passos:</strong></p>";
    echo "<ol>";
    echo "<li>Verifique se a página está recarregando após criar conta</li>";
    echo "<li>Verifique se há erros JavaScript no console</li>";
    echo "<li>Teste acessar a página diretamente</li>";
    echo "</ol>";
    echo "</div>";
} else {
    echo "<div style='background: #f8d7da; padding: 1rem; border-radius: 8px; margin: 1rem 0;'>";
    echo "<h4>❌ NENHUMA CONTA ENCONTRADA</h4>";
    echo "<p>O usuário não possui contas. O problema pode estar na criação ou na consulta.</p>";
    echo "<p><strong>Possíveis causas:</strong></p>";
    echo "<ul>";
    echo "<li>Contas não estão sendo criadas corretamente</li>";
    echo "<li>Usuário não está sendo adicionado como membro</li>";
    echo "<li>Consulta não está funcionando</li>";
    echo "</ul>";
    echo "</div>";
}

echo "<hr>";
echo "<p><strong>✅ Diagnóstico concluído!</strong> Use as informações acima para identificar o problema.</p>";
?>

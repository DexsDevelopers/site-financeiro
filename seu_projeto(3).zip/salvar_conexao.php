<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    http_response_code(403); // Proibido
    exit('Usuário não autenticado.');
}

require_once 'includes/db_connect.php';
// TO-DO: Incluir seu config.php com as chaves da API

// Pega o JSON enviado pelo JavaScript
$input = json_decode(file_get_contents('php://input'), true);
$itemId = $input['itemId'] ?? null;

if (!$itemId) {
    http_response_code(400); // Requisição inválida
    exit('itemId não fornecido.');
}

// TO-DO: Usar a API da Pluggy para buscar os detalhes da conexão (nome do banco, tipo de conta) usando o itemId
// Por enquanto, salvaremos apenas o ID.
$id_usuario = $_SESSION['user_id'];
$instituicao_nome = 'Banco Exemplo'; // Substituir com dados reais da API

try {
    $stmt = $pdo->prepare(
        "INSERT INTO contas (id_usuario, agregador_item_id, instituicao_nome) VALUES (?, ?, ?)"
    );
    $stmt->execute([$id_usuario, $itemId, $instituicao_nome]);
    
    http_response_code(200);
    echo json_encode(['status' => 'sucesso', 'message' => 'Conta salva.']);

} catch (PDOException $e) {
    http_response_code(500);
    // Em produção, logar o erro em vez de exibi-lo
    echo json_encode(['status' => 'erro', 'message' => $e->getMessage()]);
}
?>
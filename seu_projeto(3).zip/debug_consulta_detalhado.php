<?php
// debug_consulta_detalhado.php - Debug detalhado da consulta

// Ativar exibição de erros
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Verificar se a sessão já foi iniciada
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once 'includes/db_connect.php';

echo "<h2>🔍 DEBUG DETALHADO DA CONSULTA</h2>";

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    echo "❌ Usuário não está logado. Faça login primeiro.<br>";
    exit();
}

$userId = $_SESSION['user_id'];
echo "✅ Usuário logado: ID $userId<br><br>";

// 1. Verificar estrutura das tabelas
echo "<h3>1. ESTRUTURA DAS TABELAS</h3>";

// Verificar tabela contas
try {
    $stmt = $pdo->query("DESCRIBE contas");
    $colunasContas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "📋 Colunas da tabela 'contas':<br>";
    foreach ($colunasContas as $coluna) {
        echo "- {$coluna['Field']} ({$coluna['Type']})<br>";
    }
} catch (PDOException $e) {
    echo "❌ Erro ao verificar tabela contas: " . $e->getMessage() . "<br>";
}

echo "<br>";

// Verificar tabela conta_membros
try {
    $stmt = $pdo->query("DESCRIBE conta_membros");
    $colunasMembros = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "📋 Colunas da tabela 'conta_membros':<br>";
    foreach ($colunasMembros as $coluna) {
        echo "- {$coluna['Field']} ({$coluna['Type']})<br>";
    }
} catch (PDOException $e) {
    echo "❌ Erro ao verificar tabela conta_membros: " . $e->getMessage() . "<br>";
}

echo "<hr>";

// 2. Verificar dados específicos
echo "<h3>2. DADOS ESPECÍFICOS</h3>";

// Verificar contas do usuário
try {
    $stmt = $pdo->prepare("
        SELECT 
            c.id,
            c.nome,
            c.tipo,
            c.data_criacao,
            cm.papel,
            cm.status as status_membro
        FROM contas c
        JOIN conta_membros cm ON c.id = cm.conta_id
        WHERE cm.usuario_id = ?
        ORDER BY c.data_criacao DESC
        LIMIT 5
    ");
    $stmt->execute([$userId]);
    $contasUsuario = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "📊 Contas do usuário (sem filtro de status): " . count($contasUsuario) . "<br>";
    
    if (!empty($contasUsuario)) {
        echo "📋 Últimas 5 contas:<br>";
        foreach ($contasUsuario as $conta) {
            echo "- ID: {$conta['id']}, Nome: {$conta['nome']}, Papel: {$conta['papel']}, Status: {$conta['status_membro']}<br>";
        }
    }
} catch (PDOException $e) {
    echo "❌ Erro ao buscar contas: " . $e->getMessage() . "<br>";
}

echo "<br>";

// Verificar contas ativas
try {
    $stmt = $pdo->prepare("
        SELECT 
            c.id,
            c.nome,
            c.tipo,
            c.data_criacao,
            cm.papel,
            cm.status as status_membro
        FROM contas c
        JOIN conta_membros cm ON c.id = cm.conta_id
        WHERE cm.usuario_id = ? AND cm.status = 'ativo'
        ORDER BY c.data_criacao DESC
        LIMIT 5
    ");
    $stmt->execute([$userId]);
    $contasAtivas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "📊 Contas ativas do usuário: " . count($contasAtivas) . "<br>";
    
    if (!empty($contasAtivas)) {
        echo "📋 Últimas 5 contas ativas:<br>";
        foreach ($contasAtivas as $conta) {
            echo "- ID: {$conta['id']}, Nome: {$conta['nome']}, Papel: {$conta['papel']}, Status: {$conta['status_membro']}<br>";
        }
    } else {
        echo "⚠️ Nenhuma conta ativa encontrada<br>";
        
        // Verificar status dos membros
        $stmt = $pdo->prepare("
            SELECT status, COUNT(*) as total 
            FROM conta_membros 
            WHERE usuario_id = ? 
            GROUP BY status
        ");
        $stmt->execute([$userId]);
        $statusMembros = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "📊 Status dos membros:<br>";
        foreach ($statusMembros as $status) {
            echo "- Status '{$status['status']}': {$status['total']} membros<br>";
        }
    }
} catch (PDOException $e) {
    echo "❌ Erro ao buscar contas ativas: " . $e->getMessage() . "<br>";
}

echo "<hr>";

// 3. Testar consulta exata da página
echo "<h3>3. CONSULTA EXATA DA PÁGINA</h3>";

try {
    $stmt = $pdo->prepare("
        SELECT 
            c.*,
            cm.papel,
            cm.status as status_membro
        FROM contas c
        JOIN conta_membros cm ON c.id = cm.conta_id
        WHERE cm.usuario_id = ? AND cm.status = 'ativo'
        ORDER BY c.data_criacao DESC
    ");
    $stmt->execute([$userId]);
    $contasExatas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "✅ Consulta exata executada<br>";
    echo "📊 Contas encontradas: " . count($contasExatas) . "<br>";
    
    if (!empty($contasExatas)) {
        echo "📋 Contas encontradas:<br>";
        foreach ($contasExatas as $conta) {
            echo "- ID: {$conta['id']}, Nome: {$conta['nome']}, Papel: {$conta['papel']}, Status: {$conta['status_membro']}<br>";
        }
    } else {
        echo "❌ PROBLEMA IDENTIFICADO: Consulta não retorna contas<br>";
        
        // Debug adicional
        echo "<h4>🔍 DEBUG ADICIONAL:</h4>";
        
        // Verificar se há contas no banco
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM contas");
        $totalContas = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
        echo "📊 Total de contas no banco: $totalContas<br>";
        
        // Verificar se há membros do usuário
        $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM conta_membros WHERE usuario_id = ?");
        $stmt->execute([$userId]);
        $totalMembros = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
        echo "📊 Total de membros do usuário: $totalMembros<br>";
        
        // Verificar se há membros ativos
        $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM conta_membros WHERE usuario_id = ? AND status = 'ativo'");
        $stmt->execute([$userId]);
        $membrosAtivos = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
        echo "📊 Membros ativos do usuário: $membrosAtivos<br>";
        
        // Verificar se há contas com membros ativos
        $stmt = $pdo->prepare("
            SELECT COUNT(DISTINCT c.id) as total 
            FROM contas c
            JOIN conta_membros cm ON c.id = cm.conta_id
            WHERE cm.usuario_id = ? AND cm.status = 'ativo'
        ");
        $stmt->execute([$userId]);
        $contasComMembrosAtivos = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
        echo "📊 Contas com membros ativos: $contasComMembrosAtivos<br>";
    }
} catch (PDOException $e) {
    echo "❌ Erro na consulta exata: " . $e->getMessage() . "<br>";
}

echo "<hr>";

// 4. Testar consulta alternativa
echo "<h3>4. CONSULTA ALTERNATIVA</h3>";

try {
    // Consulta alternativa usando subquery
    $stmt = $pdo->prepare("
        SELECT 
            c.*,
            cm.papel,
            cm.status as status_membro
        FROM contas c
        INNER JOIN conta_membros cm ON c.id = cm.conta_id
        WHERE cm.usuario_id = ? 
        AND cm.status = 'ativo'
        ORDER BY c.data_criacao DESC
    ");
    $stmt->execute([$userId]);
    $contasAlternativa = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "✅ Consulta alternativa executada<br>";
    echo "📊 Contas encontradas: " . count($contasAlternativa) . "<br>";
    
    if (!empty($contasAlternativa)) {
        echo "📋 Contas encontradas:<br>";
        foreach ($contasAlternativa as $conta) {
            echo "- ID: {$conta['id']}, Nome: {$conta['nome']}, Papel: {$conta['papel']}, Status: {$conta['status_membro']}<br>";
        }
    }
} catch (PDOException $e) {
    echo "❌ Erro na consulta alternativa: " . $e->getMessage() . "<br>";
}

echo "<hr>";
echo "<p><strong>✅ Debug detalhado concluído!</strong></p>";
echo "<p><a href='gestao_contas_unificada.php'>Voltar para a página unificada</a></p>";
?>

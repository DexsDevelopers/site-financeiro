<?php
// buscar_membros_conta.php - Buscar membros de uma conta

session_start();
require_once 'includes/db_connect.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Acesso negado']);
    exit();
}

$userId = $_SESSION['user_id'];
$contaId = (int)($_GET['conta_id'] ?? 0);

if ($contaId <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'ID da conta inválido']);
    exit();
}

try {
    // Verificar se o usuário tem permissão para ver membros
    $stmt = $pdo->prepare("
        SELECT cm.papel 
        FROM conta_membros cm 
        WHERE cm.conta_id = ? AND cm.usuario_id = ? AND cm.status = 'ativo'
    ");
    $stmt->execute([$contaId, $userId]);
    $membro = $stmt->fetch();
    
    if (!$membro || !in_array($membro['papel'], ['proprietario', 'administrador'])) {
        echo json_encode(['success' => false, 'message' => 'Você não tem permissão para ver membros desta conta']);
        exit();
    }
    
    // Buscar membros da conta
    $stmt = $pdo->prepare("
        SELECT 
            cm.*,
            u.nome,
            u.email,
            u.data_criacao as data_cadastro
        FROM conta_membros cm
        JOIN usuarios u ON cm.usuario_id = u.id
        WHERE cm.conta_id = ?
        ORDER BY cm.papel, u.nome
    ");
    $stmt->execute([$contaId]);
    $membros = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Gerar HTML dos membros
    $html = '<div class="row">';
    
    foreach ($membros as $membro) {
        $badgeClass = '';
        switch ($membro['papel']) {
            case 'proprietario':
                $badgeClass = 'bg-danger';
                break;
            case 'administrador':
                $badgeClass = 'bg-warning';
                break;
            case 'membro':
                $badgeClass = 'bg-primary';
                break;
            case 'visualizador':
                $badgeClass = 'bg-secondary';
                break;
        }
        
        $html .= '<div class="col-md-6 mb-3">';
        $html .= '<div class="card" style="background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1);">';
        $html .= '<div class="card-body">';
        $html .= '<div class="d-flex justify-content-between align-items-start mb-2">';
        $html .= '<div>';
        $html .= '<h6 class="card-title mb-1">' . htmlspecialchars($membro['nome']) . '</h6>';
        $html .= '<small class="text-muted">' . htmlspecialchars($membro['email']) . '</small>';
        $html .= '</div>';
        $html .= '<span class="badge ' . $badgeClass . '">' . ucfirst($membro['papel']) . '</span>';
        $html .= '</div>';
        $html .= '<div class="row text-center">';
        $html .= '<div class="col-6">';
        $html .= '<small class="text-muted">Status</small><br>';
        $html .= '<span class="badge bg-' . ($membro['status'] === 'ativo' ? 'success' : 'secondary') . '">' . ucfirst($membro['status']) . '</span>';
        $html .= '</div>';
        $html .= '<div class="col-6">';
        $html .= '<small class="text-muted">Membro desde</small><br>';
        $html .= '<small>' . date('d/m/Y', strtotime($membro['data_aceite'])) . '</small>';
        $html .= '</div>';
        $html .= '</div>';
        
        // Botões de ação (apenas para não proprietários)
        if ($membro['papel'] !== 'proprietario') {
            $html .= '<div class="mt-3 d-flex gap-2">';
            $html .= '<button class="btn btn-outline-warning btn-sm" onclick="editarPermissoes(' . $membro['usuario_id'] . ', \'' . htmlspecialchars($membro['nome']) . '\')">';
            $html .= '<i class="bi bi-shield-lock me-1"></i>Permissões';
            $html .= '</button>';
            $html .= '<button class="btn btn-outline-danger btn-sm" onclick="removerMembro(' . $membro['usuario_id'] . ', \'' . htmlspecialchars($membro['nome']) . '\')">';
            $html .= '<i class="bi bi-person-x me-1"></i>Remover';
            $html .= '</button>';
            $html .= '</div>';
        }
        
        $html .= '</div>';
        $html .= '</div>';
        $html .= '</div>';
    }
    
    $html .= '</div>';
    
    echo json_encode([
        'success' => true,
        'html' => $html,
        'total' => count($membros)
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao buscar membros: ' . $e->getMessage()
    ]);
}
?>

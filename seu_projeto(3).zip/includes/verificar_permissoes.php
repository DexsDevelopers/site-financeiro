<?php
// includes/verificar_permissoes.php - Sistema de verificação de permissões granulares

require_once 'db_connect.php';

class SistemaPermissoes {
    private $pdo;
    private $userId;
    private $contaAtiva;
    
    public function __construct($pdo, $userId) {
        $this->pdo = $pdo;
        $this->userId = $userId;
        $this->contaAtiva = $this->obterContaAtiva();
    }
    
    /**
     * Obter conta ativa do usuário
     */
    private function obterContaAtiva() {
        if (isset($_SESSION['conta_ativa_id'])) {
            return $_SESSION['conta_ativa_id'];
        }
        
        // Buscar primeira conta ativa do usuário
        try {
            $stmt = $this->pdo->prepare("
                SELECT cm.conta_id 
                FROM conta_membros cm 
                WHERE cm.usuario_id = ? AND cm.status = 'ativo' 
                ORDER BY cm.data_aceite DESC 
                LIMIT 1
            ");
            $stmt->execute([$this->userId]);
            $result = $stmt->fetch();
            
            if ($result) {
                $_SESSION['conta_ativa_id'] = $result['conta_id'];
                return $result['conta_id'];
            }
        } catch (PDOException $e) {
            // Log do erro
        }
        
        return null;
    }
    
    /**
     * Verificar se o usuário tem permissão para um módulo e ação específicos
     */
    public function verificarPermissao($modulo, $permissao) {
        if (!$this->contaAtiva) {
            return false;
        }
        
        try {
            // Verificar permissão específica
            $stmt = $this->pdo->prepare("
                SELECT permitido 
                FROM conta_permissoes 
                WHERE conta_id = ? AND usuario_id = ? AND modulo = ? AND permissao = ?
            ");
            $stmt->execute([$this->contaAtiva, $this->userId, $modulo, $permissao]);
            $result = $stmt->fetch();
            
            if ($result) {
                return (bool)$result['permitido'];
            }
            
            // Se não há permissão específica, verificar papel do usuário
            return $this->verificarPermissaoPorPapel($modulo, $permissao);
            
        } catch (PDOException $e) {
            return false;
        }
    }
    
    /**
     * Verificar permissão baseada no papel do usuário
     */
    private function verificarPermissaoPorPapel($modulo, $permissao) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT cm.papel 
                FROM conta_membros cm 
                WHERE cm.conta_id = ? AND cm.usuario_id = ? AND cm.status = 'ativo'
            ");
            $stmt->execute([$this->contaAtiva, $this->userId]);
            $membro = $stmt->fetch();
            
            if (!$membro) {
                return false;
            }
            
            $papel = $membro['papel'];
            
            // Definir permissões por papel
            $permissoesPorPapel = [
                'proprietario' => [
                    'financeiro' => ['visualizar_saldo', 'editar_transacoes', 'excluir_transacoes', 'gerar_relatorios'],
                    'produtividade' => ['visualizar_tarefas', 'editar_tarefas', 'excluir_tarefas', 'gerar_relatorios'],
                    'sistema' => ['gerenciar_usuarios', 'gerenciar_permissoes', 'visualizar_logs']
                ],
                'administrador' => [
                    'financeiro' => ['visualizar_saldo', 'editar_transacoes', 'excluir_transacoes', 'gerar_relatorios'],
                    'produtividade' => ['visualizar_tarefas', 'editar_tarefas', 'excluir_tarefas', 'gerar_relatorios'],
                    'sistema' => ['gerenciar_usuarios', 'visualizar_logs']
                ],
                'membro' => [
                    'financeiro' => ['visualizar_saldo', 'editar_transacoes', 'gerar_relatorios'],
                    'produtividade' => ['visualizar_tarefas', 'editar_tarefas', 'gerar_relatorios'],
                    'sistema' => []
                ],
                'visualizador' => [
                    'financeiro' => ['visualizar_saldo', 'gerar_relatorios'],
                    'produtividade' => ['visualizar_tarefas', 'gerar_relatorios'],
                    'sistema' => []
                ]
            ];
            
            if (isset($permissoesPorPapel[$papel][$modulo])) {
                return in_array($permissao, $permissoesPorPapel[$papel][$modulo]);
            }
            
            return false;
            
        } catch (PDOException $e) {
            return false;
        }
    }
    
    /**
     * Verificar se o usuário pode ver o saldo
     */
    public function podeVerSaldo() {
        return $this->verificarPermissao('financeiro', 'visualizar_saldo');
    }
    
    /**
     * Verificar se o usuário pode editar transações
     */
    public function podeEditarTransacoes() {
        return $this->verificarPermissao('financeiro', 'editar_transacoes');
    }
    
    /**
     * Verificar se o usuário pode excluir transações
     */
    public function podeExcluirTransacoes() {
        return $this->verificarPermissao('financeiro', 'excluir_transacoes');
    }
    
    /**
     * Verificar se o usuário pode ver tarefas
     */
    public function podeVerTarefas() {
        return $this->verificarPermissao('produtividade', 'visualizar_tarefas');
    }
    
    /**
     * Verificar se o usuário pode editar tarefas
     */
    public function podeEditarTarefas() {
        return $this->verificarPermissao('produtividade', 'editar_tarefas');
    }
    
    /**
     * Verificar se o usuário pode excluir tarefas
     */
    public function podeExcluirTarefas() {
        return $this->verificarPermissao('produtividade', 'excluir_tarefas');
    }
    
    /**
     * Verificar se o usuário pode gerenciar usuários
     */
    public function podeGerenciarUsuarios() {
        return $this->verificarPermissao('sistema', 'gerenciar_usuarios');
    }
    
    /**
     * Verificar se o usuário pode gerenciar permissões
     */
    public function podeGerenciarPermissoes() {
        return $this->verificarPermissao('sistema', 'gerenciar_permissoes');
    }
    
    /**
     * Verificar se o usuário pode ver logs
     */
    public function podeVerLogs() {
        return $this->verificarPermissao('sistema', 'visualizar_logs');
    }
    
    /**
     * Obter todas as permissões do usuário
     */
    public function obterTodasPermissoes() {
        if (!$this->contaAtiva) {
            return [];
        }
        
        try {
            $stmt = $this->pdo->prepare("
                SELECT modulo, permissao, permitido 
                FROM conta_permissoes 
                WHERE conta_id = ? AND usuario_id = ?
            ");
            $stmt->execute([$this->contaAtiva, $this->userId]);
            $permissoes = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $resultado = [];
            foreach ($permissoes as $permissao) {
                $resultado[$permissao['modulo']][$permissao['permissao']] = (bool)$permissao['permitido'];
            }
            
            return $resultado;
            
        } catch (PDOException $e) {
            return [];
        }
    }
    
    /**
     * Registrar atividade do usuário
     */
    public function registrarAtividade($acao, $modulo, $detalhes = '') {
        if (!$this->contaAtiva) {
            return false;
        }
        
        try {
            $stmt = $this->pdo->prepare("
                INSERT INTO conta_logs (conta_id, usuario_id, acao, modulo, detalhes, ip_address, user_agent) 
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $this->contaAtiva,
                $this->userId,
                $acao,
                $modulo,
                $detalhes,
                $_SERVER['REMOTE_ADDR'] ?? '',
                $_SERVER['HTTP_USER_AGENT'] ?? ''
            ]);
            
            return true;
            
        } catch (PDOException $e) {
            return false;
        }
    }
    
    /**
     * Obter conta ativa
     */
    public function obterContaAtiva() {
        return $this->contaAtiva;
    }
    
    /**
     * Definir conta ativa
     */
    public function definirContaAtiva($contaId) {
        // Verificar se o usuário é membro da conta
        try {
            $stmt = $this->pdo->prepare("
                SELECT id 
                FROM conta_membros 
                WHERE conta_id = ? AND usuario_id = ? AND status = 'ativo'
            ");
            $stmt->execute([$contaId, $this->userId]);
            
            if ($stmt->fetch()) {
                $_SESSION['conta_ativa_id'] = $contaId;
                $this->contaAtiva = $contaId;
                return true;
            }
            
        } catch (PDOException $e) {
            // Log do erro
        }
        
        return false;
    }
}

// Função helper para verificar permissão rapidamente
function verificarPermissao($modulo, $permissao) {
    global $pdo, $userId;
    
    if (!isset($pdo) || !isset($userId)) {
        return false;
    }
    
    $sistemaPermissoes = new SistemaPermissoes($pdo, $userId);
    return $sistemaPermissoes->verificarPermissao($modulo, $permissao);
}

// Função helper para verificar se pode ver saldo
function podeVerSaldo() {
    return verificarPermissao('financeiro', 'visualizar_saldo');
}

// Função helper para verificar se pode editar transações
function podeEditarTransacoes() {
    return verificarPermissao('financeiro', 'editar_transacoes');
}

// Função helper para verificar se pode ver tarefas
function podeVerTarefas() {
    return verificarPermissao('produtividade', 'visualizar_tarefas');
}

// Função helper para verificar se pode editar tarefas
function podeEditarTarefas() {
    return verificarPermissao('produtividade', 'editar_tarefas');
}
?>

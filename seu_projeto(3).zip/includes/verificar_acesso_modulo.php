<?php
// includes/verificar_acesso_modulo.php - Verificar acesso a módulos específicos

require_once 'verificar_permissoes.php';

// Função para verificar se o usuário pode acessar um módulo
function verificarAcessoModulo($modulo) {
    global $pdo, $userId;
    
    if (!isset($pdo) || !isset($userId)) {
        return false;
    }
    
    $sistemaPermissoes = new SistemaPermissoes($pdo, $userId);
    
    switch ($modulo) {
        case 'financeiro':
            return $sistemaPermissoes->verificarPermissao('financeiro', 'visualizar_saldo') || 
                   $sistemaPermissoes->verificarPermissao('financeiro', 'editar_transacoes');
            
        case 'produtividade':
            return $sistemaPermissoes->verificarPermissao('produtividade', 'visualizar_tarefas');
            
        case 'academy':
            return $sistemaPermissoes->verificarPermissao('academy', 'visualizar_cursos');
            
        default:
            return false;
    }
}

// Função para verificar se pode ver saldo
function podeVerSaldoModulo() {
    global $pdo, $userId;
    
    if (!isset($pdo) || !isset($userId)) {
        return false;
    }
    
    $sistemaPermissoes = new SistemaPermissoes($pdo, $userId);
    return $sistemaPermissoes->verificarPermissao('financeiro', 'visualizar_saldo');
}

// Função para verificar se pode editar financeiro
function podeEditarFinanceiroModulo() {
    global $pdo, $userId;
    
    if (!isset($pdo) || !isset($userId)) {
        return false;
    }
    
    $sistemaPermissoes = new SistemaPermissoes($pdo, $userId);
    return $sistemaPermissoes->verificarPermissao('financeiro', 'editar_transacoes');
}

// Função para verificar se pode excluir financeiro
function podeExcluirFinanceiroModulo() {
    global $pdo, $userId;
    
    if (!isset($pdo) || !isset($userId)) {
        return false;
    }
    
    $sistemaPermissoes = new SistemaPermissoes($pdo, $userId);
    return $sistemaPermissoes->verificarPermissao('financeiro', 'excluir_transacoes');
}

// Função para verificar se pode acessar produtividade
function podeAcessarProdutividadeModulo() {
    global $pdo, $userId;
    
    if (!isset($pdo) || !isset($userId)) {
        return false;
    }
    
    $sistemaPermissoes = new SistemaPermissoes($pdo, $userId);
    return $sistemaPermissoes->verificarPermissao('produtividade', 'visualizar_tarefas');
}

// Função para verificar se pode acessar academy
function podeAcessarAcademyModulo() {
    global $pdo, $userId;
    
    if (!isset($pdo) || !isset($userId)) {
        return false;
    }
    
    $sistemaPermissoes = new SistemaPermissoes($pdo, $userId);
    return $sistemaPermissoes->verificarPermissao('academy', 'visualizar_cursos');
}

// Função para redirecionar se não tiver acesso
function verificarERedirecionar($modulo) {
    if (!verificarAcessoModulo($modulo)) {
        header('Location: gestao_contas.php?erro=acesso_negado');
        exit();
    }
}

// Função para ocultar elementos baseado em permissões
function aplicarPermissoesVisuais() {
    global $pdo, $userId;
    
    if (!isset($pdo) || !isset($userId)) {
        return;
    }
    
    $sistemaPermissoes = new SistemaPermissoes($pdo, $userId);
    
    // Adicionar classes CSS baseadas em permissões
    $classes = [];
    
    if (!$sistemaPermissoes->verificarPermissao('financeiro', 'visualizar_saldo')) {
        $classes[] = 'saldo-oculto';
    }
    
    if (!$sistemaPermissoes->verificarPermissao('financeiro', 'editar_transacoes')) {
        $classes[] = 'financeiro-somente-leitura';
    }
    
    if (!$sistemaPermissoes->verificarPermissao('produtividade', 'visualizar_tarefas')) {
        $classes[] = 'produtividade-oculta';
    }
    
    if (!$sistemaPermissoes->verificarPermissao('academy', 'visualizar_cursos')) {
        $classes[] = 'academy-oculta';
    }
    
    if (!empty($classes)) {
        echo '<script>document.body.classList.add("' . implode('", "', $classes) . '");</script>';
    }
}

// Função para obter permissões do usuário atual
function obterPermissoesUsuario() {
    global $pdo, $userId;
    
    if (!isset($pdo) || !isset($userId)) {
        return [];
    }
    
    $sistemaPermissoes = new SistemaPermissoes($pdo, $userId);
    return $sistemaPermissoes->obterTodasPermissoes();
}

// Função para verificar se o usuário está em uma conta
function estaEmConta() {
    global $pdo, $userId;
    
    if (!isset($pdo) || !isset($userId)) {
        return false;
    }
    
    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*) as total 
            FROM conta_membros 
            WHERE usuario_id = ? AND status = 'ativo'
        ");
        $stmt->execute([$userId]);
        $result = $stmt->fetch();
        
        return $result['total'] > 0;
    } catch (PDOException $e) {
        return false;
    }
}

// Função para obter informações da conta ativa
function obterContaAtiva() {
    global $pdo, $userId;
    
    if (!isset($pdo) || !isset($userId)) {
        return null;
    }
    
    if (isset($_SESSION['conta_ativa_id'])) {
        $contaId = $_SESSION['conta_ativa_id'];
        
        try {
            $stmt = $pdo->prepare("
                SELECT c.*, cm.papel 
                FROM contas c
                JOIN conta_membros cm ON c.id = cm.conta_id
                WHERE c.id = ? AND cm.usuario_id = ? AND cm.status = 'ativo'
            ");
            $stmt->execute([$contaId, $userId]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return null;
        }
    }
    
    return null;
}
?>

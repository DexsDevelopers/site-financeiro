<?php
/**
 * verificar_hostinger.php
 * Verificação de Compatibilidade com Hostinger
 * Painel Financeiro Helmer - Versão Hostinger
 */

// Configurações de erro
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Incluir sistema de gestão
require_once 'sistema_gestao_hostinger.php';

echo "<!DOCTYPE html>
<html lang='pt-BR'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Verificação Hostinger - Sistema Gestão</title>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css' rel='stylesheet'>
    <style>
        .status-ok { color: #28a745; }
        .status-erro { color: #dc3545; }
        .status-parcial { color: #ffc107; }
        .card-custom { border-left: 4px solid #007bff; }
        .card-custom.ok { border-left-color: #28a745; }
        .card-custom.erro { border-left-color: #dc3545; }
        .card-custom.parcial { border-left-color: #ffc107; }
    </style>
</head>
<body class='bg-light'>
    <div class='container mt-4'>
        <div class='row'>
            <div class='col-12'>
                <div class='card'>
                    <div class='card-header bg-primary text-white'>
                        <h1 class='h3 mb-0'>🚀 Verificação de Compatibilidade - Hostinger</h1>
                        <p class='mb-0'>Sistema de Gestão de Contas - Painel Financeiro Helmer</p>
                    </div>
                    <div class='card-body'>";

try {
    $sistema = new SistemaGestaoHostinger();
    $resultado = $sistema->executarVerificacaoCompleta();
    
    // Exibir resultado
    echo "<div class='alert alert-info'>
        <h5>📊 Resultado da Verificação</h5>
        <p><strong>Timestamp:</strong> " . $resultado['timestamp'] . "</p>
        <p><strong>Status:</strong> <span class='badge bg-" . ($resultado['status'] == 'ok' ? 'success' : ($resultado['status'] == 'erro' ? 'danger' : 'warning')) . "'>" . strtoupper($resultado['status']) . "</span></p>
    </div>";
    
    // Verificações detalhadas
    if (isset($resultado['verificacoes'])) {
        foreach ($resultado['verificacoes'] as $nome => $verificacao) {
            $card_class = 'card-custom';
            if (isset($verificacao['status'])) {
                if ($verificacao['status'] == 'ok') $card_class .= ' ok';
                elseif ($verificacao['status'] == 'erro') $card_class .= ' erro';
                elseif ($verificacao['status'] == 'parcial') $card_class .= ' parcial';
            }
            
            echo "<div class='card $card_class mb-3'>
                <div class='card-header'>
                    <h5 class='mb-0'>" . ucfirst(str_replace('_', ' ', $nome)) . "</h5>
                </div>
                <div class='card-body'>";
            
            if (is_array($verificacao)) {
                foreach ($verificacao as $key => $value) {
                    if (is_bool($value)) {
                        $badge_class = $value ? 'success' : 'danger';
                        echo "<span class='badge bg-$badge_class me-2'>$key: " . ($value ? 'OK' : 'ERRO') . "</span>";
                    } elseif (is_array($value)) {
                        echo "<p><strong>$key:</strong> " . implode(', ', $value) . "</p>";
                    } else {
                        echo "<p><strong>$key:</strong> $value</p>";
                    }
                }
            } else {
                echo "<p>$verificacao</p>";
            }
            
            echo "</div></div>";
        }
    }
    
    // Próximos passos
    echo "<div class='card card-custom mb-3'>
        <div class='card-header'>
            <h5 class='mb-0'>🎯 Próximos Passos</h5>
        </div>
        <div class='card-body'>
            <ol>
                <li>✅ Verificar se todas as tabelas foram criadas</li>
                <li>✅ Confirmar se o usuário admin foi criado</li>
                <li>✅ Testar o sistema de gestão de contas</li>
                <li>✅ Configurar permissões se necessário</li>
            </ol>
        </div>
    </div>";
    
    // Links úteis
    echo "<div class='card card-custom'>
        <div class='card-header'>
            <h5 class='mb-0'>🔗 Links Úteis</h5>
        </div>
        <div class='card-body'>
            <div class='row'>
                <div class='col-md-4'>
                    <a href='gestao_contas_unificada.php' class='btn btn-primary w-100 mb-2'>Gestão de Contas</a>
                </div>
                <div class='col-md-4'>
                    <a href='login.php' class='btn btn-secondary w-100 mb-2'>Login</a>
                </div>
                <div class='col-md-4'>
                    <a href='dashboard.php' class='btn btn-info w-100 mb-2'>Dashboard</a>
                </div>
            </div>
        </div>
    </div>";
    
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>
        <h5>❌ Erro na Verificação</h5>
        <p><strong>Erro:</strong> " . $e->getMessage() . "</p>
        <p><strong>Arquivo:</strong> " . $e->getFile() . "</p>
        <p><strong>Linha:</strong> " . $e->getLine() . "</p>
    </div>";
}

echo "                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src='https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js'></script>
</body>
</html>";
?>

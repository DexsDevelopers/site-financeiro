<?php
// atualizar_permissao.php - Atualizar permissão específica

session_start();
require_once 'includes/db_connect.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Acesso negado']);
    exit();
}

$userId = $_SESSION['user_id'];

// Verificar se é uma requisição POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit();
}

// Obter dados do POST
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['usuario_id']) || !isset($input['modulo']) || !isset($input['permissao']) || !isset($input['permitido'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Dados inválidos']);
    exit();
}

$usuarioId = (int)$input['usuario_id'];
$modulo = trim($input['modulo']);
$permissao = trim($input['permissao']);
$permitido = (bool)$input['permitido'];

try {
    // Verificar se o usuário tem permissão para alterar permissões
    $stmt = $pdo->prepare("
        SELECT cm.conta_id, cm.papel 
        FROM conta_membros cm 
        WHERE cm.usuario_id = ? AND cm.status = 'ativo'
        LIMIT 1
    ");
    $stmt->execute([$userId]);
    $membroAtual = $stmt->fetch();
    
    if (!$membroAtual || !in_array($membroAtual['papel'], ['proprietario', 'administrador'])) {
        echo json_encode(['success' => false, 'message' => 'Você não tem permissão para alterar permissões']);
        exit();
    }
    
    // Verificar se o usuário alvo é da mesma conta
    $stmt = $pdo->prepare("
        SELECT cm.conta_id 
        FROM conta_membros cm 
        WHERE cm.usuario_id = ? AND cm.status = 'ativo'
    ");
    $stmt->execute([$usuarioId]);
    $membroAlvo = $stmt->fetch();
    
    if (!$membroAlvo || $membroAlvo['conta_id'] !== $membroAtual['conta_id']) {
        echo json_encode(['success' => false, 'message' => 'Usuário não encontrado na mesma conta']);
        exit();
    }
    
    // Verificar se a permissão já existe
    $stmt = $pdo->prepare("
        SELECT id FROM conta_permissoes 
        WHERE conta_id = ? AND usuario_id = ? AND modulo = ? AND permissao = ?
    ");
    $stmt->execute([$membroAtual['conta_id'], $usuarioId, $modulo, $permissao]);
    $permissaoExistente = $stmt->fetch();
    
    if ($permissaoExistente) {
        // Atualizar permissão existente
        $stmt = $pdo->prepare("
            UPDATE conta_permissoes 
            SET permitido = ? 
            WHERE conta_id = ? AND usuario_id = ? AND modulo = ? AND permissao = ?
        ");
        $stmt->execute([$permitido, $membroAtual['conta_id'], $usuarioId, $modulo, $permissao]);
    } else {
        // Criar nova permissão
        $stmt = $pdo->prepare("
            INSERT INTO conta_permissoes (conta_id, usuario_id, modulo, permissao, permitido) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([$membroAtual['conta_id'], $usuarioId, $modulo, $permissao, $permitido]);
    }
    
    // Registrar log
    $stmt = $pdo->prepare("
        INSERT INTO conta_logs (conta_id, usuario_id, acao, modulo, detalhes) 
        VALUES (?, ?, 'permissao_alterada', 'sistema', ?)
    ");
    $stmt->execute([
        $membroAtual['conta_id'], 
        $userId, 
        "Permissão '{$permissao}' do módulo '{$modulo}' " . ($permitido ? 'concedida' : 'revogada') . " para usuário {$usuarioId}"
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Permissão atualizada com sucesso!'
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao atualizar permissão: ' . $e->getMessage()
    ]);
}
?>
